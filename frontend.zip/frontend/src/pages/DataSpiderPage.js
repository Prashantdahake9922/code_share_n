import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';
import { ORDERS } from '../data/dummyData';

export default function DataSpiderPage() {
  const { user } = useAuth();
  const { cases } = useCases();
  const [filterCaseId, setFilterCaseId] = useState('');
  const [filterChannel, setFilterChannel] = useState('');
  const [mode, setMode] = useState(user.role === 'supervisor' ? 'supervisor' : 'investigator');

  // Investigator only sees orders from their assigned cases
  const myCaseIds = user.role === 'investigator'
    ? cases.filter(c => c.assigned_to === user.id).map(c => c.id)
    : null;

  let filteredOrders = myCaseIds
    ? ORDERS.filter(o => myCaseIds.includes(o.case_id))
    : [...ORDERS];

  if (filterCaseId) {
    filteredOrders = filteredOrders.filter(o => o.case_id.toLowerCase().includes(filterCaseId.toLowerCase()) || o.order_id.toLowerCase().includes(filterCaseId.toLowerCase()));
  }
  if (filterChannel) {
    filteredOrders = filteredOrders.filter(o => o.channel === filterChannel);
  }

  const totalAmount = filteredOrders.reduce((sum, o) => sum + o.amount, 0);

  return (
    <div className="data-spider-page">
      <h1>🕷️ Data Spider - Order Aggregation</h1>
      <p className="page-description">
        Query Redshift for order-level details across {mode === 'supervisor' ? 'all cases (last 30 days)' : 'your assigned cases'}.
      </p>

      {/* Filters */}
      <div className="spider-filters">
        <input
          type="text"
          placeholder="Filter by Case ID or Order ID..."
          value={filterCaseId}
          onChange={e => setFilterCaseId(e.target.value)}
          className="search-input"
        />
        <select value={filterChannel} onChange={e => setFilterChannel(e.target.value)}>
          <option value="">All Channels</option>
          <option value="Web">Web</option>
          <option value="Mobile">Mobile</option>
          <option value="Store">Store</option>
        </select>
        {user.role === 'supervisor' && (
          <div className="mode-toggle">
            <label>
              <input type="radio" value="investigator" checked={mode === 'investigator'} onChange={e => setMode(e.target.value)} />
              Investigator
            </label>
            <label>
              <input type="radio" value="supervisor" checked={mode === 'supervisor'} onChange={e => setMode(e.target.value)} />
              Supervisor (All)
            </label>
          </div>
        )}
        <div className="spider-summary">
          <span>Orders: <strong>{filteredOrders.length}</strong></span>
          <span>Total Value: <strong>${totalAmount.toLocaleString()}</strong></span>
        </div>
      </div>

      {/* Orders Table */}
      <div className="spider-table-container">
        <table className="spider-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Case ID</th>
              <th>Customer</th>
              <th>Channel</th>
              <th>Amount</th>
              <th>Items</th>
              <th>Ship Address</th>
              <th>Status</th>
              <th>Created</th>
              <th>Risk Flags</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map(o => (
              <tr key={o.order_id}>
                <td className="order-id">{o.order_id}</td>
                <td className="case-link">{o.case_id}</td>
                <td>{o.customer}</td>
                <td><span className={`channel-badge channel-${o.channel.toLowerCase()}`}>{o.channel}</span></td>
                <td className="amount">${o.amount.toLocaleString()}</td>
                <td>{o.items}</td>
                <td className="address">{o.ship_address}</td>
                <td><span className={`order-status status-${o.status.toLowerCase()}`}>{o.status}</span></td>
                <td>{o.created_at}</td>
                <td>
                  {o.risk_flags.map(f => <span key={f} className="risk-flag">{f}</span>)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
