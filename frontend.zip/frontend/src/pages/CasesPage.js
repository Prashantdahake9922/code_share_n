import React, { useState } from 'react';
import FilterBar from '../components/FilterBar';
import CaseQueue from '../components/CaseQueue';
import CaseDetail from '../components/CaseDetail';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { TICKET_TYPES, PRIORITIES, USERS } from '../data/dummyData';

export default function CasesPage() {
  const { selectedCase, setSelectedCase, createCase } = useCases();
  const { user } = useAuth();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newCase, setNewCase] = useState({
    ticket_type: '', order_id: '', ucm_ticket_id: '', line_of_business: '',
    priority: 'medium', customer_name: '', customer_email: '', customer_phone: '',
    customer_account: '', description: '', assigned_to: ''
  });

  const handleCreate = () => {
    if (!newCase.ticket_type || !newCase.customer_name || !newCase.priority) return;
    createCase(newCase);
    setNewCase({ ticket_type: '', order_id: '', ucm_ticket_id: '', line_of_business: '', priority: 'medium', customer_name: '', customer_email: '', customer_phone: '', customer_account: '', description: '', assigned_to: '' });
    setShowCreateModal(false);
  };

  return (
    <div className="cases-page">
      <div className="cases-page-header">
        <h1>📋 Case Investigation</h1>
        <button className="btn-primary" onClick={() => setShowCreateModal(true)}>+ Create Case</button>
      </div>
      <FilterBar />
      <div className="cases-layout">
        <div className={`queue-panel ${selectedCase ? 'with-detail' : ''}`}>
          <CaseQueue />
        </div>
        {selectedCase && (
          <div className="detail-panel">
            <button className="btn-close-detail" onClick={() => setSelectedCase(null)}>✕</button>
            <CaseDetail />
          </div>
        )}
      </div>

      {/* Manual Case Creation Modal */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create New Case</h2>
              <button className="btn-close-detail" onClick={() => setShowCreateModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group">
                  <label>Ticket Type *</label>
                  <select value={newCase.ticket_type} onChange={e => setNewCase({ ...newCase, ticket_type: e.target.value })}>
                    <option value="">Select type...</option>
                    {TICKET_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Priority *</label>
                  <select value={newCase.priority} onChange={e => setNewCase({ ...newCase, priority: e.target.value })}>
                    {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>UCM Ticket ID</label>
                  <input type="text" value={newCase.ucm_ticket_id} onChange={e => setNewCase({ ...newCase, ucm_ticket_id: e.target.value })} placeholder="UCM-XXXX" />
                </div>
                <div className="form-group">
                  <label>Order ID</label>
                  <input type="text" value={newCase.order_id} onChange={e => setNewCase({ ...newCase, order_id: e.target.value })} placeholder="ORD-XXXX" />
                </div>
                <div className="form-group">
                  <label>Line of Business</label>
                  <input type="text" value={newCase.line_of_business} onChange={e => setNewCase({ ...newCase, line_of_business: e.target.value })} placeholder="E-Commerce, Retail, Wireless..." />
                </div>
                <div className="form-group">
                  <label>Assigned To</label>
                  <select value={newCase.assigned_to} onChange={e => setNewCase({ ...newCase, assigned_to: e.target.value })}>
                    <option value="">Unassigned</option>
                    {USERS.filter(u => u.role === 'investigator').map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
              </div>
              <h4 style={{ marginTop: '1rem' }}>Customer Information</h4>
              <div className="form-grid">
                <div className="form-group">
                  <label>Customer Name *</label>
                  <input type="text" value={newCase.customer_name} onChange={e => setNewCase({ ...newCase, customer_name: e.target.value })} placeholder="Full name" />
                </div>
                <div className="form-group">
                  <label>Customer Email</label>
                  <input type="email" value={newCase.customer_email} onChange={e => setNewCase({ ...newCase, customer_email: e.target.value })} placeholder="email@example.com" />
                </div>
                <div className="form-group">
                  <label>Customer Phone</label>
                  <input type="tel" value={newCase.customer_phone} onChange={e => setNewCase({ ...newCase, customer_phone: e.target.value })} placeholder="XXX-XXX-XXXX" />
                </div>
                <div className="form-group">
                  <label>Account Number</label>
                  <input type="text" value={newCase.customer_account} onChange={e => setNewCase({ ...newCase, customer_account: e.target.value })} placeholder="ACC-XXXXX" />
                </div>
              </div>
              <div className="form-group" style={{ marginTop: '1rem' }}>
                <label>Description</label>
                <textarea value={newCase.description} onChange={e => setNewCase({ ...newCase, description: e.target.value })} placeholder="Case description..." rows={3} />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn-secondary" onClick={() => setShowCreateModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={handleCreate} disabled={!newCase.ticket_type || !newCase.customer_name}>Create Case</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
