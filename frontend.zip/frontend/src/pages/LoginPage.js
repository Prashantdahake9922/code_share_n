import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [selectedRole, setSelectedRole] = useState('investigator');
  const [showForm, setShowForm] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = login(username, password);
    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error);
    }
  };

  const handleSignInClick = () => {
    setShowForm(true);
    setError('');
    setUsername('');
    setPassword('');
  };

  return (
    <div className="login-page">
      {/* Geometric background shapes */}
      <div className="login-bg-shape login-bg-shape-1"></div>
      <div className="login-bg-shape login-bg-shape-2"></div>
      <div className="login-bg-shape login-bg-shape-3"></div>

      <div className="login-container">
        {/* Brand Header */}
        <div className="login-brand">
          <div className="brand-shield">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
              <path d="M24 4L6 12V22C6 33.1 13.7 43.4 24 46C34.3 43.4 42 33.1 42 22V12L24 4Z" fill="#1565c0" stroke="#0d47a1" strokeWidth="1.5"/>
              <path d="M20 24L23 27L28 20" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h1 className="brand-title">Spectrum</h1>
          <p className="brand-subtitle">Fraud Investigation</p>
        </div>

        {/* Role Selection */}
        <div className="login-role-section">
          <div className="role-cards">
            <div
              className={`role-card ${selectedRole === 'investigator' ? 'selected' : ''}`}
              onClick={() => { setSelectedRole('investigator'); setShowForm(false); }}
            >
              <div className="role-card-icon-wrap">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                  <circle cx="10.5" cy="10.5" r="6" stroke="currentColor" strokeWidth="2"/>
                  <path d="M15 15L20 20" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/>
                </svg>
              </div>
              <span className="role-card-label">Investigator</span>
              {selectedRole === 'investigator' && <span className="role-check">✓</span>}
            </div>
            <div
              className={`role-card ${selectedRole === 'supervisor' ? 'selected' : ''}`}
              onClick={() => { setSelectedRole('supervisor'); setShowForm(false); }}
            >
              <div className="role-card-icon-wrap">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L4 6V11C4 16.5 7.8 21.7 12 23C16.2 21.7 20 16.5 20 11V6L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
                  <path d="M9 12L11 14L15 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <span className="role-card-label">Supervisor</span>
              {selectedRole === 'supervisor' && <span className="role-check">✓</span>}
            </div>
          </div>
        </div>

        {/* Sign In Button - shows credential form on click */}
        {!showForm ? (
          <button className="btn-login-primary" onClick={handleSignInClick}>
            Sign in as {selectedRole === 'supervisor' ? 'Supervisor' : 'Investigator'}
          </button>
        ) : (
          <>
            <div className="login-form-header">
              <span>Sign in as <strong>{selectedRole === 'supervisor' ? 'Supervisor' : 'Investigator'}</strong></span>
            </div>
            <form onSubmit={handleSubmit} className="login-form">
              {error && <div className="error-msg">{error}</div>}
              <div className="login-field">
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Username"
                  autoFocus
                  required
                />
              </div>
              <div className="login-field">
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                />
              </div>
              <button type="submit" className="btn-login-primary">Sign In</button>
              <button type="button" className="btn-login-back" onClick={() => setShowForm(false)}>← Back</button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
