import React, { useState } from 'react';
import { AUDIT_TRAIL_SAMPLE } from '../data/dummyData';

const ACTION_TYPES = [...new Set(AUDIT_TRAIL_SAMPLE.map(a => a.action))];

export default function AuditLogPage() {
  const [filterCaseId, setFilterCaseId] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');

  const getFiltered = () => {
    let filtered = [...AUDIT_TRAIL_SAMPLE];
    if (filterCaseId) {
      filtered = filtered.filter(a => a.case_id.toLowerCase().includes(filterCaseId.toLowerCase()));
    }
    if (filterAction) {
      filtered = filtered.filter(a => a.action === filterAction);
    }
    if (filterDateFrom) {
      filtered = filtered.filter(a => a.timestamp >= filterDateFrom);
    }
    if (filterDateTo) {
      filtered = filtered.filter(a => a.timestamp <= filterDateTo + 'T23:59:59Z');
    }
    return filtered;
  };

  const filtered = getFiltered();

  const handleExportJSON = () => {
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'audit_log_export.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCSV = () => {
    const headers = 'id,case_id,action,actor,timestamp,details';
    const rows = filtered.map(t => `"${t.id}","${t.case_id}","${t.action}","${t.actor}","${t.timestamp}","${t.details}"`);
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'audit_log_export.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="audit-log-page">
      <h1>📋 Audit Log</h1>
      <p className="page-description">Full audit trail of AI decisions, human overrides, system actions, and data events. Filter and export for compliance.</p>

      {/* Filters */}
      <div className="audit-filters">
        <input
          type="text"
          placeholder="Filter by Case ID..."
          value={filterCaseId}
          onChange={e => setFilterCaseId(e.target.value)}
          className="search-input"
        />
        <select value={filterAction} onChange={e => setFilterAction(e.target.value)}>
          <option value="">All Actions</option>
          {ACTION_TYPES.map(a => <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>)}
        </select>
        <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} title="From Date" />
        <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} title="To Date" />
        <div className="audit-export-btns">
          <button className="btn-export" onClick={handleExportJSON}>📥 Export JSON</button>
          <button className="btn-export" onClick={handleExportCSV}>📥 Export CSV</button>
        </div>
      </div>

      {/* Results count */}
      <div className="audit-count">
        Showing <strong>{filtered.length}</strong> of {AUDIT_TRAIL_SAMPLE.length} records
      </div>

      {/* Audit Table */}
      <div className="audit-table-container">
        <table className="audit-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Case ID</th>
              <th>Action</th>
              <th>Actor</th>
              <th>Timestamp</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(a => (
              <tr key={a.id}>
                <td className="audit-id">{a.id}</td>
                <td className="case-link">{a.case_id}</td>
                <td><span className={`audit-action-badge action-${a.action}`}>{a.action.replace(/_/g, ' ')}</span></td>
                <td>{a.actor}</td>
                <td className="audit-timestamp">{new Date(a.timestamp).toLocaleString()}</td>
                <td className="audit-details">{a.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="no-data">No audit records match the selected filters.</p>}
      </div>
    </div>
  );
}
