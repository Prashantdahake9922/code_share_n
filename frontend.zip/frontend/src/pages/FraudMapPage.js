import React, { useState } from 'react';
import { FRAUD_MAP_DATA } from '../data/dummyData';

export default function FraudMapPage() {
  const [view, setView] = useState('heatmap');
  const [selectedState, setSelectedState] = useState(null);
  const [selectedRing, setSelectedRing] = useState(null);
  const [stateSortBy, setStateSortBy] = useState('fraud_impact');
  const [stateSortOrder, setStateSortOrder] = useState('desc');

  const maxImpact = Math.max(...FRAUD_MAP_DATA.states.map(s => s.fraud_impact));

  const getHeatColor = (impact) => {
    const intensity = impact / maxImpact;
    if (intensity > 0.7) return '#c62828';
    if (intensity > 0.5) return '#e65100';
    if (intensity > 0.3) return '#f57f17';
    return '#2e7d32';
  };

  const getRingColor = (level) => {
    switch (level) {
      case 'critical': return '#b71c1c';
      case 'high': return '#e65100';
      case 'medium': return '#f9a825';
      default: return '#bdbdbd';
    }
  };

  return (
    <div className="fraud-map-page">
      <h1>🗺️ Fraud Map & Ring Detection</h1>

      {/* View Toggle */}
      <div className="map-toggle">
        <button className={`toggle-btn ${view === 'heatmap' ? 'active' : ''}`} onClick={() => setView('heatmap')}>
          🗺️ Heatmap View
        </button>
        <button className={`toggle-btn ${view === 'rings' ? 'active' : ''}`} onClick={() => setView('rings')}>
          🔗 Fraud Rings View
        </button>
      </div>

      {view === 'heatmap' && (
        <div className="heatmap-layout">
          {/* Map Visualization (simplified grid representation) */}
          <div className="map-container">
            <h3>US Fraud Impact by State (Choropleth)</h3>
            <div className="state-grid">
              {FRAUD_MAP_DATA.states.map(state => (
                <div
                  key={state.state}
                  className={`state-cell ${selectedState?.state === state.state ? 'selected' : ''}`}
                  style={{ backgroundColor: getHeatColor(state.fraud_impact) }}
                  onClick={() => setSelectedState(state)}
                  title={`${state.name}: ${state.fraud_impact} impacts`}
                >
                  <span className="state-code">{state.state}</span>
                  <span className="state-impact">{state.fraud_impact}</span>
                </div>
              ))}
            </div>
            <div className="map-legend">
              <span style={{ backgroundColor: '#2e7d32' }}>Low</span>
              <span style={{ backgroundColor: '#f57f17' }}>Medium</span>
              <span style={{ backgroundColor: '#e65100' }}>High</span>
              <span style={{ backgroundColor: '#c62828' }}>Critical</span>
            </div>
          </div>

          {/* State Ranking */}
          <div className="state-ranking">
            <h3>State Ranking</h3>
            <table className="ranking-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>State</th>
                  <th onClick={() => { setStateSortBy('fraud_impact'); setStateSortOrder(stateSortBy === 'fraud_impact' && stateSortOrder === 'desc' ? 'asc' : 'desc'); }} style={{ cursor: 'pointer' }}>
                    Impact {stateSortBy === 'fraud_impact' ? (stateSortOrder === 'desc' ? '↓' : '↑') : ''}
                  </th>
                  <th onClick={() => { setStateSortBy('confirmed'); setStateSortOrder(stateSortBy === 'confirmed' && stateSortOrder === 'desc' ? 'asc' : 'desc'); }} style={{ cursor: 'pointer' }}>
                    Confirmed {stateSortBy === 'confirmed' ? (stateSortOrder === 'desc' ? '↓' : '↑') : ''}
                  </th>
                  <th>ZIP Count</th>
                </tr>
              </thead>
              <tbody>
                {[...FRAUD_MAP_DATA.states]
                  .sort((a, b) => stateSortOrder === 'desc' ? b[stateSortBy] - a[stateSortBy] : a[stateSortBy] - b[stateSortBy])
                  .map((s, i) => (
                    <tr key={s.state} className={selectedState?.state === s.state ? 'selected' : ''} onClick={() => setSelectedState(s)}>
                      <td>{i + 1}</td>
                      <td>{s.name}</td>
                      <td><strong>{s.fraud_impact}</strong></td>
                      <td>{s.confirmed}</td>
                      <td>{s.zip_count}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* State Detail */}
          {selectedState && (
            <div className="state-detail">
              <h3>{selectedState.name} ({selectedState.state})</h3>
              <div className="detail-metrics">
                <div><strong>Fraud Impact:</strong> {selectedState.fraud_impact}</div>
                <div><strong>Confirmed Fraud:</strong> {selectedState.confirmed}</div>
                <div><strong>ZIP Codes Affected:</strong> {selectedState.zip_count}</div>
                <div><strong>Top ZIPs:</strong> {selectedState.top_zips.join(', ')}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {view === 'rings' && (
        <div className="rings-layout">
          {/* Fraud Rings List */}
          <div className="rings-list">
            <h3>Detected Fraud Rings (Top {FRAUD_MAP_DATA.fraud_rings.length})</h3>
            <div className="rings-grid">
              {FRAUD_MAP_DATA.fraud_rings.map(ring => (
                <div
                  key={ring.id}
                  className={`ring-card ${selectedRing?.id === ring.id ? 'selected' : ''}`}
                  onClick={() => setSelectedRing(ring)}
                  style={{ borderLeft: `4px solid ${getRingColor(ring.risk_level)}` }}
                >
                  <div className="ring-header">
                    <strong>{ring.id}</strong>
                    <span className={`ring-level level-${ring.risk_level}`}>{ring.risk_level}</span>
                  </div>
                  <div className="ring-stats">
                    <span>Nodes: {ring.nodes}</span>
                    <span>Edges: {ring.edges}</span>
                  </div>
                  <div className="ring-cities">{ring.cities.join(', ')}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Ring Visualization */}
          <div className="ring-visualization">
            <h3>Ring Network Graph</h3>
            {selectedRing ? (
              <div className="ring-detail-view">
                <div className="ring-graph-placeholder">
                  <div className="graph-nodes">
                    {Array.from({ length: selectedRing.nodes }, (_, i) => (
                      <div key={i} className="graph-node" style={{
                        left: `${20 + (i % 4) * 25}%`,
                        top: `${20 + Math.floor(i / 4) * 40}%`,
                        width: `${30 + Math.random() * 20}px`,
                        height: `${30 + Math.random() * 20}px`,
                      }}>
                        <span>N{i + 1}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="ring-detail-info">
                  <h4>Ring Details: {selectedRing.id}</h4>
                  <p><strong>Risk Level:</strong> <span className={`ring-level level-${selectedRing.risk_level}`}>{selectedRing.risk_level}</span></p>
                  <p><strong>Nodes:</strong> {selectedRing.nodes} | <strong>Edges:</strong> {selectedRing.edges}</p>
                  <p><strong>Shared Attributes:</strong> {selectedRing.shared.join(', ')}</p>
                  <p><strong>ZIP Codes:</strong> {selectedRing.zips.join(', ')}</p>
                  <p><strong>Cities:</strong> {selectedRing.cities.join(', ')}</p>
                </div>
              </div>
            ) : (
              <p className="no-data">Select a fraud ring to view its network graph</p>
            )}
          </div>

          {/* Legend */}
          <div className="ring-legend">
            <h4>Link Types</h4>
            <div className="legend-items">
              <span className="legend-item"><span className="legend-color" style={{ background: '#1565c0' }}></span> City</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#c62828' }}></span> Email</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#2e7d32' }}></span> Phone</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#e65100' }}></span> Address</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
