import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';
import { FEEDBACK_METRICS } from '../data/dummyData';
import KPICard from '../components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, Legend } from 'recharts';

export default function DashboardPage() {
  const { user } = useAuth();
  const { cases, setFilters } = useCases();
  const navigate = useNavigate();

  // Role-based: investigator sees only their cases, supervisor sees all
  const myCases = user.role === 'investigator'
    ? cases.filter(c => c.assigned_to === user.id)
    : cases;

  const openCases = myCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status)).length;
  const resolvedCases = myCases.filter(c => c.status === 'resolved').length;
  const escalatedCases = myCases.filter(c => c.status === 'escalated').length;
  const slaBreach = myCases.filter(c => c.sla_status === 'breached').length;
  const pendingCases = myCases.filter(c => c.status === 'pending_customer').length;
  const autoRejected = myCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85).length;

  const navigateWithFilter = (filterKey, filterValue) => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '', [filterKey]: filterValue });
    navigate('/cases');
  };

  const typeDistribution = [
    { name: 'Fraud Ordering', value: myCases.filter(c => c.ticket_type === 'fraud_ordering').length },
    { name: 'Credit Abuse', value: myCases.filter(c => c.ticket_type.startsWith('credit_abuse')).length },
    { name: 'Fraud Non-Ord', value: myCases.filter(c => c.ticket_type === 'fraud_non_ordering').length },
    { name: 'General', value: myCases.filter(c => c.ticket_type === 'general').length },
  ];

  const priorityDistribution = [
    { name: 'Critical', value: myCases.filter(c => c.priority === 'critical').length, color: '#ef5350' },
    { name: 'High', value: myCases.filter(c => c.priority === 'high').length, color: '#ffab40' },
    { name: 'Medium', value: myCases.filter(c => c.priority === 'medium').length, color: '#ffd54f' },
    { name: 'Low', value: myCases.filter(c => c.priority === 'low').length, color: '#66bb6a' },
  ];

  const trendData = [
    { week: 'W1 Apr', cases: 45, resolved: 38 },
    { week: 'W2 Apr', cases: 52, resolved: 44 },
    { week: 'W3 Apr', cases: 48, resolved: 41 },
    { week: 'W4 Apr', cases: 61, resolved: 52 },
    { week: 'W5 Apr', cases: 55, resolved: 43 },
  ];

  const COLORS = ['#7986cb', '#ffab40', '#66bb6a', '#ce93d8'];

  const recentActivity = [
    { time: '10:30', event: 'Case FPM-001 assigned to John Doe', type: 'assign' },
    { time: '10:15', event: 'Case FPM-008 auto-rejected (score: 95)', type: 'reject' },
    { time: '09:45', event: 'Case FPM-006 resolved - fraud_found', type: 'resolve' },
    { time: '09:30', event: 'SLA breach alert: FPM-004 (156h inactive)', type: 'alert' },
    { time: '09:00', event: 'Case FPM-010 pending customer response', type: 'pending' },
    { time: '08:30', event: 'New ticket UCM-5525 ingested', type: 'new' },
    { time: '08:15', event: 'Case FPM-003 auto-approve candidate', type: 'approve' },
  ];

  return (
    <div className="dashboard-page">
      <h1>Dashboard {user.role === 'supervisor' ? '(Supervisor View)' : ''}</h1>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div onClick={() => navigateWithFilter('status', 'open')} style={{ cursor: 'pointer' }}>
          <KPICard title="Open Cases" value={openCases} color="#ff9800" icon="📂" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'resolved')} style={{ cursor: 'pointer' }}>
          <KPICard title="Resolved" value={resolvedCases} color="#66bb6a" icon="✅" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'escalated')} style={{ cursor: 'pointer' }}>
          <KPICard title="Escalated" value={escalatedCases} color="#ef5350" icon="🚨" />
        </div>
        <div onClick={() => user.role === 'supervisor' ? navigate('/sla-monitor') : navigateWithFilter('status', '')} style={{ cursor: 'pointer' }}>
          <KPICard title="SLA Breached" value={slaBreach} color="#ff5252" icon="⏰" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'pending_customer')} style={{ cursor: 'pointer' }}>
          <KPICard title="Pending Customer" value={pendingCases} color="#ce93d8" icon="⏳" />
        </div>
        <KPICard title="Auto-Rejected" value={autoRejected} color="#f48fb1" icon="🤖" />
        {user.role === 'supervisor' && (
          <>
            <KPICard title="AI Accuracy" value={`${FEEDBACK_METRICS.ai_accuracy}%`} color="#00bcd4" icon="🎯" />
            <KPICard title="Total Decisions" value={FEEDBACK_METRICS.total_decisions} color="#78909c" icon="📊" />
          </>
        )}
      </div>

      {/* Charts Row */}
      <div className="charts-row">
        <div className="chart-card">
          <h3>Case Distribution by Type</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={typeDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="name" fontSize={11} tick={{ fill: '#b0bec5' }} axisLine={{ stroke: '#455a64' }} />
              <YAxis tick={{ fill: '#b0bec5' }} axisLine={{ stroke: '#455a64' }} />
              <Tooltip contentStyle={{ background: '#1a1f3a', border: '1px solid rgba(100,181,246,0.3)', borderRadius: '8px', color: '#e0e0e0' }} />
              <Bar dataKey="value" fill="#5c6bc0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Priority Breakdown</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={priorityDistribution} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={{ stroke: '#78909c' }} style={{ fontSize: '0.75rem' }}>
                {priorityDistribution.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: '#1a1f3a', border: '1px solid rgba(100,181,246,0.3)', borderRadius: '8px', color: '#e0e0e0' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Weekly Case Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="week" fontSize={11} tick={{ fill: '#b0bec5' }} axisLine={{ stroke: '#455a64' }} />
              <YAxis tick={{ fill: '#b0bec5' }} axisLine={{ stroke: '#455a64' }} />
              <Tooltip contentStyle={{ background: '#1a1f3a', border: '1px solid rgba(100,181,246,0.3)', borderRadius: '8px', color: '#e0e0e0' }} />
              <Legend wrapperStyle={{ color: '#b0bec5' }} />
              <Line type="monotone" dataKey="cases" stroke="#64b5f6" strokeWidth={2} name="New Cases" dot={{ fill: '#64b5f6' }} />
              <Line type="monotone" dataKey="resolved" stroke="#69f0ae" strokeWidth={2} name="Resolved" dot={{ fill: '#69f0ae' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="bottom-row">
        <div className="activity-feed">
          <h3>Recent Activity</h3>
          <div className="activity-list">
            {recentActivity.map((a, i) => (
              <div key={i} className={`activity-item activity-${a.type}`}>
                <span className="activity-time">{a.time}</span>
                <span className="activity-event">{a.event}</span>
              </div>
            ))}
          </div>
        </div>

        {user.role === 'supervisor' && (
        <div className="feedback-card">
          <h3>AI Feedback Metrics</h3>

          {/* Summary Stats Grid */}
          <div className="feedback-stats-grid">
            <div className="feedback-stat-item">
              <span className="feedback-stat-value">{FEEDBACK_METRICS.total_decisions}</span>
              <span className="feedback-stat-label">Total Decisions</span>
            </div>
            <div className="feedback-stat-item">
              <span className="feedback-stat-value" style={{ color: FEEDBACK_METRICS.override_rate > 30 ? '#ef5350' : '#69f0ae' }}>{FEEDBACK_METRICS.override_rate}%</span>
              <span className="feedback-stat-label">Override Rate</span>
            </div>
            <div className="feedback-stat-item">
              <span className="feedback-stat-value" style={{ color: '#69f0ae' }}>{FEEDBACK_METRICS.accept_rate}%</span>
              <span className="feedback-stat-label">Accept Rate</span>
            </div>
          </div>

          {/* Risk Band Accuracy */}
          <div className="feedback-section">
            <h4>Risk Band Accuracy</h4>
            <div className="accuracy-bars">
              {Object.entries(FEEDBACK_METRICS.by_risk_band).map(([band, data]) => (
                <div key={band} className="accuracy-bar-item">
                  <div className="accuracy-bar-label">
                    <span className={`risk-band-tag band-${band}`}>{band}</span>
                    <span className="accuracy-bar-value">{data.accuracy}%</span>
                  </div>
                  <div className="accuracy-bar-track">
                    <div className="accuracy-bar-fill" style={{ width: `${data.accuracy}%`, background: data.accuracy >= 90 ? '#69f0ae' : data.accuracy >= 80 ? '#ffab40' : '#ef5350' }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Disposition Accuracy */}
          <div className="feedback-section">
            <h4>Accuracy by Disposition</h4>
            <div className="disposition-grid">
              {Object.entries(FEEDBACK_METRICS.by_disposition).map(([key, val]) => (
                <div key={key} className="disposition-item">
                  <div className="disposition-header">
                    <span className="disposition-name">{key.replace(/_/g, ' ')}</span>
                    <span className="disposition-accuracy" style={{ color: val.accuracy < 70 ? '#ef5350' : val.accuracy < 80 ? '#ffab40' : '#69f0ae' }}>{val.accuracy}%</span>
                  </div>
                  <div className="disposition-bar-track">
                    <div className="disposition-bar-fill" style={{ width: `${val.accuracy}%`, background: val.accuracy < 70 ? '#ef5350' : val.accuracy < 80 ? '#ffab40' : '#69f0ae' }}></div>
                  </div>
                  <span className="disposition-detail">{val.correct}/{val.total} correct</span>
                </div>
              ))}
            </div>
          </div>

          {/* Threshold Recommendations */}
          <div className="feedback-section">
            <h4>Threshold Recommendations</h4>
            <ul className="threshold-recs">
              {FEEDBACK_METRICS.override_rate > 30 && <li className="rec-warning">⚠️ Override rate ({FEEDBACK_METRICS.override_rate}%) exceeds 30% — review auto-decision thresholds</li>}
              {Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).map(([key, val]) => (
                <li key={key} className="rec-warning">⚠️ "{key.replace(/_/g, ' ')}" accuracy ({val.accuracy}%) below 70% — adjust confidence threshold</li>
              ))}
              {Object.entries(FEEDBACK_METRICS.by_risk_band).filter(([, v]) => v.accuracy < 60).map(([key, val]) => (
                <li key={key} className="rec-critical">🔴 Risk band "{key}" accuracy ({val.accuracy}%) below 60% — retrain model</li>
              ))}
              {FEEDBACK_METRICS.override_rate <= 30 && Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).length === 0 && (
                <li className="rec-ok">✅ All metrics within acceptable thresholds</li>
              )}
            </ul>
          </div>

          {/* Override Patterns */}
          <div className="feedback-section">
            <h4>Common Override Patterns</h4>
            <ul className="override-patterns">
              {FEEDBACK_METRICS.common_overrides.map((o, i) => <li key={i}>{o}</li>)}
            </ul>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}
