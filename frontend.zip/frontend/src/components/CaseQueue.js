import React, { useState } from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { USERS } from '../data/dummyData';

export default function CaseQueue() {
  const { user } = useAuth();
  const { getFilteredCases, setSelectedCase, selectedCase } = useCases();
  const [quickFilter, setQuickFilter] = useState('all');
  const filteredCases = getFilteredCases(user.role, user.id);

  // Apply quick filters on top of existing filters
  const getQuickFiltered = () => {
    switch (quickFilter) {
      case 'open':
        return filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'my_open':
        return filteredCases.filter(c => c.assigned_to === user.id && ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'auto_rejected':
        return filteredCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85);
      case 'pending':
        return filteredCases.filter(c => c.status === 'pending_customer' || c.disposition === 'pending');
      default:
        return filteredCases;
    }
  };

  const displayCases = getQuickFiltered();

  const getAssigneeName = (id) => USERS.find(u => u.id === id)?.name || 'Unassigned';

  const getSLAIcon = (sla) => {
    switch (sla) {
      case 'on_track': return <span className="sla-badge on-track">✓ On Track</span>;
      case 'at_risk': return <span className="sla-badge at-risk">⚠️ At Risk</span>;
      case 'breached': return <span className="sla-badge breached">🔴 Breached</span>;
      default: return null;
    }
  };

  const getPriorityClass = (p) => {
    switch (p) {
      case 'critical': return 'priority-critical';
      case 'high': return 'priority-high';
      case 'medium': return 'priority-medium';
      case 'low': return 'priority-low';
      default: return '';
    }
  };

  return (
    <div className="case-queue">
      <div className="quick-filter-bar">
        <button className={`quick-filter-btn ${quickFilter === 'all' ? 'active' : ''}`} onClick={() => setQuickFilter('all')}>All</button>
        <button className={`quick-filter-btn ${quickFilter === 'open' ? 'active' : ''}`} onClick={() => setQuickFilter('open')}>Open</button>
        <button className={`quick-filter-btn ${quickFilter === 'my_open' ? 'active' : ''}`} onClick={() => setQuickFilter('my_open')}>My Open</button>
        <button className={`quick-filter-btn ${quickFilter === 'auto_rejected' ? 'active' : ''}`} onClick={() => setQuickFilter('auto_rejected')}>Auto-Rejected</button>
        <button className={`quick-filter-btn ${quickFilter === 'pending' ? 'active' : ''}`} onClick={() => setQuickFilter('pending')}>Pending</button>
      </div>
      <div className="queue-header-info">
        <span>Showing {displayCases.length} cases</span>
      </div>
      <table className="queue-table">
        <thead>
          <tr>
            <th>Case ID</th>
            <th>UCM #</th>
            <th>Order #</th>
            <th>Type</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Risk</th>
            <th>SLA</th>
            <th>Investigator</th>
          </tr>
        </thead>
        <tbody>
          {displayCases.map(c => (
            <tr
              key={c.id}
              className={`queue-row ${selectedCase?.id === c.id ? 'selected' : ''}`}
              onClick={() => setSelectedCase(c)}
            >
              <td className="case-id">{c.id}</td>
              <td>{c.ucm_ticket_id}</td>
              <td>{c.order_id}</td>
              <td><span className="type-badge">{c.ticket_type.replace(/_/g, ' ')}</span></td>
              <td><span className={`priority-badge ${getPriorityClass(c.priority)}`}>{c.priority}</span></td>
              <td><span className={`status-badge status-${c.status}`}>{c.status.replace('_', ' ')}</span></td>
              <td><span className="risk-score">{c.risk_score}</span></td>
              <td>{getSLAIcon(c.sla_status)}</td>
              <td>{getAssigneeName(c.assigned_to)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
