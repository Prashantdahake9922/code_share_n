import React from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { STATUSES, PRIORITIES, TICKET_TYPES, USERS } from '../data/dummyData';

export default function FilterBar() {
  const { filters, setFilters, sortField, setSortField, sortOrder, setSortOrder, getFilteredCases } = useCases();
  const { user } = useAuth();

  const handleChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const handleExportCSV = () => {
    const cases = getFilteredCases(user.role, user.id);
    const headers = ['case_id', 'ucm_ticket_id', 'order_id', 'ticket_type', 'line_of_business', 'priority', 'status', 'assigned_to', 'disposition', 'customer_name', 'customer_email', 'risk_score', 'created_at', 'updated_at', 'sla_status', 'comments_count'];
    const rows = cases.map(c => [
      c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.line_of_business,
      c.priority, c.status, USERS.find(u => u.id === c.assigned_to)?.name || '',
      c.disposition || '', c.customer.name, c.customer.email, c.risk_score,
      c.created_at, c.updated_at, c.sla_status, c.comments_count
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'cases_export.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="filter-bar">
      <div className="filter-group">
        <input
          type="text"
          placeholder="🔍 Search Case ID, UCM #, Order ID, Customer, Phone, Account..."
          value={filters.search}
          onChange={e => handleChange('search', e.target.value)}
          className="search-input"
        />
      </div>
      <div className="filter-group">
        <select value={filters.status} onChange={e => handleChange('status', e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
        </select>
        <select value={filters.priority} onChange={e => handleChange('priority', e.target.value)}>
          <option value="">All Priorities</option>
          {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select value={filters.ticket_type} onChange={e => handleChange('ticket_type', e.target.value)}>
          <option value="">All Types</option>
          {TICKET_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
        </select>
        {user.role === 'supervisor' && (
          <select value={filters.assigned_to} onChange={e => handleChange('assigned_to', e.target.value)}>
            <option value="">All Investigators</option>
            {USERS.filter(u => u.role === 'investigator').map(u => (
              <option key={u.id} value={u.id}>{u.name}</option>
            ))}
          </select>
        )}
      </div>
      <div className="filter-group">
        <input type="date" value={filters.dateFrom || ''} onChange={e => handleChange('dateFrom', e.target.value)} title="From Date" />
        <input type="date" value={filters.dateTo || ''} onChange={e => handleChange('dateTo', e.target.value)} title="To Date" />
      </div>
      <div className="filter-group">
        <select value={sortField} onChange={e => setSortField(e.target.value)}>
          <option value="created_at">Sort: Created</option>
          <option value="priority">Sort: Priority</option>
          <option value="status">Sort: Status</option>
          <option value="risk_score">Sort: Risk Score</option>
        </select>
        <button className="btn-sort" onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>
          {sortOrder === 'asc' ? '↑' : '↓'}
        </button>
        <button className="btn-export" onClick={handleExportCSV} title="Export to CSV">📥 Export CSV</button>
      </div>
    </div>
  );
}
