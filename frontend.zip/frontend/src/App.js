import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CasesProvider } from './contexts/CasesContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { SystemHealthProvider } from './contexts/SystemHealthContext';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import CasesPage from './pages/CasesPage';
import DataSpiderPage from './pages/DataSpiderPage';
import FraudMapPage from './pages/FraudMapPage';
import NLPQueryPage from './pages/NLPQueryPage';
import SLAMonitorPage from './pages/SLAMonitorPage';
import AuditLogPage from './pages/AuditLogPage';

function ProtectedRoute({ children, requireRole }) {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" />;
  if (requireRole && user.role !== requireRole) return <Navigate to="/dashboard" />;
  return children;
}

function AppRoutes() {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <LoginPage />} />
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="cases" element={<CasesPage />} />
        <Route path="data-spider" element={<DataSpiderPage />} />
        <Route path="fraud-map" element={<FraudMapPage />} />
        <Route path="nlp-query" element={<NLPQueryPage />} />
        <Route path="sla-monitor" element={<ProtectedRoute requireRole="supervisor"><SLAMonitorPage /></ProtectedRoute>} />
        <Route path="audit-log" element={<ProtectedRoute requireRole="supervisor"><AuditLogPage /></ProtectedRoute>} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <SystemHealthProvider>
          <AuthProvider>
            <CasesProvider>
              <AppRoutes />
            </CasesProvider>
          </AuthProvider>
        </SystemHealthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
