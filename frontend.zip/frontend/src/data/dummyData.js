// ==================== DUMMY DATA FOR FPM SYSTEM ====================

export const USERS = [
  { id: 'usr-001', username: 'john.doe', password: 'password123', name: 'John Doe', role: 'investigator' },
  { id: 'usr-002', username: 'jane.smith', password: 'password123', name: 'Jane Smith', role: 'investigator' },
  { id: 'usr-003', username: 'mike.wilson', password: 'password123', name: 'Mike Wilson', role: 'supervisor' },
  { id: 'usr-004', username: 'admin', password: 'admin', name: 'Admin User', role: 'supervisor' },
];

export const TICKET_TYPES = [
  'fraud_ordering', 'fraud_non_ordering', 'credit_abuse_ordering',
  'credit_abuse_sor', 'credit_abuse_appeal', 'general'
];

export const STATUSES = [
  'unassigned', 'assigned', 'open', 'in_progress', 'escalated',
  'pending_customer', 'closed', 'canceled', 'resolved'
];

export const DISPOSITIONS = [
  'approve', 'reject', 'customer_engagement', 'cannot_determine',
  'fraud_found', 'no_fraud', 'waiting_for_documents', 'issue_with_ticket',
  'credit_approved', 'credit_denied'
];

export const PRIORITIES = ['critical', 'high', 'medium', 'low'];

export const SLA_STATUSES = ['on_track', 'at_risk', 'breached'];

export const RISK_FACTORS = [
  { id: 'RF-01', label: 'SSN not found', weight: 15 },
  { id: 'RF-02', label: 'Deceased SSN', weight: 20 },
  { id: 'RF-03', label: 'Synthetic ID', weight: 17 },
  { id: 'RF-04', label: 'Mule/Romance scam', weight: 18 },
  { id: 'RF-05', label: 'Velocity anomaly', weight: 12 },
  { id: 'RF-06', label: 'Device mismatch', weight: 10 },
  { id: 'RF-07', label: 'IP proxy detected', weight: 8 },
  { id: 'RF-08', label: 'Address mismatch', weight: 9 },
  { id: 'RF-09', label: 'Email mismatch', weight: 7 },
  { id: 'RF-10', label: 'Phone mismatch', weight: 8 },
  { id: 'RF-11', label: 'New account', weight: 6 },
  { id: 'RF-12', label: 'High order value', weight: 11 },
  { id: 'RF-13', label: 'Multiple shipping addresses', weight: 13 },
  { id: 'RF-14', label: 'Disputed phone number', weight: 9 },
  { id: 'RF-15', label: 'Credit score anomaly', weight: 14 },
  { id: 'RF-16', label: 'Watchlist match', weight: 19 },
  { id: 'RF-17', label: 'Prior fraud history', weight: 16 },
  { id: 'RF-18', label: 'Account takeover indicators', weight: 15 },
];

export const EXTERNAL_TOOLS = [
  { name: 'GIS Lookup', uri: 'https://gis.example.com', description: 'Geographic Information System', icon: '🌍' },
  { name: 'LexisNexis', uri: 'https://lexisnexis.example.com', description: 'Identity verification', icon: '🔍' },
  { name: 'Ekata', uri: 'https://ekata.example.com', description: 'Identity verification API', icon: '✓' },
  { name: 'ID Theft Tracker', uri: 'https://idtheft.example.com', description: 'Identity theft database', icon: '🛡️' },
  { name: 'Scope', uri: 'https://scope.example.com', description: 'Investigation scope tool', icon: '🔬' },
  { name: 'SentiLink', uri: 'https://sentilink.example.com', description: 'Synthetic fraud detection', icon: '🤖' },
  { name: 'Idicore', uri: 'https://idicore.example.com', description: 'Identity data intelligence', icon: '📊' },
  { name: 'Catfish', uri: 'https://catfish.example.com', description: 'Online identity verification', icon: '🐱' },
  { name: 'FedEx/UPS Tracking', uri: 'https://tracking.example.com', description: 'Package tracking', icon: '📦' },
  { name: 'OpenCorporates', uri: 'https://opencorporates.example.com', description: 'Corporate registry', icon: '🏢' },
  { name: 'ShareFile', uri: 'https://sharefile.example.com', description: 'Document sharing', icon: '📁' },
  { name: 'Call Records', uri: 'https://callrecords.example.com', description: 'Phone call logs', icon: '📞' },
];

export const CASES = [
  {
    id: 'FPM-001', ucm_ticket_id: 'UCM-5521', order_id: 'ORD-9982',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'open',
    disposition: null, sla_status: 'at_risk', assigned_to: 'usr-001',
    customer: { name: 'John Williams', email: 'j***@email.com', phone: '***-***-1234', account: 'ACC-88901' },
    line_of_business: 'E-Commerce', risk_score: 78,
    created_at: '2026-04-28T10:30:00Z', updated_at: '2026-04-30T14:20:00Z',
    comments_count: 3, description: 'Multiple high-value orders from new device with velocity anomaly',
    linked_cases: ['FPM-005', 'FPM-012'],
    agent_insights: {
      triage: { risk_score: 78, priority: 'high', confidence: 91, flags: ['velocity', 'device_mismatch', 'new_account'] },
      verification: { phone: 'match', email: 'mismatch', address: 'match', ip: 'proxy_detected', imei: 'new_device', confidence: 72 },
      summarization: 'Customer placed 3 orders totaling $4,298 within 2 hours from a previously unseen device. Email domain differs from account registration. IP traced to known VPN provider. Shipping address matches account but billing differs.',
      decision: { recommendation: 'reject', confidence: 88, reasoning: 'High velocity pattern with device mismatch and proxy IP. Combined risk factors indicate potential account takeover or synthetic identity usage.' }
    },
    investigation_score: { selected_factors: ['RF-05', 'RF-06', 'RF-07', 'RF-08', 'RF-09', 'RF-11', 'RF-12'], score: 72 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-28T10:31:00Z', reason: 'Auto-assigned via triage' },
      { from: 'assigned', to: 'open', changed_by: 'usr-001', changed_at: '2026-04-28T11:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c1', author: 'Triage Agent', text: 'Risk score 78 - routed to investigator. Velocity and device flags detected.', created_at: '2026-04-28T10:31:00Z' },
      { id: 'c2', author: 'John Doe', text: 'Reviewing order details and customer history.', created_at: '2026-04-29T09:00:00Z' },
      { id: 'c3', author: 'Verification Agent', text: 'Email mismatch confirmed. Phone matches but IP flagged as proxy.', created_at: '2026-04-29T09:05:00Z' },
    ]
  },
  {
    id: 'FPM-002', ucm_ticket_id: 'UCM-5522', order_id: 'ORD-9983',
    ticket_type: 'credit_abuse_ordering', priority: 'medium', status: 'in_progress',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Sarah Johnson', email: 's***@gmail.com', phone: '***-***-5678', account: 'ACC-77201' },
    line_of_business: 'Retail', risk_score: 45,
    created_at: '2026-04-29T08:15:00Z', updated_at: '2026-04-30T16:45:00Z',
    comments_count: 2, description: 'Customer requesting credit for items allegedly not received',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 45, priority: 'medium', confidence: 82, flags: ['credit_history', 'repeat_claim'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 89 },
      summarization: 'Customer has filed 3 credit claims in the past 60 days. All items were marked as delivered by carrier. Address verification matches. Pattern suggests potential credit abuse.',
      decision: { recommendation: 'customer_engagement', confidence: 71, reasoning: 'Moderate risk. Customer details verify but pattern of claims warrants further engagement before decision.' }
    },
    investigation_score: { selected_factors: ['RF-15', 'RF-17'], score: 30 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-29T08:16:00Z', reason: 'Auto-assigned' },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-29T10:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c4', author: 'Triage Agent', text: 'Medium risk. Credit history pattern flagged.', created_at: '2026-04-29T08:16:00Z' },
      { id: 'c5', author: 'Jane Smith', text: 'Checking delivery confirmation with carrier.', created_at: '2026-04-29T10:30:00Z' },
    ]
  },
  {
    id: 'FPM-003', ucm_ticket_id: 'UCM-5523', order_id: 'ORD-9984',
    ticket_type: 'fraud_non_ordering', priority: 'low', status: 'assigned',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Robert Chen', email: 'r***@outlook.com', phone: '***-***-9012', account: 'ACC-55302' },
    line_of_business: 'Wireless', risk_score: 22,
    created_at: '2026-04-30T14:20:00Z', updated_at: '2026-04-30T14:20:00Z',
    comments_count: 1, description: 'Account information change request flagged for review',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 22, priority: 'low', confidence: 94, flags: ['info_change'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 95 },
      summarization: 'Customer requested email and phone number change. All current verification points match. Low risk - appears to be legitimate account maintenance.',
      decision: { recommendation: 'approve', confidence: 94, reasoning: 'All verification points match. No risk indicators. Routine account change request.' }
    },
    investigation_score: { selected_factors: [], score: 0 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T14:21:00Z', reason: 'Auto-assigned' },
    ],
    comments: [
      { id: 'c6', author: 'Triage Agent', text: 'Low risk score 22. Auto-approve candidate.', created_at: '2026-04-30T14:21:00Z' },
    ]
  },
  {
    id: 'FPM-004', ucm_ticket_id: 'UCM-5518', order_id: 'ORD-9978',
    ticket_type: 'fraud_ordering', priority: 'critical', status: 'escalated',
    disposition: null, sla_status: 'breached', assigned_to: 'usr-001',
    customer: { name: 'Alex Thompson', email: 'a***@yahoo.com', phone: '***-***-3456', account: 'ACC-44103' },
    line_of_business: 'E-Commerce', risk_score: 92,
    created_at: '2026-04-22T09:00:00Z', updated_at: '2026-04-28T11:00:00Z',
    comments_count: 7, description: 'Suspected synthetic identity with multiple high-value orders',
    linked_cases: ['FPM-007', 'FPM-008', 'FPM-015'],
    agent_insights: {
      triage: { risk_score: 92, priority: 'critical', confidence: 96, flags: ['synthetic_id', 'velocity', 'watchlist', 'deceased_ssn'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'proxy_detected', imei: 'new_device', confidence: 34 },
      summarization: 'Strong indicators of synthetic identity. SSN associated with deceased individual. Multiple orders to different addresses within 24 hours. Phone number linked to known fraud ring. All verification points fail.',
      decision: { recommendation: 'reject', confidence: 97, reasoning: 'Critical risk. Synthetic identity confirmed. Deceased SSN, watchlist match, complete verification failure. Immediate rejection recommended.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-03', 'RF-05', 'RF-06', 'RF-07', 'RF-08', 'RF-09', 'RF-10', 'RF-13', 'RF-16', 'RF-17', 'RF-18'], score: 91 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-22T09:01:00Z', reason: 'Critical priority' },
      { from: 'assigned', to: 'open', changed_by: 'usr-001', changed_at: '2026-04-22T10:00:00Z', reason: null },
      { from: 'open', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-22T10:30:00Z', reason: null },
      { from: 'in_progress', to: 'escalated', changed_by: 'usr-001', changed_at: '2026-04-24T09:00:00Z', reason: 'Suspected fraud ring - needs supervisor review' },
    ],
    comments: [
      { id: 'c7', author: 'Triage Agent', text: 'CRITICAL: Score 92. Synthetic ID + deceased SSN + watchlist.', created_at: '2026-04-22T09:01:00Z' },
      { id: 'c8', author: 'John Doe', text: 'Confirmed synthetic ID indicators. Escalating.', created_at: '2026-04-24T09:00:00Z' },
    ]
  },
  {
    id: 'FPM-005', ucm_ticket_id: 'UCM-5524', order_id: 'ORD-9985',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Maria Garcia', email: 'm***@hotmail.com', phone: '***-***-7890', account: 'ACC-66204' },
    line_of_business: 'E-Commerce', risk_score: 67,
    created_at: '2026-04-30T16:00:00Z', updated_at: '2026-04-30T18:30:00Z',
    comments_count: 2, description: 'Order placed with mismatched billing and shipping addresses',
    linked_cases: ['FPM-001'],
    agent_insights: {
      triage: { risk_score: 67, priority: 'high', confidence: 79, flags: ['address_mismatch', 'high_value', 'new_account'] },
      verification: { phone: 'match', email: 'partial', address: 'mismatch', ip: 'clean', imei: 'known_device', confidence: 61 },
      summarization: 'New account (7 days old) with first order exceeding $2,000. Billing address is in a different state than shipping. Email domain partial match. Phone verified.',
      decision: { recommendation: 'customer_engagement', confidence: 65, reasoning: 'Mixed signals. New account with high value but phone verified. Address mismatch needs customer confirmation.' }
    },
    investigation_score: { selected_factors: ['RF-08', 'RF-11', 'RF-12'], score: 26 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T16:01:00Z', reason: 'Auto-assigned' },
      { from: 'assigned', to: 'open', changed_by: 'usr-002', changed_at: '2026-04-30T17:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c9', author: 'Triage Agent', text: 'High risk. Address mismatch with high-value order on new account.', created_at: '2026-04-30T16:01:00Z' },
      { id: 'c10', author: 'Jane Smith', text: 'Attempting customer contact for address verification.', created_at: '2026-04-30T18:00:00Z' },
    ]
  },
  {
    id: 'FPM-006', ucm_ticket_id: 'UCM-5510', order_id: 'ORD-9970',
    ticket_type: 'credit_abuse_sor', priority: 'medium', status: 'resolved',
    disposition: 'fraud_found', sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'David Brown', email: 'd***@gmail.com', phone: '***-***-2345', account: 'ACC-33105' },
    line_of_business: 'Retail', risk_score: 55,
    created_at: '2026-04-20T11:00:00Z', updated_at: '2026-04-25T15:30:00Z',
    comments_count: 5, description: 'Repeated SOR claims with pattern matching known fraud scheme',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 55, priority: 'medium', confidence: 85, flags: ['repeat_claim', 'pattern_match'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 88 },
      summarization: 'Customer filed 5 SOR claims in 90 days. Pattern matches known "item not received" scheme. Carrier confirms delivery on all orders. Customer identity verified.',
      decision: { recommendation: 'reject', confidence: 82, reasoning: 'Repeated claims despite carrier confirmation. Pattern matches known fraud scheme.' }
    },
    investigation_score: { selected_factors: ['RF-15', 'RF-17'], score: 30 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-20T11:01:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-21T09:00:00Z', reason: null },
      { from: 'in_progress', to: 'resolved', changed_by: 'usr-002', changed_at: '2026-04-25T15:30:00Z', reason: 'Fraud confirmed' },
    ],
    comments: [
      { id: 'c11', author: 'Jane Smith', text: 'Fraud confirmed. Disposition: fraud_found.', created_at: '2026-04-25T15:30:00Z' },
    ]
  },
  {
    id: 'FPM-007', ucm_ticket_id: 'UCM-5515', order_id: 'ORD-9975',
    ticket_type: 'fraud_ordering', priority: 'critical', status: 'in_progress',
    disposition: null, sla_status: 'at_risk', assigned_to: 'usr-001',
    customer: { name: 'Emily Davis', email: 'e***@proton.me', phone: '***-***-6789', account: 'ACC-99006' },
    line_of_business: 'Electronics', risk_score: 85,
    created_at: '2026-04-26T07:30:00Z', updated_at: '2026-04-30T12:00:00Z',
    comments_count: 4, description: 'High-value electronics order with multiple fraud indicators',
    linked_cases: ['FPM-004'],
    agent_insights: {
      triage: { risk_score: 85, priority: 'critical', confidence: 89, flags: ['high_value', 'velocity', 'proxy_ip', 'new_device'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'partial', ip: 'proxy_detected', imei: 'new_device', confidence: 42 },
      summarization: 'Order for $5,200 in electronics. New device, proxy IP, email from privacy-focused provider. Multiple orders within short timeframe. Possible link to fraud ring FPM-004.',
      decision: { recommendation: 'reject', confidence: 91, reasoning: 'High value + new device + proxy IP + verification failures. Strong fraud indicators.' }
    },
    investigation_score: { selected_factors: ['RF-05', 'RF-06', 'RF-07', 'RF-09', 'RF-10', 'RF-12', 'RF-13'], score: 68 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-26T07:31:00Z', reason: 'Critical auto-assign' },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-26T09:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c12', author: 'Triage Agent', text: 'Critical risk. Electronics fraud pattern.', created_at: '2026-04-26T07:31:00Z' },
      { id: 'c13', author: 'John Doe', text: 'Investigating connection to FPM-004 ring.', created_at: '2026-04-27T11:00:00Z' },
    ]
  },
  {
    id: 'FPM-008', ucm_ticket_id: 'UCM-5516', order_id: 'ORD-9976',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'resolved',
    disposition: 'reject', sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Kevin Martinez', email: 'k***@temp.com', phone: '***-***-0123', account: 'ACC-11207' },
    line_of_business: 'E-Commerce', risk_score: 73,
    created_at: '2026-04-24T13:00:00Z', updated_at: '2026-04-27T10:00:00Z',
    comments_count: 4, description: 'Temporary email domain with mismatched verification data',
    linked_cases: ['FPM-004'],
    agent_insights: {
      triage: { risk_score: 73, priority: 'high', confidence: 87, flags: ['temp_email', 'verification_fail', 'linked_ring'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'proxy_detected', imei: 'new_device', confidence: 28 },
      summarization: 'Temporary email domain. All verification points fail. Connected to suspected fraud ring via shared shipping address with FPM-004.',
      decision: { recommendation: 'reject', confidence: 95, reasoning: 'Complete verification failure + fraud ring connection. Clear reject.' }
    },
    investigation_score: { selected_factors: ['RF-03', 'RF-06', 'RF-07', 'RF-08', 'RF-09', 'RF-10', 'RF-13', 'RF-16'], score: 78 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-24T13:01:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-25T08:00:00Z', reason: null },
      { from: 'in_progress', to: 'resolved', changed_by: 'usr-001', changed_at: '2026-04-27T10:00:00Z', reason: 'Rejected - fraud ring confirmed' },
    ],
    comments: [
      { id: 'c14', author: 'John Doe', text: 'Rejected. Part of fraud ring with FPM-004.', created_at: '2026-04-27T10:00:00Z' },
    ]
  },
  {
    id: 'FPM-009', ucm_ticket_id: 'UCM-5525', order_id: 'ORD-9986',
    ticket_type: 'credit_abuse_appeal', priority: 'low', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Lisa Anderson', email: 'l***@yahoo.com', phone: '***-***-4567', account: 'ACC-22308' },
    line_of_business: 'Retail', risk_score: 18,
    created_at: '2026-04-30T20:00:00Z', updated_at: '2026-05-01T08:00:00Z',
    comments_count: 1, description: 'Credit denial appeal - customer disputes decision',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 18, priority: 'low', confidence: 92, flags: [] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 97 },
      summarization: 'Customer appealing previous credit denial. Long-standing account (3 years). All verification passes. No fraud indicators. Likely legitimate appeal.',
      decision: { recommendation: 'approve', confidence: 92, reasoning: 'Clean verification, established customer, no risk flags. Approve the appeal.' }
    },
    investigation_score: { selected_factors: [], score: 0 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T20:01:00Z', reason: null },
      { from: 'assigned', to: 'open', changed_by: 'usr-002', changed_at: '2026-05-01T08:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c15', author: 'Triage Agent', text: 'Low risk. Auto-approve candidate - awaiting investigator confirmation.', created_at: '2026-04-30T20:01:00Z' },
    ]
  },
  {
    id: 'FPM-010', ucm_ticket_id: 'UCM-5512', order_id: 'ORD-9972',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'pending_customer',
    disposition: 'customer_engagement', sla_status: 'at_risk', assigned_to: 'usr-002',
    customer: { name: 'Chris Taylor', email: 'c***@icloud.com', phone: '***-***-8901', account: 'ACC-77509' },
    line_of_business: 'E-Commerce', risk_score: 61,
    created_at: '2026-04-25T15:30:00Z', updated_at: '2026-04-29T09:00:00Z',
    comments_count: 3, description: 'Awaiting customer response for address verification',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 61, priority: 'high', confidence: 76, flags: ['address_mismatch', 'new_shipping'] },
      verification: { phone: 'match', email: 'match', address: 'mismatch', ip: 'clean', imei: 'known_device', confidence: 68 },
      summarization: 'Order shipped to new address not on file. Customer account is 2 years old with clean history. Phone and email verify. Likely legitimate but needs address confirmation.',
      decision: { recommendation: 'customer_engagement', confidence: 78, reasoning: 'Established customer with new shipping address. Contact customer to verify before approving.' }
    },
    investigation_score: { selected_factors: ['RF-08', 'RF-13'], score: 22 },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-25T15:31:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-26T08:00:00Z', reason: null },
      { from: 'in_progress', to: 'pending_customer', changed_by: 'usr-002', changed_at: '2026-04-27T14:00:00Z', reason: 'Awaiting customer address verification' },
    ],
    comments: [
      { id: 'c16', author: 'Jane Smith', text: 'Customer contacted via email for address verification. Awaiting response.', created_at: '2026-04-27T14:00:00Z' },
    ]
  },
];

export const ORDERS = [
  { order_id: 'ORD-9982', case_id: 'FPM-001', customer: 'John Williams', channel: 'Web', amount: 1299.99, items: 3, ship_address: '123 Main St, Dallas TX', status: 'Processing', created_at: '2026-04-28', risk_flags: ['velocity', 'new_device'] },
  { order_id: 'ORD-9981', case_id: 'FPM-001', customer: 'John Williams', channel: 'Web', amount: 899.00, items: 2, ship_address: '123 Main St, Dallas TX', status: 'Processing', created_at: '2026-04-28', risk_flags: ['velocity'] },
  { order_id: 'ORD-9979', case_id: 'FPM-001', customer: 'John Williams', channel: 'Mobile', amount: 2100.00, items: 5, ship_address: '456 Oak Ave, Dallas TX', status: 'Processing', created_at: '2026-04-28', risk_flags: ['addr_mismatch'] },
  { order_id: 'ORD-9983', case_id: 'FPM-002', customer: 'Sarah Johnson', channel: 'Web', amount: 450.00, items: 2, ship_address: '789 Pine Rd, Austin TX', status: 'Delivered', created_at: '2026-04-29', risk_flags: ['repeat_claim'] },
  { order_id: 'ORD-9984', case_id: 'FPM-003', customer: 'Robert Chen', channel: 'Store', amount: 0, items: 0, ship_address: 'N/A', status: 'N/A', created_at: '2026-04-30', risk_flags: [] },
  { order_id: 'ORD-9978', case_id: 'FPM-004', customer: 'Alex Thompson', channel: 'Web', amount: 3500.00, items: 4, ship_address: '999 Elm St, Miami FL', status: 'Held', created_at: '2026-04-22', risk_flags: ['synthetic_id', 'velocity', 'watchlist'] },
  { order_id: 'ORD-9977', case_id: 'FPM-004', customer: 'Alex Thompson', channel: 'Web', amount: 2800.00, items: 3, ship_address: '111 Birch Ln, Miami FL', status: 'Held', created_at: '2026-04-22', risk_flags: ['multi_address', 'velocity'] },
  { order_id: 'ORD-9985', case_id: 'FPM-005', customer: 'Maria Garcia', channel: 'Web', amount: 2100.00, items: 1, ship_address: '222 Cedar Dr, Phoenix AZ', status: 'Processing', created_at: '2026-04-30', risk_flags: ['addr_mismatch', 'high_value'] },
  { order_id: 'ORD-9970', case_id: 'FPM-006', customer: 'David Brown', channel: 'Web', amount: 320.00, items: 1, ship_address: '333 Maple St, Seattle WA', status: 'Delivered', created_at: '2026-04-20', risk_flags: ['repeat_claim'] },
  { order_id: 'ORD-9975', case_id: 'FPM-007', customer: 'Emily Davis', channel: 'Web', amount: 5200.00, items: 2, ship_address: '444 Walnut Ave, Chicago IL', status: 'Held', created_at: '2026-04-26', risk_flags: ['high_value', 'proxy_ip'] },
  { order_id: 'ORD-9976', case_id: 'FPM-008', customer: 'Kevin Martinez', channel: 'Web', amount: 1800.00, items: 2, ship_address: '999 Elm St, Miami FL', status: 'Canceled', created_at: '2026-04-24', risk_flags: ['shared_address', 'temp_email'] },
  { order_id: 'ORD-9986', case_id: 'FPM-009', customer: 'Lisa Anderson', channel: 'Store', amount: 150.00, items: 1, ship_address: '555 Oak Ln, Portland OR', status: 'Delivered', created_at: '2026-04-30', risk_flags: [] },
  { order_id: 'ORD-9972', case_id: 'FPM-010', customer: 'Chris Taylor', channel: 'Web', amount: 780.00, items: 3, ship_address: '666 Spruce Ct, Denver CO', status: 'Processing', created_at: '2026-04-25', risk_flags: ['new_address'] },
];

export const FRAUD_MAP_DATA = {
  states: [
    { state: 'CA', name: 'California', fraud_impact: 234, confirmed: 89, zip_count: 45, top_zips: ['90210', '90001', '94102'] },
    { state: 'TX', name: 'Texas', fraud_impact: 189, confirmed: 72, zip_count: 38, top_zips: ['75201', '77001', '73301'] },
    { state: 'FL', name: 'Florida', fraud_impact: 156, confirmed: 61, zip_count: 32, top_zips: ['33101', '32801', '33301'] },
    { state: 'NY', name: 'New York', fraud_impact: 142, confirmed: 55, zip_count: 28, top_zips: ['10001', '10010', '11201'] },
    { state: 'IL', name: 'Illinois', fraud_impact: 98, confirmed: 38, zip_count: 20, top_zips: ['60601', '60611', '60614'] },
    { state: 'PA', name: 'Pennsylvania', fraud_impact: 76, confirmed: 29, zip_count: 15, top_zips: ['19101', '15201', '18101'] },
    { state: 'OH', name: 'Ohio', fraud_impact: 65, confirmed: 24, zip_count: 13, top_zips: ['43201', '44101', '45201'] },
    { state: 'GA', name: 'Georgia', fraud_impact: 58, confirmed: 22, zip_count: 11, top_zips: ['30301', '30901', '31401'] },
    { state: 'AZ', name: 'Arizona', fraud_impact: 52, confirmed: 19, zip_count: 10, top_zips: ['85001', '85201', '86001'] },
    { state: 'NV', name: 'Nevada', fraud_impact: 47, confirmed: 18, zip_count: 8, top_zips: ['89101', '89501', '89001'] },
    { state: 'WA', name: 'Washington', fraud_impact: 41, confirmed: 15, zip_count: 9, top_zips: ['98101', '98201', '99201'] },
    { state: 'CO', name: 'Colorado', fraud_impact: 35, confirmed: 13, zip_count: 7, top_zips: ['80201', '80301', '80901'] },
  ],
  fraud_rings: [
    { id: 'FR-042', nodes: 8, edges: 12, shared: ['email', 'phone'], zips: ['90210', '90211', '90212'], cities: ['Los Angeles', 'Beverly Hills'], risk_level: 'critical' },
    { id: 'FR-038', nodes: 5, edges: 7, shared: ['address', 'phone'], zips: ['33101', '33102'], cities: ['Miami'], risk_level: 'high' },
    { id: 'FR-041', nodes: 6, edges: 9, shared: ['email', 'address'], zips: ['75201', '75202', '75203'], cities: ['Dallas'], risk_level: 'high' },
    { id: 'FR-035', nodes: 4, edges: 5, shared: ['phone'], zips: ['60601', '60611'], cities: ['Chicago'], risk_level: 'medium' },
    { id: 'FR-039', nodes: 7, edges: 11, shared: ['email', 'phone', 'address'], zips: ['10001', '10010', '10011'], cities: ['New York'], risk_level: 'critical' },
  ]
};

export const SLA_RULES = [
  { ticket_type: 'fraud_ordering', threshold_hours: 144, label: 'Fraud Ordering' },
  { ticket_type: 'fraud_non_ordering', threshold_hours: 144, label: 'Fraud Non-Ordering' },
  { ticket_type: 'credit_abuse_ordering', threshold_hours: 144, label: 'Credit Abuse Ordering' },
  { ticket_type: 'credit_abuse_sor', threshold_hours: 144, label: 'Credit Abuse SOR' },
  { ticket_type: 'credit_abuse_appeal', threshold_hours: 96, label: 'Credit Abuse Appeal' },
  { ticket_type: 'general', threshold_hours: 72, label: 'General' },
];

export const FEEDBACK_METRICS = {
  total_decisions: 1589,
  ai_accuracy: 87.3,
  override_rate: 12.7,
  accept_rate: 87.3,
  by_disposition: {
    approve: { total: 820, correct: 756, accuracy: 92.2 },
    reject: { total: 412, correct: 348, accuracy: 84.5 },
    customer_engagement: { total: 198, correct: 152, accuracy: 76.8 },
    cannot_determine: { total: 89, correct: 62, accuracy: 69.7 },
    fraud_found: { total: 70, correct: 66, accuracy: 94.3 },
  },
  by_risk_band: {
    low: { range: '0-30', total: 523, correct: 489, accuracy: 93.5 },
    medium: { range: '31-60', total: 612, correct: 498, accuracy: 81.4 },
    high: { range: '61-100', total: 454, correct: 401, accuracy: 88.3 },
  },
  common_overrides: [
    'Customer engagement → Approve (long-standing customer)',
    'Reject → Customer engagement (partial verification)',
    'Cannot determine → Approve (additional docs provided)',
  ]
};

export const NLP_QUERY_TEMPLATES = [
  { label: 'Orders by state last 30 days', query: 'Show all orders grouped by state in the last 30 days' },
  { label: 'High-value orders > $1000', query: 'Show orders with amount greater than $1000' },
  { label: 'Orders with velocity flags', query: 'Show orders that have velocity risk flags' },
  { label: 'Customer order history', query: 'Show order history for the current case customer' },
  { label: 'Device match failures', query: 'Show orders where device verification failed' },
  { label: 'Channel distribution', query: 'Show order count by sales channel' },
];

export const AUDIT_TRAIL_SAMPLE = [
  { id: 'AT-001', case_id: 'FPM-001', action: 'case_created', actor: 'UCM_Poller', timestamp: '2026-04-28T10:30:00Z', details: 'Ingested from UCM ticket UCM-5521' },
  { id: 'AT-002', case_id: 'FPM-001', action: 'ai_decision', actor: 'Triage Agent', timestamp: '2026-04-28T10:30:05Z', details: 'Risk score: 78, Priority: HIGH' },
  { id: 'AT-003', case_id: 'FPM-001', action: 'data_collection', actor: 'Data Collection Agent', timestamp: '2026-04-28T10:30:10Z', details: 'Gathered data from 15 sources via MCP' },
  { id: 'AT-004', case_id: 'FPM-001', action: 'pii_masking', actor: 'PII Masker', timestamp: '2026-04-28T10:30:12Z', details: 'Masked SSN, phone, address for LLM processing' },
  { id: 'AT-005', case_id: 'FPM-001', action: 'verification', actor: 'Verification Agent', timestamp: '2026-04-28T10:30:15Z', details: 'Cross-reference complete. Email mismatch detected.' },
  { id: 'AT-006', case_id: 'FPM-001', action: 'auto_assignment', actor: 'Orchestrator Agent', timestamp: '2026-04-28T10:31:00Z', details: 'Assigned to John Doe (investigator)' },
  { id: 'AT-007', case_id: 'FPM-001', action: 'status_change', actor: 'John Doe', timestamp: '2026-04-28T11:00:00Z', details: 'Status: assigned → open' },
  { id: 'AT-008', case_id: 'FPM-001', action: 'nlp_query', actor: 'John Doe', timestamp: '2026-04-29T09:15:00Z', details: 'Query: "show recent orders for this customer"' },
  { id: 'AT-009', case_id: 'FPM-001', action: 'confidence_gate_block', actor: 'Confidence Gate', timestamp: '2026-04-28T10:30:08Z', details: 'Auto-reject blocked: confidence 72% below threshold 85%' },
  { id: 'AT-010', case_id: 'FPM-002', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-05-01T08:00:00Z', details: 'SLA breached: case open >24h for HIGH priority (threshold: 24h)' },
  { id: 'AT-011', case_id: 'FPM-003', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-05-02T12:00:00Z', details: 'SLA breached: case open >48h for MEDIUM priority (threshold: 48h)' },
  { id: 'AT-012', case_id: 'FPM-005', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-05-03T06:00:00Z', details: 'SLA breached: case open >12h for CRITICAL priority (threshold: 12h)' },
  { id: 'AT-013', case_id: 'FPM-002', action: 'confidence_gate_pass', actor: 'Confidence Gate', timestamp: '2026-04-29T14:00:05Z', details: 'Auto-decision eligible: confidence 91% meets threshold 85%' },
  { id: 'AT-014', case_id: 'FPM-004', action: 'pipeline_push', actor: 'Orchestrator Agent', timestamp: '2026-05-01T16:30:00Z', details: 'Disposition "approve" pushed to Order Control, Mobile IT, UCM' },
];
