import React from 'react';

export default function KPICard({ title, value, color }) {
  return (
    <div
      className="kpi-card"
      style={{
        borderTop: `3.5px solid ${color}`,
      }}
    >
      <div className="kpi-content">
        <div className="kpi-value" style={{ color }}>{value}</div>
        <div className="kpi-title">{title}</div>
      </div>
    </div>
  );
}
