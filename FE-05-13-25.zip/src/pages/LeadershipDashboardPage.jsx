import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';
import { LEADERSHIP_METRICS, ORDER_ANALYTICS, FRAUD_TREND, FRAUD_MAP_DATA, FEEDBACK_METRICS } from '../data/dummyData';
import KPICard from '../components/KPICard';
import USAMap from '../components/USAMap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, ComposedChart, Line, LabelList, ResponsiveContainer, Legend, AreaChart, Area } from 'recharts';

export default function LeadershipDashboardPage() {
  const { user } = useAuth();
  const { cases, setFilters } = useCases();
  const navigate = useNavigate();
  const [granularity, setGranularity] = useState('monthly');
  const [dateFilter, setDateFilter] = useState('all');

  const myCases = cases;

  const filteredCases = useMemo(() => {
    if (dateFilter === 'all') return myCases;
    const now = new Date();
    const months = parseInt(dateFilter);
    const fromDate = new Date(now.getFullYear(), now.getMonth() - months, now.getDate());
    return myCases.filter(c => new Date(c.created_at) >= fromDate);
  }, [myCases, dateFilter]);

  const openCases = filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status)).length;
  const resolvedCases = filteredCases.filter(c => c.status === 'resolved').length;
  const escalatedCases = filteredCases.filter(c => c.status === 'escalated').length;
  const slaBreach = filteredCases.filter(c => c.sla_status === 'breached').length;
  const fraudCases = filteredCases.filter(c => c.ticket_type.includes('fraud'));
  const highRiskAlerts = filteredCases.filter(c => c.risk_score >= 80).length;

  const orderData = ORDER_ANALYTICS[granularity] || [];
  const fraudTrendData = FRAUD_TREND[granularity] || [];
  const totalOrdersSum = orderData.reduce((s, d) => s + d.total_orders, 0);
  const closedSum = orderData.reduce((s, d) => s + d.closed, 0);
  const escalatedSum = orderData.reduce((s, d) => s + d.escalated, 0);
  const pendingSum = orderData.reduce((s, d) => s + d.pending, 0);
  const closedPctOA = totalOrdersSum ? Math.round((closedSum / totalOrdersSum) * 100) : 0;
  const escalatedPctOA = totalOrdersSum ? Math.round((escalatedSum / totalOrdersSum) * 100) : 0;
  const pendingPctOA = totalOrdersSum ? 100 - closedPctOA - escalatedPctOA : 0;

  const states = FRAUD_MAP_DATA.states;
  const maxImpact = Math.max(...states.map(s => s.fraud_impact));

  const REGION_MAP = {
    West: ['CA','WA','OR','NV','UT','CO','ID','MT','WY','HI','AK','AZ','NM'],
    South: ['TX','FL','GA','NC','VA','TN','SC','AL','LA','KY','OK','MS','AR','WV','MD','DE'],
    Northeast: ['NY','PA','NJ','MA','CT','RI','VT','NH','ME'],
    Midwest: ['IL','OH','MI','IN','MO','WI','MN','IA','KS','NE','SD','ND'],
  };
  const REGION_COLORS = { West: '#3b82f6', South: '#ef4444', Northeast: '#f59e0b', Midwest: '#22c55e' };
  const stateToRegion = {};
  Object.entries(REGION_MAP).forEach(([region, codes]) => codes.forEach(c => { stateToRegion[c] = region; }));
  const regionStats = Object.entries(REGION_MAP).map(([region, codes]) => {
    const rs = states.filter(s => codes.includes(s.state));
    return { region, impact: rs.reduce((a, s) => a + s.fraud_impact, 0), confirmed: rs.reduce((a, s) => a + s.confirmed, 0), states: rs.length, color: REGION_COLORS[region] };
  }).sort((a, b) => b.impact - a.impact);

  const getRegionColor = (impact, stateAbbr) => {
    const region = stateToRegion[stateAbbr];
    return region ? REGION_COLORS[region] : '#e0e0e0';
  };

  const openVsResolvedData = [
    { name: 'Open', value: openCases, color: '#6366f1' },
    { name: 'Resolved', value: resolvedCases, color: '#10b981' },
  ];
  const totalCaseCount = openCases + resolvedCases;
  const openPct = totalCaseCount ? Math.round((openCases / totalCaseCount) * 100) : 0;
  const resolvedPct = totalCaseCount ? 100 - openPct : 0;

  const navigateWithFilter = (filterKey, filterValue) => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '', [filterKey]: filterValue });
    navigate('/cases');
  };

  return (
    <div className="leadership-page">
      {/* Header */}
      <div className="leadership-header">
        <h2>Leadership Analytics</h2>
        <div className="leadership-controls">
          <select className="granularity-select" value={dateFilter} onChange={e => setDateFilter(e.target.value)}>
            <option value="all">All Time</option>
            <option value="1">Last 1 Month</option>
            <option value="3">Last 3 Months</option>
            <option value="6">Last 6 Months</option>
          </select>
          <select className="granularity-select" value={granularity} onChange={e => setGranularity(e.target.value)}>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid leadership-kpi-grid">
        <div onClick={() => navigateWithFilter('ticket_type', 'fraud_ordering')} style={{ cursor: 'pointer' }}>
          <KPICard title="Total Fraud Cases" value={fraudCases.length} color="#c62828" />
        </div>
        <KPICard title="Fraud Loss Prevented" value={`$${(LEADERSHIP_METRICS.fraud_loss_prevented / 1000000).toFixed(1)}M`} color="#2e7d32" />
        <KPICard title="AI Detection Accuracy" value={`${LEADERSHIP_METRICS.ai_detection_accuracy}%`} color="#1565c0" />
        <KPICard title="Fraud Trend" value={`+${LEADERSHIP_METRICS.fraud_trend_delta}%`} color="#e65100" />
        <KPICard title="Open vs Resolved" value={`${openCases} / ${resolvedCases}`} color="#7b1fa2" />
        <div onClick={() => navigate('/sla-monitor')} style={{ cursor: 'pointer' }}>
          <KPICard title="SLA Breaches" value={LEADERSHIP_METRICS.sla_breaches_total} color="#d84315" />
        </div>
        <KPICard title="High-Risk Alerts" value={highRiskAlerts} color="#ad1457" />
        <KPICard title="Total Orders" value={totalOrdersSum.toLocaleString()} color="#00838f" />
      </div>

      {/* Charts Row 1: Fraud Trend + Order Analytics */}
      <div className="leadership-charts-row">
        <div className="chart-card ld-fraud-trend-card">
          <h3>Fraud Trend <span className="info-tooltip-wrap" data-tooltip="Fraud cases, loss amount and detection rate over time">&#9432;</span></h3>
          <div className="ld-ft-summary">
            <div className="ld-ft-chip">
              <span className="ld-ft-chip-dot" style={{ background: '#8b5cf6' }}></span>
              <span className="ld-ft-chip-label">Avg Detection</span>
              <span className="ld-ft-chip-val">{(fraudTrendData.reduce((s, d) => s + d.detection_rate, 0) / (fraudTrendData.length || 1)).toFixed(1)}%</span>
            </div>
            <div className="ld-ft-chip">
              <span className="ld-ft-chip-dot" style={{ background: '#f43f5e' }}></span>
              <span className="ld-ft-chip-label">Total Cases</span>
              <span className="ld-ft-chip-val">{fraudTrendData.reduce((s, d) => s + d.fraud_cases, 0)}</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={270}>
            <ComposedChart data={fraudTrendData.map(d => ({ ...d, loss_k: Math.round(d.loss_amount / 1000) }))} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="5 5" stroke="rgba(0,0,0,0.06)" vertical={true} horizontal={true} />
              <XAxis dataKey="period" fontSize={10} tick={{ fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fill: '#94a3b8', fontSize: 10 }} axisLine={false} tickLine={false} width={30} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#94a3b8', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} width={35} domain={[80, 100]} />
              <Tooltip cursor={{ stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '4 4' }} contentStyle={{ background: '#fff', border: 'none', borderRadius: '12px', boxShadow: '0 8px 30px rgba(0,0,0,0.12)', padding: '10px 14px', fontSize: '0.78rem' }} />
              <Legend wrapperStyle={{ fontSize: '0.72rem', paddingTop: 8 }} iconType="circle" iconSize={8} />
              <Line yAxisId="left" type="monotone" dataKey="fraud_cases" stroke="#f43f5e" strokeWidth={2.5} name="Fraud Cases" dot={false} activeDot={{ r: 5, fill: '#f43f5e', stroke: '#fff', strokeWidth: 2 }} />
              <Line yAxisId="left" type="monotone" dataKey="loss_k" stroke="#10b981" strokeWidth={2.5} name="Loss ($K)" dot={false} activeDot={{ r: 5, fill: '#10b981', stroke: '#fff', strokeWidth: 2 }} />
              <Line yAxisId="right" type="monotone" dataKey="detection_rate" stroke="#8b5cf6" strokeWidth={2.5} name="Detection %" dot={false} activeDot={{ r: 5, fill: '#8b5cf6', stroke: '#fff', strokeWidth: 2 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card ld-oa-card">
          <h3>Order Analytics <span className="info-tooltip-wrap" data-tooltip="Breakdown of closed, escalated & pending orders across all regions">&#9432;</span></h3>

          <div className="ld-oa-stats">
            <div className="ld-oa-stat">
              <span className="ld-oa-dot" style={{ background: '#10b981' }}></span>
              <span className="ld-oa-stat-val">{closedSum.toLocaleString()}</span>
              <span className="ld-oa-stat-label">Closed</span>
              <span className="ld-oa-stat-pct">{closedPctOA}%</span>
            </div>
            <div className="ld-oa-stat">
              <span className="ld-oa-dot" style={{ background: '#ef4444' }}></span>
              <span className="ld-oa-stat-val">{escalatedSum.toLocaleString()}</span>
              <span className="ld-oa-stat-label">Escalated</span>
              <span className="ld-oa-stat-pct">{escalatedPctOA}%</span>
            </div>
            <div className="ld-oa-stat">
              <span className="ld-oa-dot" style={{ background: '#f59e0b' }}></span>
              <span className="ld-oa-stat-val">{pendingSum.toLocaleString()}</span>
              <span className="ld-oa-stat-label">Pending</span>
              <span className="ld-oa-stat-pct">{pendingPctOA}%</span>
            </div>
          </div>

          <ResponsiveContainer width="100%" height={270}>
            <AreaChart data={orderData.map(({ period, closed, escalated, pending }) => ({ period, closed, escalated, pending }))} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
              <defs>
                <linearGradient id="gradClosed" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="gradEscalated" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef5350" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#ef5350" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="gradPending" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#fbbf24" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
              <XAxis dataKey="period" fontSize={10} tick={{ fill: '#37474f' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#37474f', fontSize: 10 }} axisLine={false} tickLine={false} width={35} />
              <Tooltip cursor={{ stroke: '#e0e0e0', strokeDasharray: '4 4' }} contentStyle={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} />
              <Legend wrapperStyle={{ fontSize: '0.72rem', paddingTop: 8 }} iconType="circle" iconSize={7} />
              <Area type="monotone" dataKey="closed" stackId="1" stroke="#2dd4bf" strokeWidth={2.5} fill="url(#gradClosed)" name="Closed" dot={{ fill: '#fff', stroke: '#2dd4bf', strokeWidth: 2, r: 3 }} activeDot={{ r: 5, fill: '#2dd4bf' }} />
              <Area type="monotone" dataKey="escalated" stackId="1" stroke="#ef5350" strokeWidth={2.5} fill="url(#gradEscalated)" name="Escalated" dot={{ fill: '#fff', stroke: '#ef5350', strokeWidth: 2, r: 3 }} activeDot={{ r: 5, fill: '#ef5350' }} />
              <Area type="monotone" dataKey="pending" stackId="1" stroke="#fbbf24" strokeWidth={2.5} fill="url(#gradPending)" name="Pending" dot={{ fill: '#fff', stroke: '#fbbf24', strokeWidth: 2, r: 3 }} activeDot={{ r: 5, fill: '#fbbf24' }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2: Open vs Resolved + Fraud by Region Heatmap */}
      <div className="leadership-charts-row">
        <div className="chart-card ld-ovr-card">
          <h3>Open vs Resolved Cases <span className="info-tooltip-wrap" data-tooltip="Donut chart showing ratio of currently open cases to resolved cases">&#9432;</span></h3>
          <div className="ld-ovr-layout">
            <div className="ld-ovr-donut-wrap">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <defs>
                    <linearGradient id="gradOpen" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#818cf8" />
                      <stop offset="100%" stopColor="#6366f1" />
                    </linearGradient>
                    <linearGradient id="gradResolved" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#34d399" />
                      <stop offset="100%" stopColor="#10b981" />
                    </linearGradient>
                  </defs>
                  <Pie
                    data={openVsResolvedData}
                    cx="50%" cy="50%"
                    innerRadius="58%" outerRadius="85%"
                    dataKey="value"
                    stroke="none"
                    cornerRadius={6}
                    paddingAngle={4}
                    isAnimationActive={false}
                  >
                    <Cell fill="url(#gradOpen)" />
                    <Cell fill="url(#gradResolved)" />
                  </Pie>
                  <Tooltip contentStyle={{ background: '#fff', border: 'none', borderRadius: '10px', boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="ld-ovr-center">
                <span className="ld-ovr-center-val">{totalCaseCount}</span>
                <span className="ld-ovr-center-lbl">Total</span>
              </div>
            </div>
            <div className="ld-ovr-stats">
              <div className="ld-ovr-stat-card ld-ovr-open">
                <div className="ld-ovr-dot" style={{ background: '#6366f1' }}></div>
                <div className="ld-ovr-stat-body">
                  <span className="ld-ovr-stat-name">Open</span>
                  <span className="ld-ovr-stat-val">{openCases}</span>
                </div>
                <span className="ld-ovr-stat-pct">{openPct}%</span>
              </div>
              <div className="ld-ovr-stat-card ld-ovr-resolved">
                <div className="ld-ovr-dot" style={{ background: '#10b981' }}></div>
                <div className="ld-ovr-stat-body">
                  <span className="ld-ovr-stat-name">Resolved</span>
                  <span className="ld-ovr-stat-val">{resolvedCases}</span>
                </div>
                <span className="ld-ovr-stat-pct">{resolvedPct}%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="chart-card chart-card-map">
          <h3>Fraud by Region <span className="info-tooltip-wrap" data-tooltip="Fraud impact aggregated by US region — West, South, Northeast, Midwest">&#9432;</span></h3>
          <div className="map-stats-row">
            {regionStats.map((r, i) => {
              const colors = ['#c62828', '#e65100', '#1565c0', '#2e7d32'];
              return (
                <div className="map-stat-chip" key={r.region}>
                  <span className="map-stat-dot" style={{ background: r.color }}></span>
                  <span className="map-stat-num">{r.impact.toLocaleString()}</span>
                  <span className="map-stat-label">{r.region}</span>
                </div>
              );
            })}
          </div>
          <USAMap data={states} getColor={getRegionColor} regionMap={stateToRegion} regionData={regionStats} noPins />
          <div className="leadership-heatmap-legend">
            {regionStats.map(r => (
              <span key={r.region} className="ld-region-legend-item">
                <span className="ld-region-legend-swatch" style={{ background: r.color }}></span>
                {r.region}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
