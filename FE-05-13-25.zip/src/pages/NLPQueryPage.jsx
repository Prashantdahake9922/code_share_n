import React, { useState, useRef, useEffect } from 'react';
import { NLP_QUERY_TEMPLATES, ORDERS } from '../data/dummyData';
import { useSystemHealth } from '../contexts/SystemHealthContext';

export default function NLPQueryPage() {
  const [query, setQuery] = useState('');
  const [target, setTarget] = useState('redshift');
  const [results, setResults] = useState(null);
  const [generatedSQL, setGeneratedSQL] = useState('');
  const [error, setError] = useState('');
  const health = useSystemHealth();
  const llmAvailable = health.openai_api;
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleQuery = (queryText) => {
    const q = queryText || query;
    if (!q.trim()) return;

    setError('');

    // Simulate prompt shield validation
    const forbidden = ['DROP', 'DELETE', 'INSERT', 'UPDATE', 'ALTER', 'TRUNCATE', 'GRANT', 'EXEC', 'REVOKE', 'CREATE'];
    const upperQ = q.toUpperCase();
    if (forbidden.some(f => upperQ.includes(f))) {
      setError('Prompt Shield: Query rejected. Contains forbidden SQL keywords.');
      setResults(null);
      return;
    }
    // Prompt injection patterns (Req 2.6)
    const injectionPatterns = [
      /ignore\s+(all\s+)?instructions/i,
      /ignore\s+(previous|prior|above)/i,
      /you\s+are\s+(now|a)\s/i,
      /system\s*prompt/i,
      /role\s*:?\s*(system|admin|assistant)/i,
      /pretend\s+(you|to\s+be)/i,
      /act\s+as\s+(a|an|the)/i,
      /override\s+(system|prompt|instructions)/i,
      /--\s/,
      /;\s*$/,
      /UNION\s+SELECT/i,
    ];
    if (injectionPatterns.some(p => p.test(q))) {
      setError('Prompt Shield: Query rejected. Detected prompt injection pattern (role impersonation, instruction override, or SQL injection).');
      setResults(null);
      return;
    }
    if (q.length > 500) {
      setError('Prompt Shield: Query rejected. Exceeds 500 character limit.');
      setResults(null);
      return;
    }

    // Simulate NLP-to-SQL conversion
    let sql = '';
    let filteredOrders = [...ORDERS];

    if (q.toLowerCase().includes('california') || q.toLowerCase().includes('ca')) {
      sql = "SELECT order_id, customer, amount, channel, status FROM orders WHERE ship_address LIKE '%CA%' AND created_at > DATEADD(year, -1, GETDATE())";
      // No CA in dummy data, show empty
      filteredOrders = [];
    } else if (q.toLowerCase().includes('1000') || q.toLowerCase().includes('high-value')) {
      sql = "SELECT order_id, customer, amount, channel, status FROM orders WHERE amount > 1000 AND created_at > DATEADD(year, -1, GETDATE())";
      filteredOrders = ORDERS.filter(o => o.amount > 1000);
    } else if (q.toLowerCase().includes('velocity')) {
      sql = "SELECT order_id, customer, amount, risk_flags FROM orders WHERE risk_flags LIKE '%velocity%'";
      filteredOrders = ORDERS.filter(o => o.risk_flags.includes('velocity'));
    } else if (q.toLowerCase().includes('channel')) {
      sql = "SELECT channel, COUNT(*) as order_count, SUM(amount) as total FROM orders GROUP BY channel";
      filteredOrders = ORDERS;
    } else if (q.toLowerCase().includes('device')) {
      sql = "SELECT order_id, customer, amount FROM orders WHERE risk_flags LIKE '%device%' OR risk_flags LIKE '%new_device%'";
      filteredOrders = ORDERS.filter(o => o.risk_flags.some(f => f.includes('device')));
    } else {
      sql = `SELECT order_id, customer, amount, channel, status, created_at FROM orders WHERE created_at > DATEADD(year, -1, GETDATE()) LIMIT 25`;
      filteredOrders = ORDERS.slice(0, 8);
    }

    setGeneratedSQL(sql);
    setResults(filteredOrders);
  };

  const handleTemplateClick = (template) => {
    setQuery(template.query);
    handleQuery(template.query);
  };

  return (
    <div className="nlp-query-page">
      <h1>NLP-to-SQL Query Interface</h1>

      {/* Status Indicators */}
      <div className="nlp-status-bar">
        <span className="nlp-status-badge date-badge">Date Filter: Last 1 Year Enforced</span>
        <span className="nlp-status-badge pii-badge">PII Columns Excluded</span>
        <span className="nlp-status-badge prompt-badge">Prompt Shield Active</span>
        {!llmAvailable && (
          <span className="nlp-status-badge fallback-badge">LLM Unavailable — Using Keyword Template Matching (Fallback Mode)</span>
        )}
        {llmAvailable && (
          <span className="nlp-status-badge llm-badge">LLM Connected — Full NLP Processing</span>
        )}
      </div>

      {/* Query Input */}
      <div className="nlp-input-section">
        <div className="nlp-input-row">
          <textarea
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder='Ask a question like: "Show me all orders with amount over $1000"'
            rows={3}
            className="nlp-textarea"
          />
          <div className="nlp-controls">
            <select value={target} onChange={e => setTarget(e.target.value)} className="target-select">
              <option value="redshift">Redshift (26.8M records)</option>
              <option value="sqlite">SQLite FIT (10K records)</option>
            </select>
            <button className="btn-primary" onClick={() => handleQuery()}>Submit Query</button>
          </div>
        </div>
        {error && <div className="nlp-error">{error}</div>}
      </div>

      {/* Quick Query Templates */}
      <div className="quick-queries">
        <h3>Quick Queries (Pre-built Templates) <span className="info-tooltip-wrap" data-tooltip="Click a template to auto-fill the query — converts natural language to SQL">&#9432;</span></h3>
        <div className="template-buttons">
          {NLP_QUERY_TEMPLATES.map((t, i) => (
            <button key={i} className="template-btn" onClick={() => handleTemplateClick(t)}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {generatedSQL && (
        <div className="nlp-results">
          <div className="generated-sql">
            <h4>Generated SQL:</h4>
            <code>{generatedSQL}</code>
            <span className="sql-info">PII columns excluded | Target: {target} | Date filter: last 1 year</span>
          </div>

          {results && results.length > 0 ? (
            <div className="results-table-container">
              <h4>Results ({results.length} rows)</h4>
              <table className="results-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Channel</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Risk Flags</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map(r => (
                    <tr key={r.order_id}>
                      <td>{r.order_id}</td>
                      <td>{r.customer}</td>
                      <td>${r.amount.toLocaleString()}</td>
                      <td>{r.channel}</td>
                      <td>{r.status}</td>
                      <td>{r.created_at}</td>
                      <td>{r.risk_flags.join(', ')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="export-dropdown" ref={exportRef} style={{ position: 'relative', display: 'inline-block' }}>
                <button className="btn-export" onClick={() => setShowExportMenu(!showExportMenu)}>Export ▾</button>
                {showExportMenu && (
                  <div className="export-menu">
                    <button onClick={() => {
                      const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a'); a.href = url; a.download = 'nlp_query_export.json'; a.click();
                      URL.revokeObjectURL(url);
                      setShowExportMenu(false);
                    }}>JSON</button>
                    <button onClick={() => {
                      const headers = 'order_id,customer,amount,channel,status,created_at,risk_flags';
                      const rows = results.map(r => `"${r.order_id}","${r.customer}",${r.amount},"${r.channel}","${r.status}","${r.created_at}","${r.risk_flags.join('; ')}"`);
                      const csv = [headers, ...rows].join('\n');
                      const blob = new Blob([csv], { type: 'text/csv' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a'); a.href = url; a.download = 'nlp_query_export.csv'; a.click();
                      URL.revokeObjectURL(url);
                      setShowExportMenu(false);
                    }}>CSV</button>
                    <button onClick={() => {
                      const hdrs = ['Order ID','Customer','Amount','Channel','Status','Created At','Risk Flags'];
                      let html = '<table><tr>' + hdrs.map(h => `<th>${h}</th>`).join('') + '</tr>';
                      results.forEach(r => { html += `<tr><td>${r.order_id}</td><td>${r.customer}</td><td>${r.amount}</td><td>${r.channel}</td><td>${r.status}</td><td>${r.created_at}</td><td>${r.risk_flags.join('; ')}</td></tr>`; });
                      html += '</table>';
                      const blob = new Blob([`<html><head><meta charset="utf-8"></head><body>${html}</body></html>`], { type: 'application/vnd.ms-excel' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a'); a.href = url; a.download = 'nlp_query_export.xls'; a.click();
                      URL.revokeObjectURL(url);
                      setShowExportMenu(false);
                    }}>Excel</button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <p className="no-data">No results found for this query.</p>
          )}
        </div>
      )}
    </div>
  );
}
