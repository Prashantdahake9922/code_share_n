import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';
import { ORDERS } from '../data/dummyData';

export default function DataSpiderPage() {
  const { user } = useAuth();
  const { cases } = useCases();
  const [filterCaseId, setFilterCaseId] = useState('');
  const [filterChannel, setFilterChannel] = useState('');
  const [mode, setMode] = useState(user.role === 'supervisor' ? 'supervisor' : 'investigator');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Investigator only sees orders from their assigned cases
  const myCaseIds = user.role === 'investigator'
    ? cases.filter(c => c.assigned_to === user.id).map(c => c.id)
    : null;

  let filteredOrders = myCaseIds
    ? ORDERS.filter(o => myCaseIds.includes(o.case_id))
    : [...ORDERS];

  if (filterCaseId) {
    filteredOrders = filteredOrders.filter(o => o.case_id.toLowerCase().includes(filterCaseId.toLowerCase()) || o.order_id.toLowerCase().includes(filterCaseId.toLowerCase()));
  }
  if (filterChannel) {
    filteredOrders = filteredOrders.filter(o => o.channel === filterChannel);
  }

  const totalAmount = filteredOrders.reduce((sum, o) => sum + o.amount, 0);
  const totalPages = Math.ceil(filteredOrders.length / rowsPerPage);
  const paginatedOrders = filteredOrders.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);

  const handleExportJSON = () => {
    const blob = new Blob([JSON.stringify(filteredOrders, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'data_spider_export.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCSV = () => {
    const headers = 'order_id,case_id,customer,channel,amount,items,ship_address,status,created_at,risk_flags';
    const rows = filteredOrders.map(o => `"${o.order_id}","${o.case_id}","${o.customer}","${o.channel}",${o.amount},${o.items},"${o.ship_address}","${o.status}","${o.created_at}","${o.risk_flags.join('; ')}"`);
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'data_spider_export.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportExcel = () => {
    const headers = ['Order ID','Case ID','Customer','Channel','Amount','Items','Ship Address','Status','Created At','Risk Flags'];
    let html = '<table><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
    filteredOrders.forEach(o => { html += `<tr><td>${o.order_id}</td><td>${o.case_id}</td><td>${o.customer}</td><td>${o.channel}</td><td>${o.amount}</td><td>${o.items}</td><td>${o.ship_address}</td><td>${o.status}</td><td>${o.created_at}</td><td>${o.risk_flags.join('; ')}</td></tr>`; });
    html += '</table>';
    const blob = new Blob([`<html><head><meta charset="utf-8"></head><body>${html}</body></html>`], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'data_spider_export.xls'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="data-spider-page">
      <h1>Data Spider</h1>

      {/* Filters */}
      <div className="filter-bar">
        <div className="filter-bar-row">
          <div className="filter-col filter-col-search">
            <span className="filter-col-label">Search</span>
            <div className="filter-input-wrap">
              <input
                type="text"
                placeholder="Case / Order ID..."
                value={filterCaseId}
                onChange={e => setFilterCaseId(e.target.value)}
                className="search-input"
              />
              {filterCaseId && <span className="filter-clear-x" onClick={() => setFilterCaseId('')}>✕</span>}
            </div>
          </div>
          <div className="filter-col">
            <span className="filter-col-label">Channel</span>
            <div className="filter-input-wrap">
              <select value={filterChannel} onChange={e => setFilterChannel(e.target.value)}>
                <option value="">All</option>
                <option value="Web">Web</option>
                <option value="Mobile">Mobile</option>
                <option value="Store">Store</option>
              </select>
              {filterChannel && <span className="filter-clear-x" onClick={() => setFilterChannel('')}>✕</span>}
            </div>
          </div>
          {user.role === 'supervisor' && (
            <div className="filter-col">
              <span className="filter-col-label">Mode</span>
              <div className="mode-toggle">
                <label>
                  <input type="radio" value="investigator" checked={mode === 'investigator'} onChange={e => setMode(e.target.value)} />
                  Investigator
                </label>
                <label>
                  <input type="radio" value="supervisor" checked={mode === 'supervisor'} onChange={e => setMode(e.target.value)} />
                  Supervisor
                </label>
              </div>
            </div>
          )}
          <div className="filter-col" style={{ marginLeft: 'auto' }}>
            <span className="filter-col-label">Summary</span>
            <div className="spider-summary">
              <span>Orders: <strong>{filteredOrders.length}</strong></span>
              <span>Total: <strong>${totalAmount.toLocaleString()}</strong></span>
            </div>
          </div>
          <div className="filter-col filter-col-export" ref={exportRef}>
            <span className="filter-col-label">&nbsp;</span>
            <button className="btn-export-sm" onClick={() => setShowExportMenu(!showExportMenu)}>Export ▾</button>
            {showExportMenu && (
              <div className="export-dropdown-wrap">
                <div className="export-menu">
                  <button onClick={() => { handleExportJSON(); setShowExportMenu(false); }}>JSON</button>
                  <button onClick={() => { handleExportCSV(); setShowExportMenu(false); }}>CSV</button>
                  <button onClick={() => { handleExportExcel(); setShowExportMenu(false); }}>Excel</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="spider-table-container">
        <table className="spider-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Case ID</th>
              <th>Customer</th>
              <th>Channel</th>
              <th>Amount</th>
              <th>Items</th>
              <th>Ship Address</th>
              <th>Status</th>
              <th>Created</th>
              <th>Risk Flags</th>
            </tr>
          </thead>
          <tbody>
            {paginatedOrders.map(o => (
              <tr key={o.order_id}>
                <td className="order-id">{o.order_id}</td>
                <td className="case-link">{o.case_id}</td>
                <td>{o.customer}</td>
                <td><span className={`channel-badge channel-${o.channel.toLowerCase().split(' ')[0]}`}>{o.channel}</span></td>
                <td className="amount">${o.amount.toLocaleString()}</td>
                <td>{o.items}</td>
                <td className="address">{o.ship_address}</td>
                <td><span className={`order-status status-${o.status.toLowerCase()}`}>{o.status}</span></td>
                <td>{o.created_at}</td>
                <td>
                  {o.risk_flags.map(f => <span key={f} className="risk-flag">{f}</span>)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div className="spider-pagination">
        <div className="pagination-controls">
          <button disabled={currentPage === 1} onClick={() => setCurrentPage(1)}>«</button>
          <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => p - 1)}>Prev</button>
          <span className="pagination-page">{currentPage} / {totalPages}</span>
          <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(p => p + 1)}>Next</button>
          <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(totalPages)}>»</button>
        </div>
      </div>
    </div>
  );
}
