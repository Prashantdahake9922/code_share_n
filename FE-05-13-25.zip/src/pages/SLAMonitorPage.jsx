import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCases } from '../contexts/CasesContext';
import { SLA_RULES, USERS } from '../data/dummyData';

export default function SLAMonitorPage() {
  const { cases } = useCases();
  const navigate = useNavigate();
  const [notified, setNotified] = useState({});

  const breachedCases = cases.filter(c => c.sla_status === 'breached');
  const atRiskCases = cases.filter(c => c.sla_status === 'at_risk');

  const getAssigneeName = (id) => USERS.find(u => u.id === id)?.name || 'Unassigned';

  const getInactiveHours = (updatedAt) => {
    const now = new Date('2026-05-01T10:00:00Z');
    const updated = new Date(updatedAt);
    return Math.round((now - updated) / (1000 * 60 * 60));
  };

  return (
    <div className="sla-monitor-page">
      <h1>SLA Monitoring</h1>

      <div className="sla-layout">
        {/* Thresholds */}
        <div className="sla-thresholds">
          <h3>Configurable SLA Thresholds <span className="info-tooltip-wrap" data-tooltip="Maximum inactivity hours before a case is flagged as SLA breached">&#9432;</span></h3>
          <table className="threshold-table">
            <thead>
              <tr><th>Ticket Type</th><th>Inactivity Threshold</th></tr>
            </thead>
            <tbody>
              {SLA_RULES.map(rule => (
                <tr key={rule.ticket_type}>
                  <td>{rule.label}</td>
                  <td><strong>{rule.threshold_hours} hours</strong></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="priority-tiers">
            <h4>Priority Tiers</h4>
            <div className="tier-item urgent">Urgent: 4 hours</div>
            <div className="tier-item progress">In Progress: 48 hours</div>
            <div className="tier-item untouched">Untouched: 144 hours</div>
          </div>
        </div>

        {/* Breached Cases */}
        <div className="sla-breached">
          <h3>Breached Cases ({breachedCases.length}) <span className="info-tooltip-wrap" data-tooltip="Cases that have exceeded their SLA threshold — require immediate attention">&#9432;</span></h3>
          {breachedCases.length === 0 ? (
            <p className="no-data">No SLA breaches currently</p>
          ) : (
            <div className="breached-list">
              {breachedCases.map(c => (
                <div key={c.id} className="breached-card">
                  <div className="breached-header">
                    <strong>{c.id}</strong>
                    <span className="inactive-hours">{getInactiveHours(c.updated_at)}h inactive</span>
                  </div>
                  <div className="breached-info">
                    <span>Type: {c.ticket_type.replace(/_/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase())}</span>
                    <span>Assigned: {getAssigneeName(c.assigned_to)}</span>
                    <span>Priority: {c.priority}</span>
                  </div>
                  <div className="breached-actions">
                    <button className="btn-small" onClick={() => { setNotified(prev => ({ ...prev, [c.id]: true })); }}>{notified[c.id] ? 'Notified' : 'Notify'}</button>
                    <button className="btn-small" onClick={() => alert(`Reassign ${c.id} — select a new investigator from the Cases page.`)}>Reassign</button>
                    <button className="btn-small" onClick={() => navigate('/audit')}>View Audit</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* At Risk Cases */}
        <div className="sla-at-risk">
          <h3>At Risk Cases ({atRiskCases.length}) <span className="info-tooltip-wrap" data-tooltip="Cases approaching their SLA deadline — within 75% of threshold">&#9432;</span></h3>
          {atRiskCases.length === 0 ? (
            <p className="no-data">No cases at risk currently</p>
          ) : (
            <div className="at-risk-list">
              {atRiskCases.map(c => (
                <div key={c.id} className="at-risk-card">
                  <div className="at-risk-header">
                    <strong>{c.id}</strong>
                    <span className="inactive-hours">{getInactiveHours(c.updated_at)}h inactive</span>
                  </div>
                  <div className="at-risk-info">
                    <span>{c.ticket_type.replace(/_/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase())}</span>
                    <span>{getAssigneeName(c.assigned_to)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
