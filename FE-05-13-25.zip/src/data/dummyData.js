// ==================== DUMMY DATA FOR FPM SYSTEM (TELECOM / WIRELESS) ====================

export const USERS = [
  { id: 'usr-001', username: 'investigator1', password: 'password123', name: 'Investigator 1', role: 'investigator' },
  { id: 'usr-002', username: 'investigator2', password: 'password123', name: 'Investigator 2', role: 'investigator' },
  { id: 'usr-003', username: 'supervisor1', password: 'password123', name: 'Supervisor 1', role: 'supervisor' },
  { id: 'usr-004', username: 'admin', password: 'admin', name: 'Admin User', role: 'supervisor' },
  { id: 'usr-005', username: 'leadership1', password: 'password123', name: 'Leadership 1', role: 'leadership' },
];

export const TICKET_TYPES = [
  'fraud_ordering', 'fraud_non_ordering', 'credit_abuse_ordering',
  'credit_abuse_sor', 'credit_abuse_appeal', 'general'
];

export const STATUSES = [
  'unassigned', 'assigned', 'open', 'in_progress', 'escalated',
  'pending_customer', 'closed', 'canceled', 'resolved'
];

export const DISPOSITIONS = [
  'approve', 'reject', 'customer_engagement', 'cannot_determine',
  'fraud_found', 'no_fraud', 'waiting_for_documents', 'issue_with_ticket',
  'credit_approved', 'credit_denied'
];

export const PRIORITIES = ['critical', 'high', 'medium', 'low'];

export const SLA_STATUSES = ['on_track', 'at_risk', 'breached'];

export const RISK_FACTORS = [
  { id: 'RF-01', label: 'SIM swap within 24h', weight: 20 },
  { id: 'RF-02', label: 'Port-out velocity (3+ in 30d)', weight: 18 },
  { id: 'RF-03', label: 'IMEI on blacklist/stolen DB', weight: 19 },
  { id: 'RF-04', label: 'Multiple lines activated same day', weight: 16 },
  { id: 'RF-05', label: 'Device financing default history', weight: 15 },
  { id: 'RF-06', label: 'Synthetic identity indicators', weight: 17 },
  { id: 'RF-07', label: 'Dealer anomaly (high activation rate)', weight: 14 },
  { id: 'RF-08', label: 'Account age < 30 days', weight: 10 },
  { id: 'RF-09', label: 'International call spike (IRSF pattern)', weight: 18 },
  { id: 'RF-10', label: 'Disputed number on prior fraud', weight: 12 },
  { id: 'RF-11', label: 'Address mismatch with service area', weight: 9 },
  { id: 'RF-12', label: 'SSN not found / deceased', weight: 20 },
  { id: 'RF-13', label: 'Multiple devices on one account', weight: 11 },
  { id: 'RF-14', label: 'Unauthorized plan upgrade', weight: 13 },
  { id: 'RF-15', label: 'IP geolocation mismatch', weight: 8 },
  { id: 'RF-16', label: 'Call forwarding enabled post SIM swap', weight: 16 },
  { id: 'RF-17', label: 'Premium SMS subscription (Wangiri)', weight: 14 },
  { id: 'RF-18', label: 'Prior account takeover history', weight: 15 },
];

export const EXTERNAL_TOOLS = [
  { name: 'GSMA IMEI Check', uri: 'https://tool1.abcd.com', description: 'Verify IMEI status (stolen/blacklisted)', icon: '📱' },
  { name: 'Number Portability DB', uri: 'https://tool2.abcd.com', description: 'Port-out/port-in history lookup', icon: '🔄' },
  { name: 'LexisNexis', uri: 'https://tool3.abcd.com', description: 'Identity verification & fraud risk', icon: '🔍' },
  { name: 'Ekata', uri: 'https://tool4.abcd.com', description: 'Phone & identity verification API', icon: '✓' },
  { name: 'SentiLink', uri: 'https://tool5.abcd.com', description: 'Synthetic identity detection', icon: '🤖' },
  { name: 'SIM Registry', uri: 'https://tool6.abcd.com', description: 'SIM card activation & swap history', icon: '💳' },
  { name: 'Carrier Lookup', uri: 'https://tool7.abcd.com', description: 'MNO/MVNO carrier identification', icon: '📡' },
  { name: 'Device Financing DB', uri: 'https://tool8.abcd.com', description: 'Installment plan & default history', icon: '💰' },
  { name: 'Call Detail Records', uri: 'https://tool9.abcd.com', description: 'CDR analysis and call patterns', icon: '📞' },
  { name: 'GeoFence Validator', uri: 'https://tool10.abcd.com', description: 'Cell tower location vs claimed address', icon: '🌍' },
  { name: 'Dealer Portal', uri: 'https://tool11.abcd.com', description: 'Dealer activation records & audits', icon: '🏪' },
  { name: 'Fraud Consortium', uri: 'https://tool12.abcd.com', description: 'Cross-carrier fraud intelligence sharing', icon: '🛡️' },
];

export const CASES = [
  {
    id: 'FPM-001', ucm_ticket_id: 'UCM-5521', order_id: 'ORD-9982',
    ticket_type: 'fraud_ordering', priority: 'critical', status: 'open',
    disposition: null, sla_status: 'at_risk', assigned_to: 'usr-001',
    customer: { name: 'Customer 1', email: 'j***@abcd.com', phone: '***-***-1234', account: 'WLS-88901', mobile_number: '000-000-0001' },
    line_of_business: 'Wireless', risk_score: 82,
    created_at: '2026-04-28T10:30:00Z', updated_at: '2026-04-30T14:20:00Z',
    comments_count: 3, description: 'Unauthorized SIM swap followed by call forwarding activation and device financing attempt',
    linked_cases: ['FPM-005', 'FPM-012'],
    agent_insights: {
      triage: { risk_score: 82, priority: 'critical', confidence: 91, flags: ['sim_swap_24h', 'call_forwarding', 'new_device_finance'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'match', ip: 'proxy_detected', imei: 'new_device', confidence: 42 },
      summarization: 'SIM swap initiated via dealer portal at 2:14 AM. Within 30 minutes, call forwarding was enabled and a $1,399 device financing application was submitted. Original account holder reports no knowledge of change. IMEI of new SIM belongs to burner device.',
      decision: { recommendation: 'reject', confidence: 92, reasoning: 'Classic SIM swap pattern: off-hours swap via dealer, immediate call forwarding, rapid device financing attempt. All indicators point to account takeover.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-16', 'RF-18', 'RF-05', 'RF-15'], score: 78, investigator: 'Investigator 1', notes: '', timestamp: '2025-04-28T14:30:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-28T10:31:00Z', reason: 'Auto-assigned via triage - Critical SIM swap' },
      { from: 'assigned', to: 'open', changed_by: 'usr-001', changed_at: '2026-04-28T11:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c1', author: 'Triage Agent', text: 'CRITICAL: SIM swap at 2:14 AM via dealer ID DLR-442. Call forwarding + device finance within 30 min.', created_at: '2026-04-28T10:31:00Z' },
      { id: 'c2', author: 'Investigator 1', text: 'Confirmed with customer - they did NOT authorize SIM swap. Investigating dealer DLR-442.', created_at: '2026-04-29T09:00:00Z' },
      { id: 'c3', author: 'Verification Agent', text: 'New IMEI 35291012XXXXXXX not associated with any known customer device. Burner phone pattern.', created_at: '2026-04-29T09:05:00Z' },
    ]
  },
  {
    id: 'FPM-002', ucm_ticket_id: 'UCM-5522', order_id: 'ORD-9983',
    ticket_type: 'fraud_non_ordering', priority: 'high', status: 'in_progress',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 2', email: 's***@abcd.com', phone: '***-***-5678', account: 'WLS-77201', mobile_number: '000-000-0002' },
    line_of_business: 'Wireless', risk_score: 68,
    created_at: '2026-04-29T08:15:00Z', updated_at: '2026-04-30T16:45:00Z',
    comments_count: 2, description: 'Multiple device financing applications across 3 stores in 48 hours with inconsistent identity docs',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 68, priority: 'high', confidence: 82, flags: ['multi_device_finance', 'velocity_48h', 'dealer_anomaly'] },
      verification: { phone: 'match', email: 'match', address: 'partial', ip: 'clean', imei: 'multiple_new', confidence: 65 },
      summarization: 'Customer applied for iPhone 15 Pro Max financing at 3 different retail stores within 48 hours. Store A (approved), Store B (pending), Store C (pending). ID documents show slight variations in address. Total financing exposure: $4,197.',
      decision: { recommendation: 'customer_engagement', confidence: 71, reasoning: 'Multiple device applications are suspicious but phone/email verify. Address variation could be legitimate (recent move). Contact customer before blocking.' }
    },
    investigation_score: { selected_factors: ['RF-04', 'RF-05', 'RF-07', 'RF-08'], score: 42, investigator: 'Investigator 2', notes: '', timestamp: '2025-04-27T09:15:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-29T08:16:00Z', reason: 'Auto-assigned' },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-29T10:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c4', author: 'Triage Agent', text: 'High risk. 3 device finance apps in 48h across different stores.', created_at: '2026-04-29T08:16:00Z' },
      { id: 'c5', author: 'Investigator 2', text: 'Checking dealer records and ID verification photos from all 3 stores.', created_at: '2026-04-29T10:30:00Z' },
    ]
  },
  {
    id: 'FPM-003', ucm_ticket_id: 'UCM-5523', order_id: 'ORD-9984',
    ticket_type: 'credit_abuse_ordering', priority: 'low', status: 'assigned',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 3', email: 'r***@abcd.com', phone: '***-***-9012', account: 'WLS-55302', mobile_number: '000-000-0003' },
    line_of_business: 'Wireless', risk_score: 22,
    created_at: '2026-04-30T14:20:00Z', updated_at: '2026-04-30T14:20:00Z',
    comments_count: 1, description: 'Customer-initiated plan upgrade and authorized device change flagged by automated rules',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 22, priority: 'low', confidence: 94, flags: ['plan_upgrade'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 95 },
      summarization: 'Customer called in to upgrade from 5GB to unlimited plan and add a new authorized user. All identity verification passed. Call originated from registered device. No suspicious indicators.',
      decision: { recommendation: 'approve', confidence: 94, reasoning: 'All verification points match. Customer-initiated change from registered device. Routine account maintenance.' }
    },
    investigation_score: { selected_factors: [], score: 0, investigator: '', notes: '', timestamp: '' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T14:21:00Z', reason: 'Auto-assigned' },
    ],
    comments: [
      { id: 'c6', author: 'Triage Agent', text: 'Low risk score 22. Auto-approve candidate.', created_at: '2026-04-30T14:21:00Z' },
    ]
  },
  {
    id: 'FPM-004', ucm_ticket_id: 'UCM-5518', order_id: 'ORD-9978',
    ticket_type: 'credit_abuse_sor', priority: 'critical', status: 'escalated',
    disposition: null, sla_status: 'breached', assigned_to: 'usr-001',
    customer: { name: 'Customer 4', email: 'a***@abcd.com', phone: '***-***-3456', account: 'WLS-44103', mobile_number: '000-000-0004' },
    line_of_business: 'Wireless', risk_score: 94,
    created_at: '2026-04-22T09:00:00Z', updated_at: '2026-04-28T11:00:00Z',
    comments_count: 7, description: 'Synthetic identity used to open 5 wireless lines with premium devices - all shipped to same drop address',
    linked_cases: ['FPM-007', 'FPM-008', 'FPM-015'],
    agent_insights: {
      triage: { risk_score: 94, priority: 'critical', confidence: 97, flags: ['synthetic_id', 'multi_line_activation', 'deceased_ssn', 'drop_address'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'proxy_detected', imei: 'new_device', confidence: 18 },
      summarization: '5 new wireless lines activated within 3 hours using SSN linked to deceased individual. All premium devices (iPhone 15 Pro Max, Samsung S24 Ultra) shipped to known drop address at 400 Street D, City D FL. Total device value: $7,495. Phone number linked to known fraud ring.',
      decision: { recommendation: 'reject', confidence: 97, reasoning: 'Synthetic identity confirmed via deceased SSN. Drop address pattern. Multi-line activation velocity. Connected to known fraud ring. Immediate line suspension recommended.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-03', 'RF-04', 'RF-05', 'RF-06', 'RF-08', 'RF-11', 'RF-12', 'RF-13', 'RF-15', 'RF-18'], score: 91, investigator: 'Supervisor 1', notes: 'High risk - multiple indicators', timestamp: '2025-04-26T16:45:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-22T09:01:00Z', reason: 'Critical priority' },
      { from: 'assigned', to: 'open', changed_by: 'usr-001', changed_at: '2026-04-22T10:00:00Z', reason: null },
      { from: 'open', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-22T10:30:00Z', reason: null },
      { from: 'in_progress', to: 'escalated', changed_by: 'usr-001', changed_at: '2026-04-24T09:00:00Z', reason: 'Fraud ring detected - needs supervisor review and law enforcement referral' },
    ],
    comments: [
      { id: 'c7', author: 'Triage Agent', text: 'CRITICAL: Score 94. Synthetic ID + deceased SSN + 5 line activations to drop address.', created_at: '2026-04-22T09:01:00Z' },
      { id: 'c8', author: 'Investigator 1', text: 'Confirmed synthetic ID. All lines suspended. Escalating for fraud ring investigation.', created_at: '2026-04-24T09:00:00Z' },
    ]
  },
  {
    id: 'FPM-005', ucm_ticket_id: 'UCM-5524', order_id: 'ORD-9985',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 5', email: 'm***@abcd.com', phone: '***-***-7890', account: 'WLS-66204', mobile_number: '000-000-0005' },
    line_of_business: 'Wireless', risk_score: 71,
    created_at: '2026-04-30T16:00:00Z', updated_at: '2026-04-30T18:30:00Z',
    comments_count: 2, description: 'SIM swap request from non-registered device followed by password reset attempt on linked banking app',
    linked_cases: ['FPM-001'],
    agent_insights: {
      triage: { risk_score: 71, priority: 'high', confidence: 79, flags: ['sim_swap', 'unregistered_device', 'banking_reset'] },
      verification: { phone: 'match', email: 'partial', address: 'match', ip: 'different_city', imei: 'unknown_device', confidence: 51 },
      summarization: 'SIM swap request submitted online from device not previously associated with account. Within 15 minutes of swap, password reset was triggered on linked Chase banking app. Customer has 8-year account history with no prior incidents.',
      decision: { recommendation: 'customer_engagement', confidence: 65, reasoning: 'SIM swap + banking reset is concerning but customer has long clean history. Device could be new purchase. Needs customer verification before action.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-16', 'RF-15'], score: 36, investigator: 'Investigator 1', notes: '', timestamp: '2025-04-25T11:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T16:01:00Z', reason: 'Auto-assigned' },
      { from: 'assigned', to: 'open', changed_by: 'usr-002', changed_at: '2026-04-30T17:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c9', author: 'Triage Agent', text: 'High risk. SIM swap from unknown device + banking password reset within 15 min.', created_at: '2026-04-30T16:01:00Z' },
      { id: 'c10', author: 'Investigator 2', text: 'Attempting customer contact via registered email for identity verification.', created_at: '2026-04-30T18:00:00Z' },
    ]
  },
  {
    id: 'FPM-006', ucm_ticket_id: 'UCM-5510', order_id: 'ORD-9970',
    ticket_type: 'credit_abuse_appeal', priority: 'medium', status: 'resolved',
    disposition: 'fraud_found', sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 6', email: 'd***@abcd.com', phone: '***-***-2345', account: 'WLS-33105', mobile_number: '000-000-0006' },
    line_of_business: 'Wireless', risk_score: 55,
    created_at: '2026-04-20T11:00:00Z', updated_at: '2026-04-25T15:30:00Z',
    comments_count: 5, description: 'Dealer activated 12 lines using customer IDs without customer knowledge - commission farming scheme',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 55, priority: 'medium', confidence: 85, flags: ['dealer_anomaly', 'multi_activation', 'commission_pattern'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'dealer_ip', imei: 'bulk_devices', confidence: 70 },
      summarization: 'Dealer DLR-889 activated 12 lines across 4 different customer accounts in a single day. Customers report they only authorized 1-2 lines each. Dealer has history of high activation volume. Pattern consistent with commission farming.',
      decision: { recommendation: 'reject', confidence: 82, reasoning: 'Dealer commission farming confirmed. Unauthorized activations across multiple customer accounts. Recommend dealer suspension and line reversals.' }
    },
    investigation_score: { selected_factors: ['RF-07', 'RF-04', 'RF-14'], score: 35, investigator: 'Investigator 2', notes: '', timestamp: '2025-04-24T13:20:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-20T11:01:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-21T09:00:00Z', reason: null },
      { from: 'in_progress', to: 'resolved', changed_by: 'usr-002', changed_at: '2026-04-25T15:30:00Z', reason: 'Dealer fraud confirmed - lines deactivated' },
    ],
    comments: [
      { id: 'c11', author: 'Investigator 2', text: 'Dealer fraud confirmed. 12 unauthorized activations reversed. Dealer DLR-889 suspended.', created_at: '2026-04-25T15:30:00Z' },
    ]
  },
  {
    id: 'FPM-007', ucm_ticket_id: 'UCM-5515', order_id: 'ORD-9975',
    ticket_type: 'general', priority: 'critical', status: 'in_progress',
    disposition: null, sla_status: 'at_risk', assigned_to: 'usr-001',
    customer: { name: 'Customer 7', email: 'e***@abcd.com', phone: '***-***-6789', account: 'WLS-99006', mobile_number: '000-000-0007' },
    line_of_business: 'Wireless', risk_score: 88,
    created_at: '2026-04-26T07:30:00Z', updated_at: '2026-04-30T12:00:00Z',
    comments_count: 4, description: 'International Revenue Share Fraud - 400+ calls to premium rate numbers in Somalia and Latvia within 6 hours',
    linked_cases: ['FPM-004'],
    agent_insights: {
      triage: { risk_score: 88, priority: 'critical', confidence: 93, flags: ['irsf_pattern', 'premium_rate', 'call_spike', 'international_volume'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'partial', ip: 'proxy_detected', imei: 'new_device', confidence: 38 },
      summarization: '412 outbound calls to premium rate numbers in Somalia (+252) and Latvia (+371) within 6 hours. Call duration 20-40 seconds each (optimized for billing). Estimated toll charges: $12,400. Account was recently SIM-swapped. Linked to FR-042 fraud ring.',
      decision: { recommendation: 'reject', confidence: 94, reasoning: 'Classic IRSF pattern: SIM swap → call forwarding → premium number pumping. Immediate line block and toll charge reversal required.' }
    },
    investigation_score: { selected_factors: ['RF-09', 'RF-01', 'RF-16', 'RF-17', 'RF-15', 'RF-02'], score: 76, investigator: 'Investigator 1', notes: 'IRSF pattern confirmed', timestamp: '2025-04-23T10:30:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-26T07:31:00Z', reason: 'Critical auto-assign - IRSF detected' },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-26T09:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c12', author: 'Triage Agent', text: 'CRITICAL: IRSF detected. 412 calls to +252/+371 premium numbers. $12,400 toll charges.', created_at: '2026-04-26T07:31:00Z' },
      { id: 'c13', author: 'Investigator 1', text: 'Line blocked. Investigating connection to fraud ring FR-042 and prior SIM swap.', created_at: '2026-04-27T11:00:00Z' },
    ]
  },
  {
    id: 'FPM-008', ucm_ticket_id: 'UCM-5516', order_id: 'ORD-9976',
    ticket_type: 'fraud_non_ordering', priority: 'high', status: 'resolved',
    disposition: 'reject', sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 8', email: 'k***@abcd.com', phone: '***-***-0123', account: 'WLS-11207', mobile_number: '000-000-0008' },
    line_of_business: 'Wireless', risk_score: 76,
    created_at: '2026-04-24T13:00:00Z', updated_at: '2026-04-27T10:00:00Z',
    comments_count: 4, description: 'New subscription with temporary email, fake ID, and immediate international roaming activation',
    linked_cases: ['FPM-004'],
    agent_insights: {
      triage: { risk_score: 76, priority: 'high', confidence: 87, flags: ['temp_email', 'fake_id_indicators', 'immediate_roaming', 'linked_ring'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'proxy_detected', imei: 'new_device', confidence: 22 },
      summarization: 'New account opened with temporary email domain (temp.com). ID photo shows signs of manipulation. International roaming activated within 1 hour of subscription. Same drop address as FPM-004 (400 Street D, City D FL).',
      decision: { recommendation: 'reject', confidence: 95, reasoning: 'Fraudulent subscription: fake ID + temp email + immediate roaming + shared drop address with confirmed fraud ring.' }
    },
    investigation_score: { selected_factors: ['RF-06', 'RF-08', 'RF-11', 'RF-12', 'RF-15', 'RF-04'], score: 65, investigator: 'Investigator 2', notes: 'Synthetic ID suspected', timestamp: '2025-04-22T15:45:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-24T13:01:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-04-25T08:00:00Z', reason: null },
      { from: 'in_progress', to: 'resolved', changed_by: 'usr-001', changed_at: '2026-04-27T10:00:00Z', reason: 'Subscription fraud - line terminated' },
    ],
    comments: [
      { id: 'c14', author: 'Investigator 1', text: 'Subscription fraud confirmed. Line terminated. Part of fraud ring with FPM-004.', created_at: '2026-04-27T10:00:00Z' },
    ]
  },
  {
    id: 'FPM-009', ucm_ticket_id: 'UCM-5525', order_id: 'ORD-9986',
    ticket_type: 'fraud_ordering', priority: 'low', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 9', email: 'l***@abcd.com', phone: '***-***-4567', account: 'WLS-22308', mobile_number: '000-000-0009' },
    line_of_business: 'Wireless', risk_score: 18,
    created_at: '2026-04-30T20:00:00Z', updated_at: '2026-05-01T08:00:00Z',
    comments_count: 1, description: 'Customer-reported suspicious login attempt - account secured, no changes made',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 18, priority: 'low', confidence: 92, flags: [] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 97 },
      summarization: 'Customer proactively reported receiving 2FA code they did not request. Account shows failed login attempt from unknown IP. No changes were made to account. Customer reset password. No further action needed.',
      decision: { recommendation: 'approve', confidence: 92, reasoning: 'Proactive customer report, no damage, account already secured. Close as informational.' }
    },
    investigation_score: { selected_factors: [], score: 0, investigator: '', notes: '', timestamp: '' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-30T20:01:00Z', reason: null },
      { from: 'assigned', to: 'open', changed_by: 'usr-002', changed_at: '2026-05-01T08:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c15', author: 'Triage Agent', text: 'Low risk. Customer-reported attempt, account secured. Auto-approve candidate.', created_at: '2026-04-30T20:01:00Z' },
    ]
  },
  {
    id: 'FPM-010', ucm_ticket_id: 'UCM-5512', order_id: 'ORD-9972',
    ticket_type: 'credit_abuse_ordering', priority: 'high', status: 'pending_customer',
    disposition: 'customer_engagement', sla_status: 'at_risk', assigned_to: 'usr-002',
    customer: { name: 'Customer 10', email: 'c***@abcd.com', phone: '***-***-8901', account: 'WLS-77509', mobile_number: '000-000-0010' },
    line_of_business: 'Wireless', risk_score: 61,
    created_at: '2026-04-25T15:30:00Z', updated_at: '2026-04-29T09:00:00Z',
    comments_count: 3, description: 'Device upgrade financing on account with 2 prior missed installments - device shipped to different address',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 61, priority: 'high', confidence: 76, flags: ['financing_default', 'address_mismatch', 'device_upgrade'] },
      verification: { phone: 'match', email: 'match', address: 'mismatch', ip: 'clean', imei: 'known_device', confidence: 68 },
      summarization: 'Customer requested device upgrade to Samsung S24 Ultra ($1,299 financed) with shipping to address not on file. Account has 2 missed installment payments in last 6 months. Phone and email verify but shipping address is in a different city.',
      decision: { recommendation: 'customer_engagement', confidence: 78, reasoning: 'Mixed signals: established customer with payment issues requesting ship to new address. Could be relocation or could be device theft setup. Verify address before shipping.' }
    },
    investigation_score: { selected_factors: ['RF-05', 'RF-11', 'RF-13'], score: 29, investigator: 'Investigator 1', notes: '', timestamp: '2025-04-20T08:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-04-25T15:31:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-002', changed_at: '2026-04-26T08:00:00Z', reason: null },
      { from: 'in_progress', to: 'pending_customer', changed_by: 'usr-002', changed_at: '2026-04-27T14:00:00Z', reason: 'Awaiting customer address verification call-back' },
    ],
    comments: [
      { id: 'c16', author: 'Investigator 2', text: 'Customer contacted via registered phone. Awaiting call-back to verify new shipping address.', created_at: '2026-04-27T14:00:00Z' },
    ]
  },
  {
    id: 'FPM-011', ucm_ticket_id: 'UCM-5530', order_id: 'ORD-9990',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'resolved',
    disposition: 'fraud_found', sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 11', email: 'm***@abcd.com', phone: '***-***-2211', account: 'WLS-66201', mobile_number: '000-000-0011' },
    line_of_business: 'Wireless', risk_score: 88,
    created_at: '2026-05-01T09:00:00Z', updated_at: '2026-05-03T16:00:00Z',
    comments_count: 2, description: 'Multiple device orders from new account within first 24 hours of activation',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 88, priority: 'high', confidence: 90, flags: ['new_account_velocity', 'multi_device', 'first_day_order'] },
      verification: { phone: 'match', email: 'mismatch', address: 'match', ip: 'vpn_detected', imei: 'new_device', confidence: 45 },
      summarization: 'New account activated yesterday placed 3 device financing orders totaling $4,200 within 6 hours. VPN detected on IP. Email domain is disposable.',
      decision: { recommendation: 'reject', confidence: 92, reasoning: 'New account velocity pattern combined with VPN usage and disposable email strongly indicates organized fraud.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-03'], score: 42, investigator: 'Investigator 1', notes: '', timestamp: '2026-05-02T10:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-01T09:01:00Z', reason: null },
      { from: 'assigned', to: 'resolved', changed_by: 'usr-001', changed_at: '2026-05-03T16:00:00Z', reason: 'Confirmed fraud' },
    ],
    comments: [
      { id: 'c17', author: 'Triage Agent', text: 'High velocity on new account. 3 devices ordered in 6h.', created_at: '2026-05-01T09:01:00Z' },
    ]
  },
  {
    id: 'FPM-012', ucm_ticket_id: 'UCM-5531', order_id: 'ORD-9991',
    ticket_type: 'fraud_non_ordering', priority: 'critical', status: 'escalated',
    disposition: null, sla_status: 'breached', assigned_to: 'usr-002',
    customer: { name: 'Customer 12', email: 'k***@abcd.com', phone: '***-***-3322', account: 'WLS-55102', mobile_number: '000-000-0012' },
    line_of_business: 'Wireless', risk_score: 94,
    created_at: '2026-05-02T14:30:00Z', updated_at: '2026-05-04T11:00:00Z',
    comments_count: 3, description: 'Account takeover via social engineering - port-out request to competitor',
    linked_cases: ['FPM-001'],
    agent_insights: {
      triage: { risk_score: 94, priority: 'critical', confidence: 95, flags: ['port_out', 'social_engineering', 'account_takeover'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'tor_exit_node', imei: 'unknown', confidence: 12 },
      summarization: 'Port-out request received from competitor. Customer PIN was changed 2 hours prior via call center using social engineering. All verification points mismatch.',
      decision: { recommendation: 'reject', confidence: 97, reasoning: 'Classic account takeover pattern. Port-out should be blocked immediately.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-06'], score: 48, investigator: 'Investigator 2', notes: '', timestamp: '2026-05-03T08:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-02T14:31:00Z', reason: null },
      { from: 'assigned', to: 'escalated', changed_by: 'usr-002', changed_at: '2026-05-03T08:30:00Z', reason: 'Needs immediate port freeze' },
    ],
    comments: [
      { id: 'c18', author: 'Triage Agent', text: 'CRITICAL: Port-out attempt detected. PIN changed 2h ago via social engineering.', created_at: '2026-05-02T14:31:00Z' },
    ]
  },
  {
    id: 'FPM-013', ucm_ticket_id: 'UCM-5532', order_id: 'ORD-9992',
    ticket_type: 'credit_abuse_ordering', priority: 'medium', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 13', email: 'r***@abcd.com', phone: '***-***-4433', account: 'WLS-44203', mobile_number: '000-000-0013' },
    line_of_business: 'Wireless', risk_score: 55,
    created_at: '2026-05-04T11:15:00Z', updated_at: '2026-05-05T09:00:00Z',
    comments_count: 1, description: 'Customer requesting early upgrade with outstanding balance on current device',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 55, priority: 'medium', confidence: 72, flags: ['outstanding_balance', 'early_upgrade'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 88 },
      summarization: 'Customer has $420 remaining on current device installment plan and requesting new device upgrade. Account in good standing otherwise.',
      decision: { recommendation: 'customer_engagement', confidence: 70, reasoning: 'Likely legitimate customer, but policy requires outstanding balance resolution before upgrade approval.' }
    },
    investigation_score: { selected_factors: [], score: 0, investigator: null, notes: '', timestamp: null },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-04T11:16:00Z', reason: null },
    ],
    comments: [
      { id: 'c19', author: 'Triage Agent', text: 'Medium risk. Outstanding balance but otherwise clean account.', created_at: '2026-05-04T11:16:00Z' },
    ]
  },
  {
    id: 'FPM-014', ucm_ticket_id: 'UCM-5505', order_id: 'ORD-9960',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'resolved',
    disposition: 'fraud_found', sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 14', email: 'a***@abcd.com', phone: '***-***-5544', account: 'WLS-33304', mobile_number: '000-000-0014' },
    line_of_business: 'Wireless', risk_score: 79,
    created_at: '2026-03-15T08:00:00Z', updated_at: '2026-03-20T17:00:00Z',
    comments_count: 2, description: 'Stolen identity used to open new wireless account and finance devices',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 79, priority: 'high', confidence: 85, flags: ['stolen_id', 'new_account', 'device_finance'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'match', ip: 'clean', imei: 'new_device', confidence: 35 },
      summarization: 'Account opened with stolen SSN. Victim reported identity theft to police. Two devices financed totaling $2,800.',
      decision: { recommendation: 'reject', confidence: 91, reasoning: 'Confirmed identity theft with police report. All devices should be blocked.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-04'], score: 38, investigator: 'Investigator 1', notes: '', timestamp: '2026-03-16T10:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-03-15T08:01:00Z', reason: null },
      { from: 'assigned', to: 'resolved', changed_by: 'usr-001', changed_at: '2026-03-20T17:00:00Z', reason: 'Fraud confirmed via police report' },
    ],
    comments: [
      { id: 'c20', author: 'Triage Agent', text: 'Stolen identity. Police report filed by victim.', created_at: '2026-03-15T08:01:00Z' },
    ]
  },
  {
    id: 'FPM-015', ucm_ticket_id: 'UCM-5506', order_id: 'ORD-9961',
    ticket_type: 'fraud_non_ordering', priority: 'critical', status: 'resolved',
    disposition: 'fraud_found', sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 15', email: 'b***@abcd.com', phone: '***-***-6655', account: 'WLS-22405', mobile_number: '000-000-0015' },
    line_of_business: 'Wireless', risk_score: 91,
    created_at: '2026-03-10T12:00:00Z', updated_at: '2026-03-14T15:00:00Z',
    comments_count: 2, description: 'Organized ring performing SIM swaps targeting high-value accounts',
    linked_cases: ['FPM-014'],
    agent_insights: {
      triage: { risk_score: 91, priority: 'critical', confidence: 93, flags: ['organized_ring', 'sim_swap', 'high_value_target'] },
      verification: { phone: 'mismatch', email: 'mismatch', address: 'mismatch', ip: 'proxy_detected', imei: 'burner', confidence: 15 },
      summarization: 'Part of organized fraud ring targeting executives with high credit lines. SIM swap performed via compromised dealer credentials.',
      decision: { recommendation: 'reject', confidence: 96, reasoning: 'Organized ring activity confirmed through dealer credential compromise investigation.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-06'], score: 45, investigator: 'Investigator 2', notes: '', timestamp: '2026-03-11T09:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-03-10T12:01:00Z', reason: null },
      { from: 'assigned', to: 'resolved', changed_by: 'usr-002', changed_at: '2026-03-14T15:00:00Z', reason: 'Ring identified and blocked' },
    ],
    comments: [
      { id: 'c21', author: 'Triage Agent', text: 'Organized ring activity. Dealer credentials compromised.', created_at: '2026-03-10T12:01:00Z' },
    ]
  },
  {
    id: 'FPM-016', ucm_ticket_id: 'UCM-5490', order_id: 'ORD-9950',
    ticket_type: 'credit_abuse_sor', priority: 'medium', status: 'resolved',
    disposition: 'no_fraud', sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 16', email: 'j***@abcd.com', phone: '***-***-7766', account: 'WLS-11506', mobile_number: '000-000-0016' },
    line_of_business: 'Wireless', risk_score: 42,
    created_at: '2026-02-20T10:00:00Z', updated_at: '2026-02-25T14:00:00Z',
    comments_count: 1, description: 'Suspicious return pattern - 3 devices returned within 14-day window over 2 months',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 42, priority: 'medium', confidence: 65, flags: ['return_abuse', 'serial_returner'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 92 },
      summarization: 'Customer returned 3 high-end devices within the 14-day window. Devices were resold by customer on marketplace. Pattern suggests return abuse for profit.',
      decision: { recommendation: 'customer_engagement', confidence: 68, reasoning: 'Pattern is suspicious but within policy. Flag account and monitor future returns.' }
    },
    investigation_score: { selected_factors: ['RF-11'], score: 12, investigator: 'Investigator 1', notes: '', timestamp: '2026-02-21T08:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-02-20T10:01:00Z', reason: null },
      { from: 'assigned', to: 'resolved', changed_by: 'usr-001', changed_at: '2026-02-25T14:00:00Z', reason: 'No fraud, flagged for monitoring' },
    ],
    comments: [
      { id: 'c22', author: 'Triage Agent', text: 'Serial return pattern detected. Within policy but suspicious.', created_at: '2026-02-20T10:01:00Z' },
    ]
  },
  {
    id: 'FPM-017', ucm_ticket_id: 'UCM-5491', order_id: 'ORD-9951',
    ticket_type: 'fraud_ordering', priority: 'high', status: 'resolved',
    disposition: 'reject', sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 17', email: 'p***@abcd.com', phone: '***-***-8877', account: 'WLS-99607', mobile_number: '000-000-0017' },
    line_of_business: 'Wireless', risk_score: 85,
    created_at: '2026-02-10T16:00:00Z', updated_at: '2026-02-15T12:00:00Z',
    comments_count: 2, description: 'Synthetic identity detected on device financing application',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 85, priority: 'high', confidence: 88, flags: ['synthetic_id', 'cpn', 'thin_file'] },
      verification: { phone: 'no_record', email: 'new_domain', address: 'commercial', ip: 'datacenter', imei: 'new_device', confidence: 20 },
      summarization: 'Application uses Credit Privacy Number (CPN) instead of SSN. Address is a commercial mail receiving agency. Phone number has no prior usage history.',
      decision: { recommendation: 'reject', confidence: 94, reasoning: 'Clear synthetic identity indicators. CPN + CMRA + thin credit file = fabricated identity.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-04', 'RF-07'], score: 44, investigator: 'Investigator 2', notes: '', timestamp: '2026-02-11T09:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-02-10T16:01:00Z', reason: null },
      { from: 'assigned', to: 'resolved', changed_by: 'usr-002', changed_at: '2026-02-15T12:00:00Z', reason: 'Synthetic ID confirmed' },
    ],
    comments: [
      { id: 'c23', author: 'Triage Agent', text: 'Synthetic ID indicators: CPN, CMRA address, thin file.', created_at: '2026-02-10T16:01:00Z' },
    ]
  },
  {
    id: 'FPM-018', ucm_ticket_id: 'UCM-5533', order_id: 'ORD-9993',
    ticket_type: 'credit_abuse_appeal', priority: 'low', status: 'open',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-001',
    customer: { name: 'Customer 18', email: 's***@abcd.com', phone: '***-***-9988', account: 'WLS-88708', mobile_number: '000-000-0018' },
    line_of_business: 'Wireless', risk_score: 30,
    created_at: '2026-05-05T08:30:00Z', updated_at: '2026-05-05T08:30:00Z',
    comments_count: 1, description: 'Customer appealing credit denial for device upgrade - claims identity was verified in store',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 30, priority: 'low', confidence: 60, flags: ['credit_appeal', 'in_store_verified'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'store_ip', imei: 'known_device', confidence: 95 },
      summarization: 'Customer visited retail store, showed valid ID, but credit check failed due to prior delinquency. Customer claims this is resolved and wants re-evaluation.',
      decision: { recommendation: 'approve', confidence: 65, reasoning: 'In-store verification passed. Prior delinquency may be resolved. Low risk to re-run credit check.' }
    },
    investigation_score: { selected_factors: [], score: 0, investigator: null, notes: '', timestamp: null },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-05T08:31:00Z', reason: null },
    ],
    comments: [
      { id: 'c24', author: 'Triage Agent', text: 'Low risk appeal. In-store ID verification passed.', created_at: '2026-05-05T08:31:00Z' },
    ]
  },
  {
    id: 'FPM-019', ucm_ticket_id: 'UCM-5534', order_id: 'ORD-9994',
    ticket_type: 'general', priority: 'low', status: 'assigned',
    disposition: null, sla_status: 'on_track', assigned_to: 'usr-002',
    customer: { name: 'Customer 19', email: 't***@abcd.com', phone: '***-***-1100', account: 'WLS-77809', mobile_number: '000-000-0019' },
    line_of_business: 'Wireless', risk_score: 20,
    created_at: '2026-05-05T10:00:00Z', updated_at: '2026-05-05T10:00:00Z',
    comments_count: 1, description: 'Billing dispute - customer claims charges for services not subscribed',
    linked_cases: [],
    agent_insights: {
      triage: { risk_score: 20, priority: 'low', confidence: 55, flags: ['billing_dispute'] },
      verification: { phone: 'match', email: 'match', address: 'match', ip: 'clean', imei: 'known_device', confidence: 98 },
      summarization: 'Customer disputing $45 in add-on service charges. Claims they never subscribed. Account shows subscription was added via IVR 2 months ago.',
      decision: { recommendation: 'approve', confidence: 60, reasoning: 'Likely legitimate billing dispute. IVR recording should be reviewed for consent verification.' }
    },
    investigation_score: { selected_factors: [], score: 0, investigator: null, notes: '', timestamp: null },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-05T10:01:00Z', reason: null },
    ],
    comments: [
      { id: 'c25', author: 'Triage Agent', text: 'Billing dispute. Review IVR recording for consent.', created_at: '2026-05-05T10:01:00Z' },
    ]
  },
  {
    id: 'FPM-020', ucm_ticket_id: 'UCM-5535', order_id: 'ORD-9995',
    ticket_type: 'fraud_ordering', priority: 'critical', status: 'in_progress',
    disposition: null, sla_status: 'at_risk', assigned_to: 'usr-001',
    customer: { name: 'Customer 20', email: 'x***@abcd.com', phone: '***-***-2200', account: 'WLS-66910', mobile_number: '000-000-0020' },
    line_of_business: 'Wireless', risk_score: 96,
    created_at: '2026-05-05T14:00:00Z', updated_at: '2026-05-06T08:00:00Z',
    comments_count: 2, description: 'Massive multi-line fraud - 8 new lines activated with devices shipped to known drop address',
    linked_cases: ['FPM-004'],
    agent_insights: {
      triage: { risk_score: 96, priority: 'critical', confidence: 97, flags: ['multi_line_8', 'drop_address', 'known_ring', 'velocity_extreme'] },
      verification: { phone: 'voip', email: 'disposable', address: 'drop_address_db', ip: 'tor_exit_node', imei: 'bulk_purchase', confidence: 8 },
      summarization: '8 new lines activated in 45 minutes with $12,800 in device financing. Ship-to address matches known drop location from FPM-004. TOR exit node IP, disposable email, VoIP phone.',
      decision: { recommendation: 'reject', confidence: 99, reasoning: 'Extreme fraud indicators across all dimensions. Known drop address, TOR, disposable identifiers. Connected to prior fraud ring FPM-004.' }
    },
    investigation_score: { selected_factors: ['RF-01', 'RF-02', 'RF-03', 'RF-06', 'RF-07'], score: 50, investigator: 'Investigator 1', notes: 'Connected to FPM-004 ring', timestamp: '2026-05-05T15:00:00Z' },
    status_history: [
      { from: 'unassigned', to: 'assigned', changed_by: 'system', changed_at: '2026-05-05T14:01:00Z', reason: null },
      { from: 'assigned', to: 'in_progress', changed_by: 'usr-001', changed_at: '2026-05-05T15:00:00Z', reason: null },
    ],
    comments: [
      { id: 'c26', author: 'Triage Agent', text: 'CRITICAL: 8-line fraud burst. Known drop address from FPM-004.', created_at: '2026-05-05T14:01:00Z' },
      { id: 'c27', author: 'Investigator 1', text: 'Connected to organized ring. Shipments intercepted. Working with law enforcement.', created_at: '2026-05-05T15:30:00Z' },
    ]
  },
];

export const ORDERS = [
  { order_id: 'ORD-9982', case_id: 'FPM-001', customer: 'Customer 1', channel: 'Dealer', amount: 1399.99, items: 1, ship_address: '100 Street A, City A TX', status: 'Held', created_at: '2026-04-28', risk_flags: ['sim_swap', 'call_forwarding'], device: 'iPhone 15 Pro Max', imei: '352910XXXXXXX', line: '000-000-0001' },
  { order_id: 'ORD-9981', case_id: 'FPM-001', customer: 'Customer 1', channel: 'Online', amount: 0, items: 0, ship_address: 'N/A', status: 'Suspended', created_at: '2026-04-28', risk_flags: ['sim_swap_off_hours'], device: 'SIM Swap', imei: 'N/A', line: '000-000-0001' },
  { order_id: 'ORD-9980', case_id: 'FPM-002', customer: 'Customer 2', channel: 'Retail Store A', amount: 1399.99, items: 1, ship_address: '200 Street B, City B TX', status: 'Approved', created_at: '2026-04-29', risk_flags: ['multi_store'], device: 'iPhone 15 Pro Max', imei: '353120XXXXXXX', line: '000-000-0002' },
  { order_id: 'ORD-9983', case_id: 'FPM-002', customer: 'Customer 2', channel: 'Retail Store B', amount: 1399.99, items: 1, ship_address: '300 Street C, City C TX', status: 'Pending', created_at: '2026-04-29', risk_flags: ['velocity_48h', 'addr_variation'], device: 'iPhone 15 Pro Max', imei: '353121XXXXXXX', line: '469-555-5679' },
  { order_id: 'ORD-9984', case_id: 'FPM-003', customer: 'Customer 3', channel: 'IVR', amount: 0, items: 0, ship_address: 'N/A', status: 'Completed', created_at: '2026-04-30', risk_flags: [], device: 'Plan Upgrade', imei: 'N/A', line: '000-000-0003' },
  { order_id: 'ORD-9978', case_id: 'FPM-004', customer: 'Customer 4', channel: 'Online', amount: 1499.99, items: 1, ship_address: '400 Street D, City D FL', status: 'Held', created_at: '2026-04-22', risk_flags: ['synthetic_id', 'drop_address', 'deceased_ssn'], device: 'iPhone 15 Pro Max', imei: '354001XXXXXXX', line: '000-000-0004' },
  { order_id: 'ORD-9977', case_id: 'FPM-004', customer: 'Customer 4', channel: 'Online', amount: 1299.99, items: 1, ship_address: '400 Street D, City D FL', status: 'Held', created_at: '2026-04-22', risk_flags: ['multi_line', 'same_drop_addr'], device: 'Samsung S24 Ultra', imei: '354002XXXXXXX', line: '000-000-0041' },
  { order_id: 'ORD-9976A', case_id: 'FPM-004', customer: 'Customer 4', channel: 'Online', amount: 1599.99, items: 1, ship_address: '400 Street D, City D FL', status: 'Held', created_at: '2026-04-22', risk_flags: ['5_lines_3h', 'velocity'], device: 'Google Pixel 8 Pro', imei: '354003XXXXXXX', line: '000-000-0042' },
  { order_id: 'ORD-9985', case_id: 'FPM-005', customer: 'Customer 5', channel: 'Online', amount: 0, items: 0, ship_address: 'N/A', status: 'Blocked', created_at: '2026-04-30', risk_flags: ['sim_swap_unknown_device', 'banking_reset'], device: 'SIM Swap', imei: '359900XXXXXXX', line: '000-000-0005' },
  { order_id: 'ORD-9970', case_id: 'FPM-006', customer: 'Customer 6', channel: 'Dealer DLR-889', amount: 0, items: 12, ship_address: 'Dealer Location, City E TX', status: 'Reversed', created_at: '2026-04-20', risk_flags: ['dealer_fraud', 'bulk_activation', 'commission_farm'], device: '12 Line Activations', imei: 'Multiple', line: 'Multiple' },
  { order_id: 'ORD-9975', case_id: 'FPM-007', customer: 'Customer 7', channel: 'N/A (IRSF)', amount: 12400.00, items: 412, ship_address: 'N/A', status: 'Blocked', created_at: '2026-04-26', risk_flags: ['irsf', 'premium_rate', 'somalia_latvia'], device: 'Call Fraud', imei: '358800XXXXXXX', line: '000-000-0007' },
  { order_id: 'ORD-9976', case_id: 'FPM-008', customer: 'Customer 8', channel: 'Online', amount: 1299.99, items: 1, ship_address: '400 Street D, City D FL', status: 'Canceled', created_at: '2026-04-24', risk_flags: ['fake_id', 'temp_email', 'immediate_roaming'], device: 'Samsung S24 Ultra', imei: '354010XXXXXXX', line: '000-000-0008' },
  { order_id: 'ORD-9986', case_id: 'FPM-009', customer: 'Customer 9', channel: 'App', amount: 0, items: 0, ship_address: 'N/A', status: 'No Action', created_at: '2026-04-30', risk_flags: [], device: 'N/A (Login Attempt)', imei: 'Known', line: '000-000-0009' },
  { order_id: 'ORD-9972', case_id: 'FPM-010', customer: 'Customer 10', channel: 'Online', amount: 1299.99, items: 1, ship_address: '500 Street F, City F CO', status: 'On Hold', created_at: '2026-04-25', risk_flags: ['financing_default', 'new_address'], device: 'Samsung S24 Ultra', imei: '354020XXXXXXX', line: '000-000-0010' },
];

export const FRAUD_MAP_DATA = {
  states: [
    { state: 'CA', name: 'California', fraud_impact: 312, confirmed: 118, zip_count: 52, top_zips: ['90210', '90001', '94102'] },
    { state: 'TX', name: 'Texas', fraud_impact: 267, confirmed: 98, zip_count: 44, top_zips: ['75201', '77001', '73301'] },
    { state: 'FL', name: 'Florida', fraud_impact: 198, confirmed: 82, zip_count: 38, top_zips: ['33101', '32801', '33301'] },
    { state: 'NY', name: 'New York', fraud_impact: 176, confirmed: 67, zip_count: 32, top_zips: ['10001', '10010', '11201'] },
    { state: 'IL', name: 'Illinois', fraud_impact: 112, confirmed: 44, zip_count: 22, top_zips: ['60601', '60611', '60614'] },
    { state: 'PA', name: 'Pennsylvania', fraud_impact: 89, confirmed: 33, zip_count: 17, top_zips: ['19101', '15201', '18101'] },
    { state: 'OH', name: 'Ohio', fraud_impact: 74, confirmed: 28, zip_count: 14, top_zips: ['43201', '44101', '45201'] },
    { state: 'GA', name: 'Georgia', fraud_impact: 68, confirmed: 26, zip_count: 12, top_zips: ['30301', '30901', '31401'] },
    { state: 'AZ', name: 'Arizona', fraud_impact: 56, confirmed: 21, zip_count: 10, top_zips: ['85001', '85201', '86001'] },
    { state: 'NV', name: 'Nevada', fraud_impact: 51, confirmed: 20, zip_count: 9, top_zips: ['89101', '89501', '89001'] },
    { state: 'WA', name: 'Washington', fraud_impact: 44, confirmed: 16, zip_count: 9, top_zips: ['98101', '98201', '99201'] },
    { state: 'CO', name: 'Colorado', fraud_impact: 38, confirmed: 14, zip_count: 7, top_zips: ['80201', '80301', '80901'] },
    { state: 'NC', name: 'North Carolina', fraud_impact: 95, confirmed: 36, zip_count: 18, top_zips: ['27601', '28201', '27701'] },
    { state: 'MI', name: 'Michigan', fraud_impact: 82, confirmed: 31, zip_count: 16, top_zips: ['48201', '49501', '48601'] },
    { state: 'NJ', name: 'New Jersey', fraud_impact: 78, confirmed: 29, zip_count: 15, top_zips: ['07101', '07302', '08601'] },
    { state: 'VA', name: 'Virginia', fraud_impact: 72, confirmed: 27, zip_count: 14, top_zips: ['22301', '23219', '20101'] },
    { state: 'MA', name: 'Massachusetts', fraud_impact: 65, confirmed: 24, zip_count: 11, top_zips: ['02101', '02201', '01101'] },
    { state: 'TN', name: 'Tennessee', fraud_impact: 58, confirmed: 22, zip_count: 11, top_zips: ['37201', '38101', '37901'] },
    { state: 'IN', name: 'Indiana', fraud_impact: 52, confirmed: 19, zip_count: 10, top_zips: ['46201', '46801', '47901'] },
    { state: 'MO', name: 'Missouri', fraud_impact: 48, confirmed: 18, zip_count: 9, top_zips: ['63101', '64101', '65201'] },
    { state: 'MD', name: 'Maryland', fraud_impact: 46, confirmed: 17, zip_count: 8, top_zips: ['21201', '20601', '21401'] },
    { state: 'WI', name: 'Wisconsin', fraud_impact: 42, confirmed: 15, zip_count: 8, top_zips: ['53201', '53701', '54301'] },
    { state: 'MN', name: 'Minnesota', fraud_impact: 40, confirmed: 15, zip_count: 8, top_zips: ['55401', '55101', '56001'] },
    { state: 'SC', name: 'South Carolina', fraud_impact: 37, confirmed: 14, zip_count: 7, top_zips: ['29201', '29401', '29601'] },
    { state: 'AL', name: 'Alabama', fraud_impact: 35, confirmed: 13, zip_count: 7, top_zips: ['35201', '36601', '35801'] },
    { state: 'LA', name: 'Louisiana', fraud_impact: 34, confirmed: 13, zip_count: 6, top_zips: ['70112', '70801', '71101'] },
    { state: 'KY', name: 'Kentucky', fraud_impact: 32, confirmed: 12, zip_count: 6, top_zips: ['40201', '40501', '41001'] },
    { state: 'OR', name: 'Oregon', fraud_impact: 31, confirmed: 11, zip_count: 6, top_zips: ['97201', '97401', '97301'] },
    { state: 'OK', name: 'Oklahoma', fraud_impact: 29, confirmed: 11, zip_count: 5, top_zips: ['73101', '74101', '73401'] },
    { state: 'CT', name: 'Connecticut', fraud_impact: 28, confirmed: 10, zip_count: 5, top_zips: ['06101', '06501', '06901'] },
    { state: 'IA', name: 'Iowa', fraud_impact: 24, confirmed: 9, zip_count: 5, top_zips: ['50301', '52801', '50010'] },
    { state: 'MS', name: 'Mississippi', fraud_impact: 23, confirmed: 9, zip_count: 4, top_zips: ['39201', '39501', '38601'] },
    { state: 'AR', name: 'Arkansas', fraud_impact: 22, confirmed: 8, zip_count: 4, top_zips: ['72201', '72701', '71601'] },
    { state: 'KS', name: 'Kansas', fraud_impact: 21, confirmed: 8, zip_count: 4, top_zips: ['66101', '67201', '66601'] },
    { state: 'UT', name: 'Utah', fraud_impact: 20, confirmed: 7, zip_count: 4, top_zips: ['84101', '84601', '84301'] },
    { state: 'NE', name: 'Nebraska', fraud_impact: 18, confirmed: 7, zip_count: 3, top_zips: ['68101', '68501', '68801'] },
    { state: 'NM', name: 'New Mexico', fraud_impact: 17, confirmed: 6, zip_count: 3, top_zips: ['87101', '88001', '87501'] },
    { state: 'WV', name: 'West Virginia', fraud_impact: 15, confirmed: 6, zip_count: 3, top_zips: ['25301', '26003', '24701'] },
    { state: 'ID', name: 'Idaho', fraud_impact: 14, confirmed: 5, zip_count: 3, top_zips: ['83701', '83201', '83301'] },
    { state: 'HI', name: 'Hawaii', fraud_impact: 13, confirmed: 5, zip_count: 2, top_zips: ['96801', '96813'] },
    { state: 'NH', name: 'New Hampshire', fraud_impact: 12, confirmed: 4, zip_count: 2, top_zips: ['03101', '03301'] },
    { state: 'ME', name: 'Maine', fraud_impact: 11, confirmed: 4, zip_count: 2, top_zips: ['04101', '04401'] },
    { state: 'MT', name: 'Montana', fraud_impact: 10, confirmed: 4, zip_count: 2, top_zips: ['59601', '59101'] },
    { state: 'RI', name: 'Rhode Island', fraud_impact: 10, confirmed: 3, zip_count: 2, top_zips: ['02901', '02860'] },
    { state: 'DE', name: 'Delaware', fraud_impact: 9, confirmed: 3, zip_count: 2, top_zips: ['19901', '19801'] },
    { state: 'SD', name: 'South Dakota', fraud_impact: 8, confirmed: 3, zip_count: 2, top_zips: ['57101', '57701'] },
    { state: 'ND', name: 'North Dakota', fraud_impact: 7, confirmed: 2, zip_count: 1, top_zips: ['58102'] },
    { state: 'AK', name: 'Alaska', fraud_impact: 6, confirmed: 2, zip_count: 1, top_zips: ['99501'] },
    { state: 'VT', name: 'Vermont', fraud_impact: 5, confirmed: 2, zip_count: 1, top_zips: ['05401'] },
    { state: 'WY', name: 'Wyoming', fraud_impact: 4, confirmed: 1, zip_count: 1, top_zips: ['82001'] },
  ],
  fraud_rings: [
    { id: 'FR-042', nodes: 8, edges: 12, shared: ['phone', 'IMEI'], zips: ['33101', '33102', '33301'], cities: ['City D', 'City G'], risk_level: 'critical', type: 'SIM Swap Ring' },
    { id: 'FR-038', nodes: 5, edges: 7, shared: ['address', 'phone'], zips: ['75201', '75202'], cities: ['City A'], risk_level: 'high', type: 'Device Financing Ring' },
    { id: 'FR-041', nodes: 6, edges: 9, shared: ['email', 'IMEI', 'address'], zips: ['90210', '90211', '90212'], cities: ['City H', 'City I'], risk_level: 'high', type: 'Subscription Fraud Ring' },
    { id: 'FR-035', nodes: 4, edges: 5, shared: ['phone'], zips: ['60601', '60611'], cities: ['City J'], risk_level: 'medium', type: 'Port-Out Ring' },
    { id: 'FR-039', nodes: 9, edges: 14, shared: ['email', 'phone', 'IMEI', 'address'], zips: ['10001', '10010', '10011'], cities: ['City K'], risk_level: 'critical', type: 'Multi-Vector Ring' },
  ],
  // Raw link data for union-find fraud ring detection (Req 9.5)
  // Each link represents a shared PII attribute between two ZIP codes
  raw_links: [
    // Ring 1: Region D SIM Swap Ring (shared phone, IMEI across 3 ZIPs)
    { source_zip: '33101', target_zip: '33102', link_type: 'phone', value: '***-***-XX34' },
    { source_zip: '33102', target_zip: '33301', link_type: 'phone', value: '***-***-XX56' },
    { source_zip: '33101', target_zip: '33301', link_type: 'phone', value: '***-***-XX78' },
    { source_zip: '33101', target_zip: '33102', link_type: 'phone', value: '***-***-XX90' },
    { source_zip: '33102', target_zip: '33301', link_type: 'phone', value: '***-***-XX12' },
    // Ring 2: Region A Device Financing Ring (shared address, phone across 2 ZIPs)
    { source_zip: '75201', target_zip: '75202', link_type: 'address', value: '*** Street X (masked)' },
    { source_zip: '75201', target_zip: '75202', link_type: 'phone', value: '***-***-XX44' },
    { source_zip: '75202', target_zip: '75201', link_type: 'address', value: '*** Street Y (masked)' },
    // Ring 3: Region H Subscription Fraud Ring (shared email, IMEI, address across 3 ZIPs)
    { source_zip: '90210', target_zip: '90211', link_type: 'email', value: '***@abcd.com' },
    { source_zip: '90211', target_zip: '90212', link_type: 'email', value: '***@abcd.com' },
    { source_zip: '90210', target_zip: '90212', link_type: 'address', value: '*** Street P (masked)' },
    { source_zip: '90210', target_zip: '90211', link_type: 'address', value: '*** Street Q (masked)' },
    // Ring 4: Region J Port-Out Ring (shared phone across 2 ZIPs)
    { source_zip: '60601', target_zip: '60611', link_type: 'phone', value: '***-***-XX66' },
    { source_zip: '60611', target_zip: '60601', link_type: 'phone', value: '***-***-XX88' },
    // Ring 5: Region K Multi-Vector Ring (all link types across 3 ZIPs)
    { source_zip: '10001', target_zip: '10010', link_type: 'email', value: '***@abcd.com' },
    { source_zip: '10010', target_zip: '10011', link_type: 'phone', value: '***-***-XX22' },
    { source_zip: '10001', target_zip: '10011', link_type: 'address', value: '*** Street R (masked)' },
    { source_zip: '10001', target_zip: '10010', link_type: 'phone', value: '***-***-XX33' },
    { source_zip: '10010', target_zip: '10011', link_type: 'email', value: '***@abcd.com' },
    { source_zip: '10011', target_zip: '10001', link_type: 'address', value: '*** Street S (masked)' },
  ]
};

export const SLA_RULES = [
  { ticket_type: 'fraud_ordering', threshold_hours: 144, label: 'Fraud Ordering' },
  { ticket_type: 'fraud_non_ordering', threshold_hours: 144, label: 'Fraud Non-Ordering' },
  { ticket_type: 'credit_abuse_ordering', threshold_hours: 144, label: 'Credit Abuse Ordering' },
  { ticket_type: 'credit_abuse_sor', threshold_hours: 144, label: 'Credit Abuse SOR' },
  { ticket_type: 'credit_abuse_appeal', threshold_hours: 144, label: 'Credit Abuse Appeal' },
  { ticket_type: 'general', threshold_hours: 144, label: 'General' },
];

// SLA Priority Tier thresholds (hours) per Requirement 3.10
export const SLA_PRIORITY_TIERS = {
  urgent: 4,
  in_progress: 48,
  untouched: 144
};

export const FEEDBACK_METRICS = {
  total_decisions: 1842,
  ai_accuracy: 89.1,
  override_rate: 10.9,
  accept_rate: 89.1,
  by_disposition: {
    approve: { total: 620, correct: 582, accuracy: 93.9 },
    reject: { total: 534, correct: 468, accuracy: 87.6 },
    fraud_found: { total: 312, correct: 278, accuracy: 89.1 },
    customer_engagement: { total: 198, correct: 152, accuracy: 76.8 },
    cannot_determine: { total: 178, correct: 124, accuracy: 69.7 },
  },
  by_risk_band: {
    low: { range: '0-30', total: 523, correct: 498, accuracy: 95.2 },
    medium: { range: '31-60', total: 712, correct: 598, accuracy: 84.0 },
    high: { range: '61-100', total: 607, correct: 546, accuracy: 89.9 },
  },
  common_overrides: [
    'Reject → Customer engagement (SIM swap reported by customer - could be authorized)',
    'Reject → Approve (device financing with verified address change)',
    'Cannot determine → Reject (dealer activation pattern confirmed by secondary data)',
  ]
};

// Recent AI vs Human decision history (per-case comparison)
export const AI_VS_HUMAN_HISTORY = [
  { case_id: 'FPM-001', type: 'fraud_ordering', risk_score: 72, ai_recommendation: 'reject', ai_confidence: 88, human_disposition: 'customer_engagement', accepted: false, investigator: 'Investigator 1', resolved_at: '2026-04-28T14:30:00Z', reason: 'Customer confirmed authorized SIM swap' },
  { case_id: 'FPM-002', type: 'fraud_non_ordering', risk_score: 85, ai_recommendation: 'reject', ai_confidence: 92, human_disposition: 'reject', accepted: true, investigator: 'Investigator 2', resolved_at: '2026-04-28T11:15:00Z', reason: '' },
  { case_id: 'FPM-003', type: 'credit_abuse_ordering', risk_score: 12, ai_recommendation: 'approve', ai_confidence: 95, human_disposition: 'approve', accepted: true, investigator: 'Investigator 1', resolved_at: '2026-04-27T16:00:00Z', reason: '' },
  { case_id: 'FPM-004', type: 'fraud_ordering', risk_score: 68, ai_recommendation: 'customer_engagement', ai_confidence: 71, human_disposition: 'reject', accepted: false, investigator: 'Investigator 2', resolved_at: '2026-04-27T09:45:00Z', reason: 'Confirmed unauthorized access — immediate suspension needed' },
  { case_id: 'FPM-005', type: 'credit_abuse_sor', risk_score: 55, ai_recommendation: 'customer_engagement', ai_confidence: 65, human_disposition: 'customer_engagement', accepted: true, investigator: 'Investigator 1', resolved_at: '2026-04-26T13:20:00Z', reason: '' },
  { case_id: 'FPM-006', type: 'general', risk_score: 91, ai_recommendation: 'reject', ai_confidence: 96, human_disposition: 'reject', accepted: true, investigator: 'Investigator 2', resolved_at: '2026-04-26T10:00:00Z', reason: '' },
  { case_id: 'FPM-007', type: 'fraud_ordering', risk_score: 45, ai_recommendation: 'cannot_determine', ai_confidence: 52, human_disposition: 'reject', accepted: false, investigator: 'Investigator 1', resolved_at: '2026-04-25T15:30:00Z', reason: 'Secondary data confirmed dealer activation ring' },
  { case_id: 'FPM-008', type: 'fraud_non_ordering', risk_score: 95, ai_recommendation: 'reject', ai_confidence: 97, human_disposition: 'reject', accepted: true, investigator: 'Investigator 2', resolved_at: '2026-04-25T09:00:00Z', reason: '' },
  { case_id: 'FPM-009', type: 'credit_abuse_appeal', risk_score: 38, ai_recommendation: 'customer_engagement', ai_confidence: 73, human_disposition: 'approve', accepted: false, investigator: 'Investigator 1', resolved_at: '2026-04-24T14:15:00Z', reason: 'Verified identity — false positive from address mismatch' },
  { case_id: 'FPM-010', type: 'fraud_ordering', risk_score: 82, ai_recommendation: 'reject', ai_confidence: 89, human_disposition: 'reject', accepted: true, investigator: 'Investigator 2', resolved_at: '2026-04-24T08:30:00Z', reason: '' },
];

export const NLP_QUERY_TEMPLATES = [
  { label: 'SIM swaps last 30 days by state', query: 'Show all SIM swap events grouped by state in the last 30 days' },
  { label: 'Device financing > $1000', query: 'Show device financing orders with amount greater than $1000' },
  { label: 'IRSF calls to premium numbers', query: 'Show calls to international premium rate numbers flagged as IRSF' },
  { label: 'Dealer activations by store', query: 'Show line activation count by dealer ID in the last 7 days' },
  { label: 'Port-out velocity by account', query: 'Show accounts with more than 2 port-out requests in 30 days' },
  { label: 'Device IMEI blacklist hits', query: 'Show orders where IMEI matches the stolen device blacklist' },
];

export const AUDIT_TRAIL_SAMPLE = [
  { id: 'AT-001', case_id: 'FPM-001', action: 'case_created', actor: 'UCM_Poller', timestamp: '2026-04-28T10:30:00Z', details: 'Ingested from UCM ticket UCM-5521 - SIM swap alert' },
  { id: 'AT-002', case_id: 'FPM-001', action: 'ai_decision', actor: 'Triage Agent', timestamp: '2026-04-28T10:30:05Z', details: 'Risk score: 82, Priority: CRITICAL - SIM swap + call forwarding pattern' },
  { id: 'AT-003', case_id: 'FPM-001', action: 'data_collection', actor: 'Data Collection Agent', timestamp: '2026-04-28T10:30:10Z', details: 'Gathered data from SIM Registry, GSMA IMEI, CDR, Number Portability DB, and 11 other sources via MCP' },
  { id: 'AT-004', case_id: 'FPM-001', action: 'pii_masking', actor: 'PII Masker', timestamp: '2026-04-28T10:30:12Z', details: 'Masked SSN, phone, IMEI, address for LLM processing' },
  { id: 'AT-005', case_id: 'FPM-001', action: 'verification', actor: 'Verification Agent', timestamp: '2026-04-28T10:30:15Z', details: 'Cross-reference complete. IMEI unknown, email mismatch, call forwarding active.' },
  { id: 'AT-006', case_id: 'FPM-001', action: 'auto_assignment', actor: 'Orchestrator Agent', timestamp: '2026-04-28T10:31:00Z', details: 'Assigned to Investigator 1 (investigator) - SIM swap specialist queue' },
  { id: 'AT-007', case_id: 'FPM-001', action: 'status_change', actor: 'Investigator 1', timestamp: '2026-04-28T11:00:00Z', details: 'Status: assigned → open' },
  { id: 'AT-008', case_id: 'FPM-001', action: 'nlp_query', actor: 'Investigator 1', timestamp: '2026-04-29T09:15:00Z', details: 'Query: "show SIM swap history for this mobile number last 90 days"' },
  { id: 'AT-009', case_id: 'FPM-001', action: 'confidence_gate_block', actor: 'Confidence Gate', timestamp: '2026-04-28T10:30:08Z', details: 'Auto-reject blocked: confidence 72% below threshold 85% - requires human review' },
  { id: 'AT-010', case_id: 'FPM-007', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-05-01T08:00:00Z', details: 'SLA breached: IRSF case open >2h for CRITICAL priority (threshold: 2h)' },
  { id: 'AT-011', case_id: 'FPM-002', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-05-02T12:00:00Z', details: 'SLA breached: device financing case open >48h for HIGH priority (threshold: 48h)' },
  { id: 'AT-012', case_id: 'FPM-004', action: 'sla_breach', actor: 'sla_monitor_system', timestamp: '2026-04-23T09:00:00Z', details: 'SLA breached: subscription fraud case open >24h for CRITICAL priority (threshold: 24h)' },
  { id: 'AT-013', case_id: 'FPM-003', action: 'confidence_gate_pass', actor: 'Confidence Gate', timestamp: '2026-04-30T14:20:05Z', details: 'Auto-decision eligible: confidence 94% meets threshold 85% - plan upgrade approved' },
  { id: 'AT-014', case_id: 'FPM-006', action: 'pipeline_push', actor: 'Orchestrator Agent', timestamp: '2026-04-25T16:00:00Z', details: 'Disposition "fraud_found" pushed to Order Control, Mobile IT API, UCM. Dealer DLR-889 suspended.' },
];

// ==================== LEADERSHIP ANALYTICS DATA ====================

export const LEADERSHIP_METRICS = {
  fraud_loss_prevented: 1874500,
  ai_detection_accuracy: 89.1,
  high_risk_alerts: 47,
  sla_breaches_total: 12,
  fraud_trend_delta: 8.3,
};

export const ORDER_ANALYTICS = {
  daily: [
    { period: 'May 1', total_orders: 42, closed: 28, escalated: 5, pending: 9 },
    { period: 'May 2', total_orders: 38, closed: 25, escalated: 4, pending: 9 },
    { period: 'May 3', total_orders: 45, closed: 32, escalated: 6, pending: 7 },
    { period: 'May 4', total_orders: 31, closed: 22, escalated: 3, pending: 6 },
    { period: 'May 5', total_orders: 50, closed: 35, escalated: 7, pending: 8 },
    { period: 'May 6', total_orders: 47, closed: 33, escalated: 5, pending: 9 },
    { period: 'May 7', total_orders: 36, closed: 24, escalated: 4, pending: 8 },
    { period: 'May 8', total_orders: 44, closed: 30, escalated: 6, pending: 8 },
    { period: 'May 9', total_orders: 52, closed: 38, escalated: 5, pending: 9 },
    { period: 'May 10', total_orders: 41, closed: 29, escalated: 4, pending: 8 },
    { period: 'May 11', total_orders: 48, closed: 34, escalated: 6, pending: 8 },
    { period: 'May 12', total_orders: 39, closed: 26, escalated: 5, pending: 8 },
  ],
  weekly: [
    { period: 'W1 Apr', total_orders: 285, closed: 198, escalated: 32, pending: 55 },
    { period: 'W2 Apr', total_orders: 312, closed: 224, escalated: 38, pending: 50 },
    { period: 'W3 Apr', total_orders: 298, closed: 210, escalated: 35, pending: 53 },
    { period: 'W4 Apr', total_orders: 340, closed: 252, escalated: 41, pending: 47 },
    { period: 'W1 May', total_orders: 325, closed: 238, escalated: 37, pending: 50 },
    { period: 'W2 May', total_orders: 290, closed: 205, escalated: 34, pending: 51 },
  ],
  monthly: [
    { period: 'Jan', total_orders: 1120, closed: 812, escalated: 128, pending: 180 },
    { period: 'Feb', total_orders: 1045, closed: 768, escalated: 115, pending: 162 },
    { period: 'Mar', total_orders: 1230, closed: 920, escalated: 142, pending: 168 },
    { period: 'Apr', total_orders: 1340, closed: 1008, escalated: 155, pending: 177 },
    { period: 'May', total_orders: 890, closed: 640, escalated: 98, pending: 152 },
  ],
  yearly: [
    { period: '2024', total_orders: 11200, closed: 8120, escalated: 1280, pending: 1800 },
    { period: '2025', total_orders: 13400, closed: 10080, escalated: 1550, pending: 1770 },
    { period: '2026', total_orders: 5630, closed: 4148, escalated: 638, pending: 844 },
  ],
};

export const FRAUD_TREND = {
  daily: [
    { period: 'May 1', fraud_cases: 8, loss_amount: 42000, detection_rate: 89 },
    { period: 'May 2', fraud_cases: 6, loss_amount: 31000, detection_rate: 92 },
    { period: 'May 3', fraud_cases: 10, loss_amount: 55000, detection_rate: 88 },
    { period: 'May 4', fraud_cases: 5, loss_amount: 28000, detection_rate: 94 },
    { period: 'May 5', fraud_cases: 12, loss_amount: 67000, detection_rate: 86 },
    { period: 'May 6', fraud_cases: 9, loss_amount: 48000, detection_rate: 90 },
    { period: 'May 7', fraud_cases: 7, loss_amount: 38000, detection_rate: 91 },
    { period: 'May 8', fraud_cases: 11, loss_amount: 59000, detection_rate: 87 },
    { period: 'May 9', fraud_cases: 8, loss_amount: 43000, detection_rate: 93 },
    { period: 'May 10', fraud_cases: 6, loss_amount: 32000, detection_rate: 95 },
    { period: 'May 11', fraud_cases: 9, loss_amount: 50000, detection_rate: 90 },
    { period: 'May 12', fraud_cases: 7, loss_amount: 36000, detection_rate: 92 },
  ],
  weekly: [
    { period: 'W1 Apr', fraud_cases: 52, loss_amount: 285000, detection_rate: 88 },
    { period: 'W2 Apr', fraud_cases: 61, loss_amount: 340000, detection_rate: 90 },
    { period: 'W3 Apr', fraud_cases: 48, loss_amount: 260000, detection_rate: 91 },
    { period: 'W4 Apr', fraud_cases: 58, loss_amount: 315000, detection_rate: 93 },
    { period: 'W1 May', fraud_cases: 55, loss_amount: 298000, detection_rate: 92 },
    { period: 'W2 May', fraud_cases: 44, loss_amount: 240000, detection_rate: 94 },
  ],
  monthly: [
    { period: 'Jan', fraud_cases: 185, loss_amount: 980000, detection_rate: 86 },
    { period: 'Feb', fraud_cases: 172, loss_amount: 910000, detection_rate: 88 },
    { period: 'Mar', fraud_cases: 210, loss_amount: 1120000, detection_rate: 89 },
    { period: 'Apr', fraud_cases: 198, loss_amount: 1050000, detection_rate: 91 },
    { period: 'May', fraud_cases: 142, loss_amount: 760000, detection_rate: 93 },
  ],
  yearly: [
    { period: '2024', fraud_cases: 2180, loss_amount: 11500000, detection_rate: 84 },
    { period: '2025', fraud_cases: 2450, loss_amount: 13200000, detection_rate: 89 },
    { period: '2026', fraud_cases: 907, loss_amount: 4820000, detection_rate: 92 },
  ],
};
