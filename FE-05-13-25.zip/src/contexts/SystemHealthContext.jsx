import React, { createContext, useContext, useState } from 'react';

const SystemHealthContext = createContext(null);

const DEFAULT_HEALTH = {
  openai_api: true,
  redshift: true,
  mcp_servers: true,
  ucm_poller: true
};

export function SystemHealthProvider({ children }) {
  const [health, setHealth] = useState(DEFAULT_HEALTH);

  const toggleService = (service) => {
    setHealth(prev => ({ ...prev, [service]: !prev[service] }));
  };

  const isFullyOperational = Object.values(health).every(v => v);
  const degradedServices = Object.entries(health).filter(([, v]) => !v).map(([k]) => k);

  return (
    <SystemHealthContext.Provider value={{ health, toggleService, isFullyOperational, degradedServices }}>
      {children}
    </SystemHealthContext.Provider>
  );
}

export const useSystemHealth = () => useContext(SystemHealthContext);
