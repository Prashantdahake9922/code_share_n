import React, { createContext, useContext, useState, useEffect } from 'react';
import { CASES, SLA_PRIORITY_TIERS } from '../data/dummyData';

const CasesContext = createContext(null);

// Compute SLA status based on priority tier thresholds and case age
function computeSlaStatus(caseItem) {
  // Only compute for active cases
  const activeStatuses = ['unassigned', 'assigned', 'open', 'in_progress', 'escalated', 'pending_customer'];
  if (!activeStatuses.includes(caseItem.status)) return caseItem.sla_status;

  const now = new Date();
  const lastActivity = new Date(caseItem.updated_at || caseItem.created_at);
  const inactiveHours = (now - lastActivity) / (1000 * 60 * 60);

  // Determine tier: urgent (critical priority), in_progress (high/medium actively worked), untouched (low/unassigned)
  let tierKey = 'untouched';
  if (caseItem.priority === 'critical') tierKey = 'urgent';
  else if (['high', 'medium'].includes(caseItem.priority) && caseItem.status === 'in_progress') tierKey = 'in_progress';
  else if (caseItem.status === 'unassigned' || caseItem.status === 'assigned') tierKey = 'untouched';
  else tierKey = 'in_progress';

  const threshold = SLA_PRIORITY_TIERS[tierKey]; // hours
  const atRiskThreshold = threshold * 0.75; // 75% = at_risk

  if (inactiveHours >= threshold) return 'breached';
  if (inactiveHours >= atRiskThreshold) return 'at_risk';
  return 'on_track';
}

export function CasesProvider({ children }) {
  const [cases, setCases] = useState(CASES);
  const [selectedCase, setSelectedCase] = useState(null);
  const [filters, setFilters] = useState({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '' });
  const [sortField, setSortField] = useState('created_at');
  const [sortOrder, setSortOrder] = useState('desc');

  // Dynamically compute SLA statuses based on priority tiers
  useEffect(() => {
    setCases(prev => prev.map(c => ({ ...c, sla_status: computeSlaStatus(c) })));
  }, []); // Recompute on mount

  const updateCase = (caseId, updates) => {
    setCases(prev => prev.map(c => c.id === caseId ? { ...c, ...updates } : c));
    if (selectedCase && selectedCase.id === caseId) {
      setSelectedCase(prev => ({ ...prev, ...updates }));
    }
  };

  const addComment = (caseId, comment) => {
    setCases(prev => prev.map(c => {
      if (c.id === caseId) {
        return { ...c, comments: [...c.comments, comment], comments_count: c.comments_count + 1 };
      }
      return c;
    }));
  };

  const reassignCase = (caseId, newAssignee) => {
    setCases(prev => prev.map(c => {
      if (c.id === caseId) {
        return { ...c, assigned_to: newAssignee, updated_at: new Date().toISOString() };
      }
      return c;
    }));
  };

  const createCase = (newCase) => {
    const id = `FPM-${String(cases.length + 1).padStart(3, '0')}`;
    const fullCase = {
      id,
      ucm_ticket_id: newCase.ucm_ticket_id || '',
      order_id: newCase.order_id || '',
      ticket_type: newCase.ticket_type,
      priority: newCase.priority,
      status: newCase.assigned_to ? 'assigned' : 'unassigned',
      disposition: null,
      sla_status: 'on_track',
      assigned_to: newCase.assigned_to || null,
      customer: {
        name: newCase.customer_name,
        email: newCase.customer_email,
        phone: newCase.customer_phone || '',
        account: newCase.customer_account || ''
      },
      line_of_business: newCase.line_of_business || 'Wireless',
      risk_score: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      comments_count: 0,
      description: newCase.description || '',
      linked_cases: [],
      agent_insights: {
        triage: { risk_score: 0, priority: newCase.priority, confidence: 0, flags: [] },
        verification: { phone: 'pending', email: 'pending', address: 'pending', ip: 'pending', imei: 'pending', confidence: 0 },
        summarization: 'Manually created case — awaiting AI pipeline processing.',
        decision: { recommendation: 'cannot_determine', confidence: 0, reasoning: 'Manual case — no AI decision yet.' }
      },
      investigation_score: { selected_factors: [], score: 0 },
      status_history: [
        { from: 'new', to: newCase.assigned_to ? 'assigned' : 'unassigned', changed_by: 'manual', changed_at: new Date().toISOString(), reason: 'Manually created' }
      ],
      comments: []
    };
    setCases(prev => [fullCase, ...prev]);
    return fullCase;
  };

  const linkCases = (caseId1, caseId2) => {
    setCases(prev => prev.map(c => {
      if (c.id === caseId1 && !c.linked_cases.includes(caseId2)) {
        return { ...c, linked_cases: [...c.linked_cases, caseId2] };
      }
      if (c.id === caseId2 && !c.linked_cases.includes(caseId1)) {
        return { ...c, linked_cases: [...c.linked_cases, caseId1] };
      }
      return c;
    }));
  };

  const getFilteredCases = (userRole, userId) => {
    let filtered = [...cases];

    if (userRole === 'investigator') {
      filtered = filtered.filter(c => c.assigned_to === userId);
    }

    if (filters.status) filtered = filtered.filter(c => c.status === filters.status);
    if (filters.priority) filtered = filtered.filter(c => c.priority === filters.priority);
    if (filters.ticket_type) filtered = filtered.filter(c => c.ticket_type === filters.ticket_type);
    if (filters.assigned_to) filtered = filtered.filter(c => c.assigned_to === filters.assigned_to);
    if (filters.dateFrom) filtered = filtered.filter(c => c.created_at >= filters.dateFrom);
    if (filters.dateTo) filtered = filtered.filter(c => c.created_at <= filters.dateTo + 'T23:59:59Z');
    if (filters.search) {
      const s = filters.search.toLowerCase();
      filtered = filtered.filter(c =>
        c.id.toLowerCase().includes(s) ||
        c.ucm_ticket_id.toLowerCase().includes(s) ||
        c.order_id.toLowerCase().includes(s) ||
        c.customer.name.toLowerCase().includes(s) ||
        c.customer.email.toLowerCase().includes(s) ||
        c.customer.phone.toLowerCase().includes(s) ||
        c.customer.account.toLowerCase().includes(s) ||
        (c.customer.mobile_number || '').toLowerCase().includes(s) ||
        (c.assigned_to || '').toLowerCase().includes(s)
      );
    }

    filtered.sort((a, b) => {
      const aVal = a[sortField] || '';
      const bVal = b[sortField] || '';
      if (sortOrder === 'asc') return aVal > bVal ? 1 : -1;
      return aVal < bVal ? 1 : -1;
    });

    return filtered;
  };

  return (
    <CasesContext.Provider value={{
      cases, selectedCase, setSelectedCase, filters, setFilters,
      sortField, setSortField, sortOrder, setSortOrder,
      updateCase, addComment, reassignCase, createCase, linkCases, getFilteredCases
    }}>
      {children}
    </CasesContext.Provider>
  );
}

export const useCases = () => useContext(CasesContext);
