import React from 'react';

export default function KPICard({ title, value, color }) {
  return (
    <div
      className="kpi-card"
      style={{
        // borderTop: `3.5px solid ${color}`,
      }}
    >
      <div className="kpi-content">
        <div style={{
          width: "6px",
          height: "6px",
          backgroundColor: color,
          borderRadius:"5px",
          position:"absolute",
          right:"6px",
          top:"6px"
        }}/>
        <div className="kpi-value" style={{ color }}>{value}</div>
        <div className="kpi-title">{title}</div>
      </div>
    </div>
  );
}
