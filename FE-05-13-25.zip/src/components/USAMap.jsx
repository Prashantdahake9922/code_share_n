import React, { useState, memo } from 'react';
import { ComposableMap, Geographies, Geography, Marker, Annotation } from 'react-simple-maps';

const GEO_URL = 'https://cdn.jsdelivr.net/npm/us-atlas@3/states-10m.json';

// State centroids for pin markers and labels (approximate lng/lat)
const STATE_CENTERS = {
  AL: [-86.9, 32.8], AK: [-153.5, 63.6], AZ: [-111.9, 34.2], AR: [-92.4, 34.8],
  CA: [-119.4, 37.2], CO: [-105.5, 39.0], CT: [-72.7, 41.6], DE: [-75.5, 39.0],
  FL: [-81.7, 28.6], GA: [-83.5, 32.7], HI: [-155.5, 20.0], ID: [-114.7, 44.2],
  IL: [-89.2, 40.0], IN: [-86.3, 39.8], IA: [-93.5, 42.0], KS: [-98.3, 38.5],
  KY: [-84.8, 37.8], LA: [-92.0, 31.0], ME: [-69.2, 45.4], MD: [-76.6, 39.0],
  MA: [-71.8, 42.3], MI: [-84.7, 44.3], MN: [-94.3, 46.3], MS: [-89.7, 32.7],
  MO: [-92.5, 38.4], MT: [-109.6, 47.0], NE: [-99.8, 41.5], NV: [-116.6, 39.3],
  NH: [-71.5, 43.7], NJ: [-74.7, 40.1], NM: [-106.0, 34.5], NY: [-75.5, 42.9],
  NC: [-79.4, 35.6], ND: [-100.5, 47.5], OH: [-82.8, 40.3], OK: [-97.5, 35.5],
  OR: [-120.5, 44.0], PA: [-77.6, 40.9], RI: [-71.5, 41.7], SC: [-80.9, 33.9],
  SD: [-100.2, 44.4], TN: [-86.3, 35.8], TX: [-99.0, 31.5], UT: [-111.7, 39.5],
  VT: [-72.6, 44.0], VA: [-79.4, 37.5], WA: [-120.4, 47.4], WV: [-80.6, 38.6],
  WI: [-89.6, 44.6], WY: [-107.6, 43.0],
};

// Small NE states that need offset annotations (with dx, dy offsets)
const OFFSET_STATES = {
  VT: { dx: 30, dy: -15 },
  NH: { dx: 36, dy: -5 },
  MA: { dx: 40, dy: 0 },
  RI: { dx: 36, dy: 5 },
  CT: { dx: 36, dy: 10 },
  NJ: { dx: 30, dy: 5 },
  DE: { dx: 34, dy: 8 },
  MD: { dx: 40, dy: 15 },
  DC: { dx: 40, dy: 22 },
  HI: { dx: 25, dy: -15 },
};

// FIPS code → state abbreviation mapping
const FIPS_TO_STATE = {
  '01':'AL','02':'AK','04':'AZ','05':'AR','06':'CA','08':'CO','09':'CT','10':'DE',
  '11':'DC','12':'FL','13':'GA','15':'HI','16':'ID','17':'IL','18':'IN','19':'IA',
  '20':'KS','21':'KY','22':'LA','23':'ME','24':'MD','25':'MA','26':'MI','27':'MN',
  '28':'MS','29':'MO','30':'MT','31':'NE','32':'NV','33':'NH','34':'NJ','35':'NM',
  '36':'NY','37':'NC','38':'ND','39':'OH','40':'OK','41':'OR','42':'PA','44':'RI',
  '45':'SC','46':'SD','47':'TN','48':'TX','49':'UT','50':'VT','51':'VA','53':'WA',
  '54':'WV','55':'WI','56':'WY',
};

const PinMarker = memo(({ coordinates, value, color }) => (
  <Marker coordinates={coordinates}>
    <ellipse cx={0} cy={14} rx={5} ry={2.5} fill="rgba(0,0,0,0.2)" />
    <path
      d="M0,-12 C-7,-12 -12,-7 -12,-2 C-12,5 0,14 0,14 C0,14 12,5 12,-2 C12,-7 7,-12 0,-12Z"
      fill={color}
      stroke="#fff"
      strokeWidth="1.2"
    />
    <circle cx={0} cy={-3} r={4} fill="#fff" opacity={0.9} />
    <text
      textAnchor="middle"
      y={-1}
      style={{ fontSize: '5px', fontWeight: 800, fill: color, pointerEvents: 'none' }}
    >
      {value}
    </text>
  </Marker>
));

export default function USAMap({ data = [], getColor, onStateClick, regionMap, regionData, noPins }) {
  const [tooltip, setTooltip] = useState(null);

  // Build region lookup for aggregated tooltips
  const regionLookup = {};
  if (regionData) regionData.forEach(r => { regionLookup[r.region] = r; });

  const dataMap = {};
  data.forEach(d => { dataMap[d.state] = d; });

  // Only show pins on top-impact states to avoid clutter
  const pinStates = data
    .filter(d => d.fraud_impact >= 40 && STATE_CENTERS[d.state])
    .sort((a, b) => b.fraud_impact - a.fraud_impact);

  return (
    <div className="usa-map-container">
      <ComposableMap
        projection="geoAlbersUsa"
        projectionConfig={{ scale: 1050 }}
        width={980}
        height={620}
        className="usa-map-svg"
      >
        <Geographies geography={GEO_URL}>
          {({ geographies }) =>
            geographies.map(geo => {
              const stateAbbr = FIPS_TO_STATE[geo.id];
              const stateData = stateAbbr ? dataMap[stateAbbr] : null;
              const fill = stateData ? getColor(stateData.fraud_impact, stateAbbr) : '#e8e8e8';
              // If noPins (region mode), use fill color as stroke so same-region states merge visually
              const strokeColor = noPins ? fill : '#fff';
              const strokeW = noPins ? 0.3 : 0.8;
              return (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill={fill}
                  stroke={strokeColor}
                  strokeWidth={strokeW}
                  className="usa-map-state"
                  onMouseEnter={(e) => {
                    if (stateData) {
                      const rect = e.currentTarget.closest('.usa-map-container').getBoundingClientRect();
                      const currentRegion = regionMap && regionMap[stateAbbr];
                      setTooltip(prev => {
                        // In region mode, don't re-trigger if same region
                        if (noPins && prev && currentRegion && regionMap[prev.id] === currentRegion) {
                          return { ...prev, x: e.clientX - rect.left, y: e.clientY - rect.top - 12 };
                        }
                        return {
                          id: stateAbbr,
                          region: currentRegion,
                          name: stateData.name,
                          data: stateData,
                          x: e.clientX - rect.left,
                          y: e.clientY - rect.top - 12,
                        };
                      });
                    }
                  }}
                  onMouseMove={(e) => {
                    if (stateData) {
                      const rect = e.currentTarget.closest('.usa-map-container').getBoundingClientRect();
                      setTooltip(prev => prev ? {
                        ...prev,
                        x: e.clientX - rect.left,
                        y: e.clientY - rect.top - 12,
                      } : prev);
                    }
                  }}
                  onMouseLeave={(e) => {
                    // In region mode, only hide if leaving to a different region or outside the map
                    if (noPins && regionMap) {
                      const related = e.relatedTarget;
                      if (related && related.closest && related.closest('.usa-map-state')) {
                        // Moving to another state — let onMouseEnter handle it
                        return;
                      }
                    }
                    setTooltip(null);
                  }}
                  onClick={() => stateData && onStateClick && onStateClick(stateData)}
                  style={{
                    default: { outline: 'none' },
                    hover: { outline: 'none', stroke: noPins ? strokeColor : '#1a237e', strokeWidth: noPins ? strokeW : 2, opacity: noPins ? 1 : 0.85 },
                    pressed: { outline: 'none' },
                  }}
                />
              );
            })
          }
        </Geographies>

        {/* Pin markers on high-impact states */}
        {!noPins && pinStates.map(s => (
          <PinMarker
            key={`pin-${s.state}`}
            coordinates={STATE_CENTERS[s.state]}
            value={s.fraud_impact}
            color={getColor(s.fraud_impact, s.state)}
          />
        ))}

        {/* State abbreviation labels on all states */}
        {Object.entries(STATE_CENTERS).map(([abbr, coords]) => {
          const offset = OFFSET_STATES[abbr];
          if (offset) {
            // Small states get an offset annotation with a connecting line
            return (
              <Annotation
                key={`lbl-${abbr}`}
                subject={coords}
                dx={offset.dx}
                dy={offset.dy}
                connectorProps={{ stroke: '#546e7a', strokeWidth: 0.8, strokeLinecap: 'round' }}
              >
                <text
                  textAnchor="start"
                  alignmentBaseline="middle"
                  className="usa-map-state-label"
                >
                  {abbr}
                </text>
              </Annotation>
            );
          }
          // Normal-sized states get a centered label
          return (
            <Marker key={`lbl-${abbr}`} coordinates={coords}>
              <text
                textAnchor="middle"
                alignmentBaseline="central"
                className="usa-map-state-label"
              >
                {abbr}
              </text>
            </Marker>
          );
        })}
      </ComposableMap>

      {/* Tooltip */}
      {tooltip && (
        <div className="usa-map-tooltip" style={{ left: tooltip.x, top: tooltip.y }}>
          {regionData && regionMap && regionMap[tooltip.id] ? (() => {
            const rName = regionMap[tooltip.id];
            const r = regionLookup[rName];
            return <>
              <strong>{rName} Region</strong>
              <span>Impact: {r ? r.impact : 0}</span>
              <span>Confirmed: {r ? r.confirmed : 0}</span>
              <span>States: {r ? r.states : 0}</span>
            </>;
          })() : <>
            <strong>{tooltip.name} ({tooltip.id})</strong>
            {regionMap && regionMap[tooltip.id] && <span>Region: {regionMap[tooltip.id]}</span>}
            <span>Impact: {tooltip.data.fraud_impact}</span>
            <span>Confirmed: {tooltip.data.confirmed}</span>
            <span>ZIP Codes: {tooltip.data.zip_count}</span>
          </>}
        </div>
      )}
    </div>
  );
}
