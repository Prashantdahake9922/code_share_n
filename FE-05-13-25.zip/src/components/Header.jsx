import React, { useState, useRef, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSystemHealth } from '../contexts/SystemHealthContext';

export default function Header() {
  const { user, logout } = useAuth();
  const { isFullyOperational, degradedServices, toggleService } = useSystemHealth();
  const navigate = useNavigate();
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    setProfileOpen(false);
    logout();
    navigate('/login');
  };

  return (
    <header className="app-header">
      <div className="header-left">
        <div className="logo">FPM Platform</div>
        <nav className="main-nav">
          <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Summary</NavLink>
          <NavLink to="/cases" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Cases</NavLink>
          <NavLink to="/data-spider" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Data Spider</NavLink>
          <NavLink to="/fraud-map" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Fraud Map</NavLink>
          <NavLink to="/nlp-query" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>NLP Query</NavLink>
          {(user?.role === 'supervisor' || user?.role === 'leadership') && (
            <NavLink to="/sla-monitor" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>SLA Monitor</NavLink>
          )}
          {(user?.role === 'supervisor' || user?.role === 'leadership') && (
            <NavLink to="/audit-log" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>Audit Log</NavLink>
          )}
        </nav>
      </div>
      <div className="header-right">
        {!isFullyOperational && (
          <div className="degradation-indicator" title={`Degraded: ${degradedServices.join(', ')}`}>
            <span className="degradation-icon">!</span>
            <span className="degradation-text">
              {degradedServices.map(s => s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())).join(', ')} unavailable
            </span>
          </div>
        )}
        <div className="profile-menu" ref={profileRef}>
          <button className="profile-trigger" onClick={() => setProfileOpen(!profileOpen)}>
            <span className="profile-avatar">{user?.name?.charAt(0).toUpperCase()}</span>
          </button>
          {profileOpen && (
            <div className="profile-dropdown">
              <div className="profile-dropdown-header">
                <div className="profile-dropdown-avatar">{user?.name?.charAt(0).toUpperCase()}</div>
                <div className="profile-dropdown-info">
                  <span className="profile-dropdown-name">{user?.name}</span>
                  <span className="profile-dropdown-role">{user?.role}</span>
                </div>
              </div>
              <div className="profile-dropdown-divider"></div>
              <button className="profile-dropdown-item logout" onClick={handleLogout}>
                <span className="profile-dropdown-icon">→</span>
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
