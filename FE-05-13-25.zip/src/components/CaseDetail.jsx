import React, { useState } from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { useSystemHealth } from '../contexts/SystemHealthContext';
import { DISPOSITIONS, RISK_FACTORS, EXTERNAL_TOOLS, AUDIT_TRAIL_SAMPLE, USERS, ORDERS } from '../data/dummyData';

export default function CaseDetail() {
  const { selectedCase, setSelectedCase, updateCase, addComment, reassignCase, linkCases, cases } = useCases();
  const { user } = useAuth();
  const { health } = useSystemHealth();
  const [activeTab, setActiveTab] = useState('ai_insights');
  const [disposition, setDisposition] = useState('');
  const [dispComment, setDispComment] = useState('');
  const [newComment, setNewComment] = useState('');
  const [reassignTo, setReassignTo] = useState('');
  const [linkToCaseId, setLinkToCaseId] = useState('');
  const [rsQuery, setRsQuery] = useState('');
  const [rsResults, setRsResults] = useState(null);
  const [pipelineStatus, setPipelineStatus] = useState(null);
  const [escalateReason, setEscalateReason] = useState('');
  const [auditActionFilter, setAuditActionFilter] = useState('');
  const [auditDateFrom, setAuditDateFrom] = useState('');
  const [auditDateTo, setAuditDateTo] = useState('');

  if (!selectedCase) {
    return <div className="case-detail-empty"><p>Select a case from the queue to view details</p></div>;
  }

  const c = selectedCase;

  const handleDisposition = () => {
    if (!disposition) return;
    updateCase(c.id, {
      disposition,
      status: 'resolved',
      updated_at: new Date().toISOString(),
      status_history: [...c.status_history, {
        from: c.status,
        to: 'resolved',
        changed_by: user.name,
        changed_at: new Date().toISOString(),
        reason: `Disposition: ${disposition}${dispComment ? ' — ' + dispComment : ''}`
      }]
    });
    addComment(c.id, {
      id: `c-${Date.now()}`,
      author: user.name,
      text: `Disposition submitted: ${disposition}. ${dispComment}`,
      created_at: new Date().toISOString()
    });
    // Simulate downstream pipeline push
    setPipelineStatus({ status: 'pushing', started: new Date().toISOString() });
    setTimeout(() => {
      setPipelineStatus({
        status: 'complete',
        started: new Date().toISOString(),
        systems: [
          { name: 'Order Control (Redshift)', status: 'success' },
          { name: 'Mobile IT API', status: 'success' },
          { name: 'UCM', status: 'success' }
        ]
      });
      addComment(c.id, {
        id: `c-${Date.now() + 1}`,
        author: 'Orchestrator Agent',
        text: `Pipeline complete: Disposition "${disposition}" pushed to Order Control, Mobile IT API, and UCM.`,
        created_at: new Date().toISOString()
      });
    }, 1500);
    setDisposition('');
    setDispComment('');
  };

  const handleEscalate = () => {
    if (!escalateReason.trim()) { alert('Please provide a reason for escalation.'); return; }
    updateCase(c.id, {
      status: 'escalated',
      updated_at: new Date().toISOString(),
      status_history: [...c.status_history, { from: c.status, to: 'escalated', changed_by: user.name, changed_at: new Date().toISOString(), reason: escalateReason }]
    });
    addComment(c.id, {
      id: `c-${Date.now()}`,
      author: user.name,
      text: `Case escalated to supervisor. Reason: ${escalateReason}`,
      created_at: new Date().toISOString()
    });
    setEscalateReason('');
  };

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    addComment(c.id, {
      id: `c-${Date.now()}`,
      author: user.name,
      text: newComment,
      created_at: new Date().toISOString()
    });
    setNewComment('');
  };

  const handleReassign = () => {
    if (!reassignTo) return;
    reassignCase(c.id, reassignTo);
    addComment(c.id, {
      id: `c-${Date.now()}`,
      author: user.name,
      text: `Case reassigned to ${USERS.find(u => u.id === reassignTo)?.name}`,
      created_at: new Date().toISOString()
    });
    setReassignTo('');
  };

  const handleToggleRiskFactor = (rfId) => {
    const current = c.investigation_score.selected_factors;
    const updated = current.includes(rfId)
      ? current.filter(f => f !== rfId)
      : [...current, rfId];
    const totalWeight = RISK_FACTORS.reduce((s, rf) => s + rf.weight, 0);
    const selectedWeight = updated.reduce((s, id) => s + (RISK_FACTORS.find(r => r.id === id)?.weight || 0), 0);
    const newScore = Math.round((selectedWeight / totalWeight) * 100);
    updateCase(c.id, { investigation_score: { selected_factors: updated, score: newScore, investigator: user.name, notes: c.investigation_score.notes || '', timestamp: new Date().toISOString() } });
  };

  // Customer history
  const customerCases = cases.filter(cc => cc.customer.name === c.customer.name || cc.customer.email === c.customer.email || cc.customer.phone === c.customer.phone || cc.customer.account === c.customer.account);
  const customerMetrics = {
    total: customerCases.length,
    open: customerCases.filter(cc => !['resolved', 'closed', 'canceled'].includes(cc.status)).length,
    lastCaseDate: customerCases.sort((a, b) => b.created_at.localeCompare(a.created_at))[0]?.created_at || '',
    highRisk: customerCases.some(cc => cc.risk_score >= 70)
  };

  const getVerifyIcon = (status) => {
    switch (status) {
      case 'match': return <span className="verify-match">✓ Match</span>;
      case 'mismatch': return <span className="verify-mismatch">✗ Mismatch</span>;
      case 'partial': return <span className="verify-partial">~ Partial</span>;
      default: return <span className="verify-info">{status}</span>;
    }
  };

  // Redshift Chat handler - scoped to current case
  const handleRedshiftQuery = () => {
    if (!rsQuery.trim()) return;
    const orderData = ORDERS.filter(o => o.order_id === c.order_id || o.customer_name === c.customer.name);
    const simulatedSQL = `SELECT * FROM orders WHERE order_id = '${c.order_id}' AND ${rsQuery.toLowerCase().includes('status') ? "status != 'canceled'" : '1=1'} LIMIT 50;`;
    setRsResults({
      sql: simulatedSQL,
      rows: orderData.length > 0 ? orderData : [{ order_id: c.order_id, customer_name: c.customer.name, status: 'simulated', amount: '$299.99', date: c.created_at }],
      timestamp: new Date().toISOString()
    });
  };

  // Confidence Gate check
  const confidenceGateThreshold = 85;
  const decisionConfidence = c.agent_insights.decision.confidence;
  const confidenceGateBlocked = decisionConfidence < confidenceGateThreshold;

  const tabs = [
    { id: 'ai_insights', label: 'AI Insights' },
    { id: 'verification', label: 'Verification' },
    { id: 'disposition', label: 'Disposition' },
    { id: 'redshift_chat', label: 'Redshift Chat' },
    { id: 'customer_history', label: 'Customer History' },
    { id: 'comments', label: 'Comments' },
    { id: 'history', label: 'History' },
    { id: 'linked', label: 'Linked' },
    { id: 'tools', label: 'Tools' },
  ];

  return (
    <div className="case-detail">
      {/* Case Header */}
      <div className="detail-header">
        <div className="detail-header-top">
          <h2>{c.id}</h2>
          <span className={`priority-badge priority-${c.priority}`}>{c.priority.toUpperCase()}</span>
          <span className={`status-badge status-${c.status}`}>{c.status.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span>
          <span className={`sla-badge ${c.sla_status.replace('_', '-')}`}>{c.sla_status.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span>
          <span className="risk-score-large">Risk: {c.risk_score}/100</span>
        </div>
        <div className="detail-header-customer">
          <span>Customer: {c.customer.name}</span>
          <span>Email: {c.customer.email}</span>
          <span>Phone: {c.customer.phone}</span>
          <span>Account: {c.customer.account}</span>
          {c.customer.mobile_account && <span>Mobile: {c.customer.mobile_account}</span>}
          <span>Order: {c.order_id}</span>
        </div>
        <p className="case-description">{c.description}</p>
      </div>

      {/* Tabs */}
      <div className="detail-tabs">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'ai_insights' && (
          <div className="ai-insights-grid">
            {!health.openai_api && (
              <div className="ai-degradation-banner">
                <span className="degradation-badge">AI Degraded</span>
                <p>OpenAI API is unavailable. Showing rule-based fallback summaries and recommendations. Confidence scores may be reduced.</p>
              </div>
            )}
            {confidenceGateBlocked && (
              <div className="confidence-gate-banner">
                <span className="gate-badge">Confidence Gate Blocked</span>
                <p>AI confidence ({decisionConfidence}%) is below the auto-decision threshold ({confidenceGateThreshold}%). Auto-approve/reject is blocked. Case routed to human review.</p>
              </div>
            )}
            {!confidenceGateBlocked && (
              <div className="confidence-gate-pass">
                <span className="gate-pass-badge">Confidence Gate Passed</span>
                <span>AI confidence ({decisionConfidence}%) meets threshold ({confidenceGateThreshold}%). Eligible for auto-decision.</span>
              </div>
            )}
            <div className="agent-card triage">
              <h4>Triage Agent <span className="info-tooltip-wrap" data-tooltip="AI risk scoring — classifies case priority and fraud likelihood">&#9432;</span></h4>
              <div className="agent-metric"><strong>Risk Score:</strong> {c.agent_insights.triage.risk_score}/100</div>
              <div className="agent-metric"><strong>Priority:</strong> {c.agent_insights.triage.priority.toUpperCase()}</div>
              <div className="agent-metric"><strong>Confidence:</strong> {c.agent_insights.triage.confidence}%</div>
              <div className="agent-flags">
                <strong>Flags:</strong>
                {c.agent_insights.triage.flags.map(f => <span key={f} className="flag-tag">{f}</span>)}
              </div>
            </div>
            <div className="agent-card verification">
              <h4>Verification Agent <span className="info-tooltip-wrap" data-tooltip="Automated customer identity verification across multiple data sources">&#9432;</span></h4>
              <div className="agent-metric">Phone: {getVerifyIcon(c.agent_insights.verification.phone)}</div>
              <div className="agent-metric">Email: {getVerifyIcon(c.agent_insights.verification.email)}</div>
              <div className="agent-metric">Address: {getVerifyIcon(c.agent_insights.verification.address)}</div>
              <div className="agent-metric">IP: {getVerifyIcon(c.agent_insights.verification.ip)}</div>
              <div className="agent-metric">IMEI: {getVerifyIcon(c.agent_insights.verification.imei)}</div>
              <div className="agent-metric"><strong>Confidence:</strong> {c.agent_insights.verification.confidence}%</div>
            </div>
            <div className="agent-card summarization">
              <h4>Summarization Agent <span className="info-tooltip-wrap" data-tooltip="AI-generated case summary highlighting key fraud indicators">&#9432;</span></h4>
              <p className="summary-text">{c.agent_insights.summarization}</p>
            </div>
            <div className="agent-card decision">
              <h4>Decision Agent <span className="info-tooltip-wrap" data-tooltip="AI disposition recommendation with confidence score and reasoning">&#9432;</span></h4>
              <div className="agent-metric">
                <strong>Recommendation:</strong>
                <span className={`recommendation rec-${c.agent_insights.decision.recommendation}`}>
                  {c.agent_insights.decision.recommendation.toUpperCase()}
                </span>
              </div>
              <div className="agent-metric"><strong>Confidence:</strong> {c.agent_insights.decision.confidence}%</div>
              <p className="reasoning-text">{c.agent_insights.decision.reasoning}</p>
            </div>

            {/* Investigation Score */}
            <div className="investigation-score-section">
              <h4>Investigation Score: {c.investigation_score.score}%</h4>
              <p className="score-help">Select risk factors to recalculate investigation score:</p>
              <div className="risk-factors-grid">
                {RISK_FACTORS.map(rf => (
                  <label key={rf.id} className={`risk-factor-item ${c.investigation_score.selected_factors.includes(rf.id) ? 'selected' : ''}`}>
                    <input type="checkbox" checked={c.investigation_score.selected_factors.includes(rf.id)} onChange={() => handleToggleRiskFactor(rf.id)} />
                    <span>{rf.label} ({rf.weight})</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'verification' && (
          <div className="verification-panel">
            <h3>Customer Verification Results <span className="info-tooltip-wrap" data-tooltip="Automated verification of customer PII — phone, email, address, IP, device">&#9432;</span></h3>
            <table className="verify-table">
              <thead>
                <tr><th>Field</th><th>Status</th></tr>
              </thead>
              <tbody>
                <tr><td>Phone</td><td>{getVerifyIcon(c.agent_insights.verification.phone)}</td></tr>
                <tr><td>Email</td><td>{getVerifyIcon(c.agent_insights.verification.email)}</td></tr>
                <tr><td>Address</td><td>{getVerifyIcon(c.agent_insights.verification.address)}</td></tr>
                <tr><td>IP Address</td><td>{getVerifyIcon(c.agent_insights.verification.ip)}</td></tr>
                <tr><td>IMEI / Device</td><td>{getVerifyIcon(c.agent_insights.verification.imei)}</td></tr>
              </tbody>
            </table>
            <div className="verify-confidence">
              Overall Confidence: <strong>{c.agent_insights.verification.confidence}%</strong>
            </div>
          </div>
        )}

        {activeTab === 'disposition' && (
          <div className="disposition-panel">
            {/* AI vs Human comparison - always visible */}
            <div className="avh-case-compare">
              <h3>AI Recommendation vs Your Decision <span className="info-tooltip-wrap" data-tooltip="Compare AI-generated disposition with your manual decision before submitting">&#9432;</span></h3>
              <div className="avh-compare-cards">
                <div className="avh-compare-ai">
                  <div className="avh-compare-label">AI</div>
                  <div className={`avh-compare-disp avh-disp-${c.agent_insights.decision.recommendation}`}>
                    {c.agent_insights.decision.recommendation.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}
                  </div>
                  <div className="avh-compare-conf">Confidence: {c.agent_insights.decision.confidence}%</div>
                  <div className="avh-compare-reason">{c.agent_insights.decision.reasoning}</div>
                </div>
                <div className="avh-compare-vs">VS</div>
                <div className="avh-compare-human">
                  <div className="avh-compare-label">Human</div>
                  {c.status === 'resolved' ? (
                    <>
                      <div className={`avh-compare-disp avh-disp-${c.disposition}`}>
                        {c.disposition ? c.disposition.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase()) : 'N/A'}
                      </div>
                      <div className="avh-compare-result">
                        {c.disposition === c.agent_insights.decision.recommendation
                          ? <span className="avh-result-agree">Agreed with AI</span>
                          : <span className="avh-result-override">Overrode AI</span>}
                      </div>
                    </>
                  ) : (
                    <div className="avh-compare-pending">Awaiting your decision below...</div>
                  )}
                </div>
              </div>
            </div>

            <h3>Submit Disposition <span className="info-tooltip-wrap" data-tooltip="Select and submit your final fraud determination for this case">&#9432;</span></h3>
            {c.status === 'resolved' ? (
              <div className="disposition-done">
                <p>✓ Case resolved with disposition: <strong>{c.disposition}</strong></p>
                {pipelineStatus && (
                  <div className={`pipeline-status pipeline-${pipelineStatus.status}`}>
                    <h4>Downstream Pipeline Status</h4>
                    {pipelineStatus.status === 'pushing' && <p className="pipeline-pushing">Pushing disposition to downstream systems...</p>}
                    {pipelineStatus.status === 'complete' && (
                      <div className="pipeline-results">
                        {pipelineStatus.systems.map(s => (
                          <div key={s.name} className="pipeline-item">
                            <span className="pipeline-icon">{s.status === 'success' ? '✓' : '✗'}</span>
                            <span>{s.name}</span>
                            <span className={`pipeline-badge-${s.status}`}>{s.status}</span>
                          </div>
                        ))}
                        <div className="pipeline-ucm-mapping">
                          <h5>UCM Status Mapping</h5>
                          <span className="ucm-map-item">Disposition: <strong>{c.disposition}</strong> → UCM Status: <strong>{{
                            approve: 'approved',
                            reject: 'rejected',
                            customer_engagement: 'pending_customer_contact',
                            cannot_determine: 'escalated'
                          }[c.disposition] || c.disposition}</strong></span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <>
                <div className="disp-form">
                  <label>Disposition:</label>
                  <select value={disposition} onChange={e => setDisposition(e.target.value)}>
                    <option value="">Select disposition...</option>
                    {DISPOSITIONS.map(d => <option key={d} value={d}>{d.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</option>)}
                  </select>
                  <label>Comments:</label>
                  <textarea
                    value={dispComment}
                    onChange={e => setDispComment(e.target.value)}
                    placeholder="Enter disposition notes..."
                    rows={4}
                  />
                  <div className="disp-actions">
                    <button className="btn-primary" onClick={handleDisposition} disabled={!disposition}>
                      Submit Disposition
                    </button>
                  </div>
                  <div className="escalate-section">
                    <h4>Escalate to Supervisor</h4>
                    <input
                      type="text"
                      value={escalateReason}
                      onChange={e => setEscalateReason(e.target.value)}
                      placeholder="Reason for escalation (required)..."
                      className="escalate-reason-input"
                    />
                    <button className="btn-warning" onClick={handleEscalate} disabled={!escalateReason.trim()}>
                      Escalate to Supervisor
                    </button>
                  </div>
                  {user.role === 'supervisor' && (
                    <div className="reassign-section">
                      <h4>Reassign Case</h4>
                      <div className="reassign-row">
                        <select value={reassignTo} onChange={e => setReassignTo(e.target.value)}>
                          <option value="">Select investigator...</option>
                          {USERS.filter(u => u.role === 'investigator' && u.id !== c.assigned_to).map(u => (
                            <option key={u.id} value={u.id}>{u.name}</option>
                          ))}
                        </select>
                        <button className="btn-secondary" onClick={handleReassign} disabled={!reassignTo}>Reassign</button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {activeTab === 'redshift_chat' && (
          <div className="redshift-chat-panel">
            <h3>Redshift Chat — Case: {c.id} <span className="info-tooltip-wrap" data-tooltip="Query Redshift database directly — ask natural language questions about this case">&#9432;</span></h3>
            <p className="rs-chat-help">Query Redshift data scoped to this case's order ({c.order_id}) and customer.</p>
            <div className="rs-chat-input-row">
              <input
                type="text"
                value={rsQuery}
                onChange={e => setRsQuery(e.target.value)}
                placeholder="e.g., Show all orders for this customer, What's the shipping status?"
                onKeyDown={e => e.key === 'Enter' && handleRedshiftQuery()}
              />
              <button className="btn-primary" onClick={handleRedshiftQuery} disabled={!rsQuery.trim()}>
                Query
              </button>
            </div>
            <div className="rs-quick-queries">
              <button onClick={() => { setRsQuery('Show all orders for this customer'); }}>All Orders</button>
              <button onClick={() => { setRsQuery('Show order status and shipping details'); }}>Shipping Status</button>
              <button onClick={() => { setRsQuery('Show payment history'); }}>Payment History</button>
              <button onClick={() => { setRsQuery('Show device activations'); }}>Device Activations</button>
            </div>
            {rsResults && (
              <div className="rs-results">
                <div className="rs-sql-display">
                  <strong>Generated SQL:</strong>
                  <code>{rsResults.sql}</code>
                </div>
                <table className="verify-table">
                  <thead>
                    <tr>
                      {Object.keys(rsResults.rows[0] || {}).map(k => <th key={k}>{k}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {rsResults.rows.map((row, i) => (
                      <tr key={i}>
                        {Object.values(row).map((v, j) => <td key={j}>{String(v)}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
                <span className="rs-timestamp">Query executed: {new Date(rsResults.timestamp).toLocaleString()}</span>
              </div>
            )}
          </div>
        )}

        {activeTab === 'customer_history' && (
          <div className="customer-history-panel">
            <h3>Customer History: {c.customer.name} <span className="info-tooltip-wrap" data-tooltip="Complete order and case history for this customer across all channels">&#9432;</span></h3>
            <div className="customer-summary">
              <div className="summary-metric"><strong>Total Tickets:</strong> {customerMetrics.total}</div>
              <div className="summary-metric"><strong>Open Tickets:</strong> {customerMetrics.open}</div>
              <div className="summary-metric"><strong>Last Case Date:</strong> {customerMetrics.lastCaseDate ? new Date(customerMetrics.lastCaseDate).toLocaleDateString() : 'N/A'}</div>
              <div className="summary-metric"><strong>High-Risk Flag:</strong> {customerMetrics.highRisk ? <span className="verify-mismatch">YES (score ≥ 70)</span> : <span className="verify-match">NO</span>}</div>
            </div>
            <h4>All Cases for this Customer:</h4>
            <table className="verify-table">
              <thead>
                <tr><th>Case ID</th><th>Type</th><th>Status</th><th>Risk</th><th>Created</th></tr>
              </thead>
              <tbody>
                {customerCases.map(cc => (
                  <tr key={cc.id} className={cc.id === c.id ? 'selected' : ''}>
                    <td>{cc.id}</td>
                    <td>{cc.ticket_type.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</td>
                    <td>{cc.status.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</td>
                    <td>{cc.risk_score}</td>
                    <td>{new Date(cc.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'comments' && (
          <div className="comments-panel">
            <h3>Comments & Notes ({c.comments.length}) <span className="info-tooltip-wrap" data-tooltip="Internal team notes and comments — add observations or flag concerns">&#9432;</span></h3>
            <div className="comments-list">
              {c.comments.map(comment => {
                const isAgent = comment.author.includes('Agent') || comment.author === 'Orchestrator Agent' || comment.author === 'System';
                return (
                  <div key={comment.id} className={`comment-item ${isAgent ? 'agent-comment' : 'human-comment'}`}>
                    <div className="comment-header">
                      <strong>{comment.author}</strong>
                      {isAgent && <span className="comment-agent-badge">Agent</span>}
                      <span className="comment-time">{new Date(comment.created_at).toLocaleString()}</span>
                    </div>
                    <p>{comment.text}</p>
                  </div>
                );
              })}
            </div>
            <div className="add-comment">
              <textarea
                value={newComment}
                onChange={e => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                rows={3}
              />
              <button className="btn-primary" onClick={handleAddComment}>Add Comment</button>
            </div>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="history-panel">
            <h3>Status Change History <span className="info-tooltip-wrap" data-tooltip="Full timeline of all status transitions for this case">&#9432;</span></h3>
            <div className="history-list">
              {c.status_history.map((h, i) => (
                <div key={i} className="history-item">
                  <span className="history-time">{new Date(h.changed_at).toLocaleString()}</span>
                  <span className="history-change">{h.from} → {h.to}</span>
                  <span className="history-actor">by {h.changed_by}</span>
                  {h.reason && <span className="history-reason">({h.reason})</span>}
                </div>
              ))}
            </div>
            <h3>Audit Trail <span className="info-tooltip-wrap" data-tooltip="Detailed log of every action taken on this case — filterable by action type">&#9432;</span></h3>
            <div className="audit-filters">
              <select value={auditActionFilter} onChange={e => setAuditActionFilter(e.target.value)}>
                <option value="">All Action Types</option>
                {[...new Set(AUDIT_TRAIL_SAMPLE.filter(a => a.case_id === c.id).map(a => a.action))].map(action => (
                  <option key={action} value={action}>{action.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</option>
                ))}
              </select>
              <input type="date" value={auditDateFrom} onChange={e => setAuditDateFrom(e.target.value)} title="From Date" />
              <input type="date" value={auditDateTo} onChange={e => setAuditDateTo(e.target.value)} title="To Date" />
            </div>
            <div className="audit-trail">
              {AUDIT_TRAIL_SAMPLE.filter(a => {
                if (a.case_id !== c.id) return false;
                if (auditActionFilter && a.action !== auditActionFilter) return false;
                if (auditDateFrom && a.timestamp < auditDateFrom) return false;
                if (auditDateTo && a.timestamp > auditDateTo + 'T23:59:59Z') return false;
                return true;
              }).map(a => (
                <div key={a.id} className="audit-item">
                  <span className="audit-time">{new Date(a.timestamp).toLocaleString()}</span>
                  <span className={`audit-action action-${a.action}`}>{a.action.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span>
                  <span className="audit-actor">{a.actor}</span>
                  <span className="audit-details">{a.details}</span>
                </div>
              ))}
            </div>
            <div className="audit-export-btns">
              <button className="btn-export" onClick={() => {
                const trail = AUDIT_TRAIL_SAMPLE.filter(a => {
                  if (a.case_id !== c.id) return false;
                  if (auditActionFilter && a.action !== auditActionFilter) return false;
                  if (auditDateFrom && a.timestamp < auditDateFrom) return false;
                  if (auditDateTo && a.timestamp > auditDateTo + 'T23:59:59Z') return false;
                  return true;
                });
                const blob = new Blob([JSON.stringify(trail, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = `audit_${c.id}.json`; a.click();
                URL.revokeObjectURL(url);
              }}>Export JSON</button>
              <button className="btn-export" onClick={() => {
                const trail = AUDIT_TRAIL_SAMPLE.filter(a => {
                  if (a.case_id !== c.id) return false;
                  if (auditActionFilter && a.action !== auditActionFilter) return false;
                  if (auditDateFrom && a.timestamp < auditDateFrom) return false;
                  if (auditDateTo && a.timestamp > auditDateTo + 'T23:59:59Z') return false;
                  return true;
                });
                const headers = 'id,case_id,action,actor,timestamp,details';
                const rows = trail.map(t => `"${t.id}","${t.case_id}","${t.action}","${t.actor}","${t.timestamp}","${t.details}"`);
                const csv = [headers, ...rows].join('\n');
                const blob = new Blob([csv], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = `audit_${c.id}.csv`; a.click();
                URL.revokeObjectURL(url);
              }}>Export CSV</button>
            </div>
          </div>
        )}

        {activeTab === 'linked' && (
          <div className="linked-panel">
            <h3>Linked Cases <span className="info-tooltip-wrap" data-tooltip="Cases sharing common customer data or fraud patterns — bidirectional links">&#9432;</span></h3>
            {c.linked_cases.length === 0 ? (
              <p className="no-data">No linked cases</p>
            ) : (
              <div className="linked-list">
                {c.linked_cases.map(lc => (
                  <div key={lc} className="linked-item">
                    <span className="link-icon">•</span>
                    <span className="link-id">{lc}</span>
                    <span className="link-type">Bidirectional</span>
                  </div>
                ))}
              </div>
            )}
            <div className="link-create-section">
              <h4>Link Another Case</h4>
              <div className="link-create-row">
                <select value={linkToCaseId} onChange={e => setLinkToCaseId(e.target.value)}>
                  <option value="">Select case to link...</option>
                  {cases.filter(cc => cc.id !== c.id && !c.linked_cases.includes(cc.id)).map(cc => (
                    <option key={cc.id} value={cc.id}>{cc.id} — {cc.customer.name} ({cc.ticket_type.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())})</option>
                  ))}
                </select>
                <button className="btn-primary" onClick={() => { if (linkToCaseId) { linkCases(c.id, linkToCaseId); setLinkToCaseId(''); } }} disabled={!linkToCaseId}>
                  Create Link
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tools' && (
          <div className="tools-panel">
            <h3>External Investigation Tools <span className="info-tooltip-wrap" data-tooltip="Quick links to external systems for deeper investigation — opens in new tab">&#9432;</span></h3>
            <div className="tools-grid">
              {EXTERNAL_TOOLS.map(tool => (
                <a key={tool.name} href={tool.uri} target="_blank" rel="noopener noreferrer" className="tool-link">
                  <span className="tool-icon">{tool.icon}</span>
                  <span className="tool-name">{tool.name}</span>
                  <span className="tool-desc">{tool.description}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
