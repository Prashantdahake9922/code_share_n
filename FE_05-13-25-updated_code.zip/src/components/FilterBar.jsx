import React, { useState, useRef, useEffect } from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { STATUSES, PRIORITIES, TICKET_TYPES, USERS } from '../data/dummyData';

export default function FilterBar() {
  const { filters, setFilters, sortField, setSortField, sortOrder, setSortOrder, getFilteredCases } = useCases();
  const { user } = useAuth();
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const dateRef = useRef(null);
  const exportRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dateRef.current && !dateRef.current.contains(e.target)) setShowDatePicker(false);
      if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getAssigneeName = (id) => USERS.find(u => u.id === id)?.name || 'Unassigned';

  const handleChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const formatDateLabel = () => {
    if (filters.dateFrom && filters.dateTo) {
      return `${filters.dateFrom} → ${filters.dateTo}`;
    }
    if (filters.dateFrom) return `From ${filters.dateFrom}`;
    if (filters.dateTo) return `Until ${filters.dateTo}`;
    return 'Date Range';
  };

  const clearDates = () => {
    setFilters(prev => ({ ...prev, dateFrom: '', dateTo: '' }));
    setShowDatePicker(false);
  };

  const handleExportCSV = () => {
    const cases = getFilteredCases(user.role, user.id);
    const headers = ['case_id', 'ucm_ticket_id', 'order_id', 'ticket_type', 'line_of_business', 'priority', 'status', 'assigned_to', 'disposition', 'customer_name', 'customer_email', 'risk_score', 'created_at', 'updated_at', 'sla_status', 'comments_count'];
    const rows = cases.map(c => [
      c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.line_of_business,
      c.priority, c.status, USERS.find(u => u.id === c.assigned_to)?.name || '',
      c.disposition || '', c.customer.name, c.customer.email, c.risk_score,
      c.created_at, c.updated_at, c.sla_status, c.comments_count
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'cases_export.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const hasActiveFilters = filters.search || filters.status || filters.priority || filters.ticket_type || filters.assigned_to || filters.dateFrom || filters.dateTo;

  const clearAllFilters = () => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '' });
  };

  return (
    <div className="filter-bar">
      <div className="filter-bar-row">
        <div className="filter-col filter-col-search">
          <span className="filter-col-label">Search</span>
          <div className="filter-input-wrap">
            <input
              type="text"
              placeholder="Search..."
              value={filters.search}
              onChange={e => handleChange('search', e.target.value)}
              className="search-input"
            />
            {filters.search && <span className="filter-clear-x" onClick={() => handleChange('search', '')}>✕</span>}
          </div>
        </div>
        <div className="filter-col">
          <span className="filter-col-label">Status</span>
          <div className="filter-input-wrap">
            <select value={filters.status} onChange={e => handleChange('status', e.target.value)}>
              <option value="">All</option>
              {STATUSES.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
            </select>
            {filters.status && <span className="filter-clear-x" onClick={() => handleChange('status', '')}>✕</span>}
          </div>
        </div>
        <div className="filter-col">
          <span className="filter-col-label">Priority</span>
          <div className="filter-input-wrap">
            <select value={filters.priority} onChange={e => handleChange('priority', e.target.value)}>
              <option value="">All</option>
              {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
            {filters.priority && <span className="filter-clear-x" onClick={() => handleChange('priority', '')}>✕</span>}
          </div>
        </div>
        <div className="filter-col">
          <span className="filter-col-label">Type</span>
          <div className="filter-input-wrap">
            <select value={filters.ticket_type} onChange={e => handleChange('ticket_type', e.target.value)}>
              <option value="">All</option>
              {TICKET_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
            </select>
            {filters.ticket_type && <span className="filter-clear-x" onClick={() => handleChange('ticket_type', '')}>✕</span>}
          </div>
        </div>
        {user.role === 'supervisor' && (
          <div className="filter-col">
            <span className="filter-col-label">Investigator</span>
            <div className="filter-input-wrap">
              <select value={filters.assigned_to} onChange={e => handleChange('assigned_to', e.target.value)}>
                <option value="">All</option>
                {USERS.filter(u => u.role === 'investigator').map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
              {filters.assigned_to && <span className="filter-clear-x" onClick={() => handleChange('assigned_to', '')}>✕</span>}
            </div>
          </div>
        )}
        <div className="filter-col date-range-wrapper" ref={dateRef}>
          <span className="filter-col-label">Date Range</span>
          <div className="filter-input-wrap">
            <button
              className={`date-range-trigger${filters.dateFrom || filters.dateTo ? ' has-value' : ''}`}
              onClick={() => setShowDatePicker(!showDatePicker)}
            >
              {formatDateLabel()}
            </button>
            {(filters.dateFrom || filters.dateTo) && <span className="filter-clear-x" onClick={clearDates}>✕</span>}
          </div>
          {showDatePicker && (
            <div className="date-range-popup">
              <div className="date-range-header">Select Date Range</div>
              <div className="date-range-fields">
                <div className="date-field">
                  <label>Start Date</label>
                  <input type="date" value={filters.dateFrom || ''} onChange={e => handleChange('dateFrom', e.target.value)} />
                </div>
                <div className="date-field">
                  <label>End Date</label>
                  <input type="date" value={filters.dateTo || ''} onChange={e => handleChange('dateTo', e.target.value)} />
                </div>
              </div>
              <div className="date-range-actions">
                <button className="date-clear-btn" onClick={clearDates}>Clear</button>
                <button className="date-apply-btn" onClick={() => setShowDatePicker(false)}>Apply</button>
              </div>
            </div>
          )}
        </div>
        <div className="filter-col">
          <span className="filter-col-label">Sort By</span>
          <div className="filter-sort-group">
            <select value={sortField} onChange={e => setSortField(e.target.value)}>
              <option value="created_at">Created</option>
              <option value="priority">Priority</option>
              <option value="status">Status</option>
              <option value="risk_score">Risk</option>
            </select>
            <button className="btn-sort" onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>
              {sortOrder === 'asc' ? '↑' : '↓'}
            </button>
          </div>
        </div>
        <div className="filter-col filter-col-export" ref={exportRef}>
          <span className="filter-col-label">&nbsp;</span>
          <div className="export-dropdown-wrap">
            <button className="btn-export-sm" onClick={() => setShowExportMenu(!showExportMenu)}>Export ▾</button>
            {showExportMenu && (
              <div className="export-menu">
                <button onClick={() => {
                  const filtered = getFilteredCases(user.role, user.id);
                  const headers = ['case_id','ucm_ticket_id','order_id','ticket_type','priority','status','risk_score','sla_status','assigned_to','customer_name','created_at'];
                  const rows = filtered.map(c => [c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.priority, c.status, c.risk_score, c.sla_status, getAssigneeName(c.assigned_to), c.customer.name, c.created_at]);
                  const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
                  const blob = new Blob([csv], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a'); a.href = url; a.download = 'cases_export.csv'; a.click();
                  URL.revokeObjectURL(url);
                  setShowExportMenu(false);
                }}>CSV</button>
                <button onClick={() => {
                  const filtered = getFilteredCases(user.role, user.id);
                  const data = filtered.map(c => ({ case_id: c.id, ucm_ticket_id: c.ucm_ticket_id, order_id: c.order_id, ticket_type: c.ticket_type, priority: c.priority, status: c.status, risk_score: c.risk_score, sla_status: c.sla_status, assigned_to: getAssigneeName(c.assigned_to), customer_name: c.customer.name, created_at: c.created_at }));
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a'); a.href = url; a.download = 'cases_export.json'; a.click();
                  URL.revokeObjectURL(url);
                  setShowExportMenu(false);
                }}>JSON</button>
                <button onClick={() => {
                  const filtered = getFilteredCases(user.role, user.id);
                  const headers = ['Case ID','UCM Ticket','Order ID','Ticket Type','Priority','Status','Risk Score','SLA Status','Assigned To','Customer','Created At'];
                  const rows = filtered.map(c => [c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.priority, c.status, c.risk_score, c.sla_status, getAssigneeName(c.assigned_to), c.customer.name, c.created_at]);
                  let html = '<table><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
                  rows.forEach(r => { html += '<tr>' + r.map(v => `<td>${v}</td>`).join('') + '</tr>'; });
                  html += '</table>';
                  const blob = new Blob([`<html><head><meta charset="utf-8"></head><body>${html}</body></html>`], { type: 'application/vnd.ms-excel' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a'); a.href = url; a.download = 'cases_export.xls'; a.click();
                  URL.revokeObjectURL(url);
                  setShowExportMenu(false);
                }}>Excel</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

