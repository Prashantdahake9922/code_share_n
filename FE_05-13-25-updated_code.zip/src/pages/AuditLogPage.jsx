import React, { useState, useRef, useEffect } from 'react';
import { AUDIT_TRAIL_SAMPLE } from '../data/dummyData';

const ACTION_TYPES = [...new Set(AUDIT_TRAIL_SAMPLE.map(a => a.action))];

export default function AuditLogPage() {
  const [filterCaseId, setFilterCaseId] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const getFiltered = () => {
    let filtered = [...AUDIT_TRAIL_SAMPLE];
    if (filterCaseId) {
      filtered = filtered.filter(a => a.case_id.toLowerCase().includes(filterCaseId.toLowerCase()));
    }
    if (filterAction) {
      filtered = filtered.filter(a => a.action === filterAction);
    }
    if (filterDateFrom) {
      filtered = filtered.filter(a => a.timestamp >= filterDateFrom);
    }
    if (filterDateTo) {
      filtered = filtered.filter(a => a.timestamp <= filterDateTo + 'T23:59:59Z');
    }
    return filtered;
  };

  const filtered = getFiltered();

  const handleExportJSON = () => {
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'audit_log_export.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCSV = () => {
    const headers = 'id,case_id,action,actor,timestamp,details';
    const rows = filtered.map(t => `"${t.id}","${t.case_id}","${t.action}","${t.actor}","${t.timestamp}","${t.details}"`);
    const csv = [headers, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'audit_log_export.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportExcel = () => {
    const headers = ['ID','Case ID','Action','Actor','Timestamp','Details'];
    let html = '<table><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
    filtered.forEach(t => { html += `<tr><td>${t.id}</td><td>${t.case_id}</td><td>${t.action}</td><td>${t.actor}</td><td>${t.timestamp}</td><td>${t.details}</td></tr>`; });
    html += '</table>';
    const blob = new Blob([`<html><head><meta charset="utf-8"></head><body>${html}</body></html>`], { type: 'application/vnd.ms-excel' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'audit_log_export.xls'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="audit-log-page">
      <h1>Audit Log</h1>

      {/* Filters */}
      <div className="filter-bar">
        <div className="filter-bar-row">
          <div className="filter-col filter-col-search">
            <span className="filter-col-label">Search</span>
            <div className="filter-input-wrap">
              <input
                type="text"
                placeholder="Case ID..."
                value={filterCaseId}
                onChange={e => setFilterCaseId(e.target.value)}
                className="search-input"
              />
              {filterCaseId && <span className="filter-clear-x" onClick={() => setFilterCaseId('')}>✕</span>}
            </div>
          </div>
          <div className="filter-col">
            <span className="filter-col-label">Action</span>
            <div className="filter-input-wrap">
              <select value={filterAction} onChange={e => setFilterAction(e.target.value)}>
                <option value="">All</option>
                {ACTION_TYPES.map(a => <option key={a} value={a}>{a.replace(/_/g, ' ')}</option>)}
              </select>
              {filterAction && <span className="filter-clear-x" onClick={() => setFilterAction('')}>✕</span>}
            </div>
          </div>
          <div className="filter-col">
            <span className="filter-col-label">From Date</span>
            <div className="filter-input-wrap">
              <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} />
              {filterDateFrom && <span className="filter-clear-x" onClick={() => setFilterDateFrom('')}>✕</span>}
            </div>
          </div>
          <div className="filter-col">
            <span className="filter-col-label">To Date</span>
            <div className="filter-input-wrap">
              <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} />
              {filterDateTo && <span className="filter-clear-x" onClick={() => setFilterDateTo('')}>✕</span>}
            </div>
          </div>
          <div className="filter-col filter-col-export" ref={exportRef} style={{ marginLeft: 'auto' }}>
            <span className="filter-col-label">&nbsp;</span>
            <button className="btn-export-sm" onClick={() => setShowExportMenu(!showExportMenu)}>Export ▾</button>
            {showExportMenu && (
              <div className="export-dropdown-wrap">
                <div className="export-menu">
                  <button onClick={() => { handleExportJSON(); setShowExportMenu(false); }}>JSON</button>
                  <button onClick={() => { handleExportCSV(); setShowExportMenu(false); }}>CSV</button>
                  <button onClick={() => { handleExportExcel(); setShowExportMenu(false); }}>Excel</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Audit Table */}
      <div className="audit-table-container">
        <table className="audit-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Case ID</th>
              <th>Action</th>
              <th>Actor</th>
              <th>Timestamp</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(a => (
              <tr key={a.id}>
                <td className="audit-id">{a.id}</td>
                <td className="case-link">{a.case_id}</td>
                <td><span className={`audit-action-badge action-${a.action}`}>{a.action.replace(/_/g, ' ')}</span></td>
                <td>{a.actor}</td>
                <td className="audit-timestamp">{new Date(a.timestamp).toLocaleString()}</td>
                <td className="audit-details">{a.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="no-data">No audit records match the selected filters.</p>}
      </div>
    </div>
  );
}
