import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';

import { FEEDBACK_METRICS, AI_VS_HUMAN_HISTORY } from '../data/dummyData';
import KPICard from '../components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, ComposedChart, Line, LabelList, ResponsiveContainer, Legend } from 'recharts';

export default function DashboardPage() {
  const { user } = useAuth();
  const { cases, setFilters } = useCases();
  const navigate = useNavigate();

  // Date filter state
  const [dateFilter, setDateFilter] = useState('all');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [filterOpen, setFilterOpen] = useState(false);
  const [selectedPriority, setSelectedPriority] = useState(null);
  const filterRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (filterRef.current && !filterRef.current.contains(e.target)) {
        setFilterOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const chartColors = {
    grid: 'rgba(0,0,0,0.1)',
    tick: '#37474f',
    axis: '#90a4ae',
    label: '#546e7a',
    legend: '#37474f',
  };

  // Role-based: investigator sees only their cases, supervisor sees all
  const myCases = user.role === 'investigator'
    ? cases.filter(c => c.assigned_to === user.id)
    : cases;
  const isSuperOrLead = user.role === 'supervisor' || user.role === 'leadership';

  // Apply date filter
  const filteredCases = useMemo(() => {
    if (dateFilter === 'all') return myCases;

    const now = new Date();
    let fromDate;

    if (dateFilter === 'custom') {
      if (!customFrom && !customTo) return myCases;
      const from = customFrom ? new Date(customFrom) : new Date('2000-01-01');
      const to = customTo ? new Date(customTo + 'T23:59:59') : now;
      return myCases.filter(c => {
        const cDate = new Date(c.created_at);
        return cDate >= from && cDate <= to;
      });
    }

    const months = parseInt(dateFilter);
    fromDate = new Date(now.getFullYear(), now.getMonth() - months, now.getDate());
    return myCases.filter(c => new Date(c.created_at) >= fromDate);
  }, [myCases, dateFilter, customFrom, customTo]);

  const totalCases = filteredCases.length;
  const openCases = filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status)).length;
  const resolvedCases = filteredCases.filter(c => c.status === 'resolved').length;
  const escalatedCases = filteredCases.filter(c => c.status === 'escalated').length;
  const slaBreach = filteredCases.filter(c => c.sla_status === 'breached').length;
  const pendingCases = filteredCases.filter(c => c.status === 'pending_customer').length;
  const autoRejected = filteredCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85).length;

  const navigateWithFilter = (filterKey, filterValue) => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '', [filterKey]: filterValue });
    navigate('/cases');
  };

  const typeDistribution = [
    { name: 'Fraud Ordering', value: filteredCases.filter(c => c.ticket_type === 'fraud_ordering').length },
    { name: 'Fraud Non-Ordering', value: filteredCases.filter(c => c.ticket_type === 'fraud_non_ordering').length },
    { name: 'Credit Abuse Ordering', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_ordering').length },
    { name: 'Credit Abuse SOR', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_sor').length },
    { name: 'Credit Abuse Appeal', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_appeal').length },
    { name: 'General', value: filteredCases.filter(c => c.ticket_type === 'general').length },
  ];

  const priorityDistribution = [
    { name: 'Critical', value: filteredCases.filter(c => c.priority === 'critical').length, color: '#e74c3c' },
    { name: 'High', value: filteredCases.filter(c => c.priority === 'high').length, color: '#e67e22' },
    { name: 'Medium', value: filteredCases.filter(c => c.priority === 'medium').length, color: '#f1c40f' },
    { name: 'Low', value: filteredCases.filter(c => c.priority === 'low').length, color: '#1abc9c' },
  ];

  const trendData = [
    { week: 'W1 Apr', resolved: 38, open: 7, rate: 0 },
    { week: 'W2 Apr', resolved: 44, open: 8, rate: 15.6 },
    { week: 'W3 Apr', resolved: 41, open: 7, rate: -7.7 },
    { week: 'W4 Apr', resolved: 52, open: 9, rate: 27.1 },
    { week: 'W5 Apr', resolved: 43, open: 12, rate: -9.8 },
  ];

  const COLORS = ['#7986cb', '#ffab40', '#66bb6a', '#ce93d8'];

  const recentActivity = [
    { time: '10:30', event: 'Case FPM-001 assigned to Investigator 1', type: 'assign', caseId: 'FPM-001' },
    { time: '10:15', event: 'Case FPM-008 auto-rejected (score: 95)', type: 'reject', caseId: 'FPM-008' },
    { time: '09:45', event: 'Case FPM-006 resolved - fraud_found', type: 'resolve', caseId: 'FPM-006' },
    { time: '09:30', event: 'SLA breach alert: FPM-004 (156h inactive)', type: 'alert', caseId: 'FPM-004' },
    { time: '09:00', event: 'Case FPM-010 pending customer response', type: 'pending', caseId: 'FPM-010' },
    { time: '08:30', event: 'New ticket UCM-5525 ingested', type: 'new', caseId: null },
    { time: '08:15', event: 'Case FPM-003 auto-approve candidate', type: 'approve', caseId: 'FPM-003' },
  ];

  return (
    <div className="dashboard-page">
      {/* Filter Icon */}
      <div className="dashboard-filter-icon-wrap" ref={filterRef}>
        <button className="dashboard-filter-icon-btn" onClick={() => setFilterOpen(!filterOpen)} title="Filter by period">
          📅
        </button>
        {filterOpen && (
          <div className="dashboard-filter-popup">
            {['all', '1', '2', '3', 'custom'].map(val => {
              const labels = { all: 'All Time', '1': 'Last 1 Month', '2': 'Last 2 Months', '3': 'Last 3 Months', custom: 'Custom Range' };
              return (
                <button
                  key={val}
                  className={`filter-popup-option ${dateFilter === val ? 'active' : ''}`}
                  onClick={() => { setDateFilter(val); if (val !== 'custom') setFilterOpen(false); }}
                >{labels[val]}</button>
              );
            })}
            {dateFilter === 'custom' && (
              <div className="filter-popup-custom">
                <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} className="filter-date-input" />
                <span className="filter-date-sep">to</span>
                <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} className="filter-date-input" />
              </div>
            )}
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div onClick={() => navigateWithFilter('status', '')} style={{ cursor: 'pointer' }}>
          <KPICard title="Total Cases" value={totalCases} color="#1a237e" icon="📋" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'open')} style={{ cursor: 'pointer' }}>
          <KPICard title="Open Cases" value={openCases} color="#e65100" icon="📂" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'resolved')} style={{ cursor: 'pointer' }}>
          <KPICard title="Resolved" value={resolvedCases} color="#2e7d32" icon="✅" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'escalated')} style={{ cursor: 'pointer' }}>
          <KPICard title="Escalated" value={escalatedCases} color="#c62828" icon="🚨" />
        </div>
        <div onClick={() => isSuperOrLead ? navigate('/sla-monitor') : navigateWithFilter('status', '')} style={{ cursor: 'pointer' }}>
          <KPICard title="SLA Breached" value={slaBreach} color="#d84315" icon="⏰" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'pending_customer')} style={{ cursor: 'pointer' }}>
          <KPICard title="Pending" value={pendingCases} color="#7b1fa2" />
        </div>
        <div onClick={() => { setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '' }); navigate('/cases?filter=auto_rejected'); }} style={{ cursor: 'pointer' }}>
          <KPICard title="Auto-Rejected" value={autoRejected} color="#ad1457" icon="🤖" />
        </div>
        {isSuperOrLead && (
          <>
            <KPICard title="AI Accuracy" value={`${FEEDBACK_METRICS.ai_accuracy}%`} color="#00838f" icon="🎯" />
            <KPICard title="Total Decisions" value={FEEDBACK_METRICS.total_decisions} color="#1565c0" icon="📊" />
          </>
        )}
      </div>

      {/* Charts Row */}
      <div className="charts-row">
        <div className="chart-card">
          <h3>Case Distribution by Type <span className="info-tooltip-wrap" data-tooltip="Breakdown of fraud cases by category — SIM Swap, Account Takeover, etc.">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <BarChart data={typeDistribution} margin={{ top: 10, right: 10, left: -10, bottom: 40 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
              <XAxis dataKey="name" fontSize={10} tick={{ fill: chartColors.tick }} axisLine={false} tickLine={false} interval={0} angle={-30} textAnchor="end" />
              <YAxis tick={{ fill: chartColors.tick }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '10px', color: '#212121', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} cursor={false} />
              <Bar dataKey="value" fill="#6366f1" radius={[6, 6, 0, 0]} barSize={28} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Priority Breakdown <span className="info-tooltip-wrap" data-tooltip="Distribution of cases across Critical, High, Medium and Low priority levels">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <PieChart>
              <Pie
                data={priorityDistribution}
                cx="50%" cy="48%"
                innerRadius="40%" outerRadius="68%"
                dataKey="value"
                paddingAngle={0}
                stroke="none"
                isAnimationActive={false}
                activeIndex={-1}
                activeShape={() => null}
                labelLine={false}
                label={({ cx, cy, midAngle, innerRadius, outerRadius, name, value }) => {
                  const RADIAN = Math.PI / 180;
                  const total = priorityDistribution.reduce((s, d) => s + d.value, 0);
                  const pct = Math.round((value / total) * 100);
                  const midR = (innerRadius + outerRadius) / 2;
                  const xIn = cx + midR * Math.cos(-midAngle * RADIAN);
                  const yIn = cy + midR * Math.sin(-midAngle * RADIAN);
                  const xOut = cx + (outerRadius + 20) * Math.cos(-midAngle * RADIAN);
                  const yOut = cy + (outerRadius + 20) * Math.sin(-midAngle * RADIAN);
                  return (
                    <g>
                      <text x={xIn} y={yIn} fill="#fff" textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight={700}>{name}</text>
                      <text x={xOut} y={yOut} fill="#37474f" textAnchor="middle" dominantBaseline="central" fontSize={12} fontWeight={700}>{pct}%</text>
                    </g>
                  );
                }}
              >
                {priorityDistribution.map((entry, index) => (
                  <Cell key={index} fill={entry.color} style={{ cursor: 'pointer' }} />
                ))}
              </Pie>
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload || !payload.length) return null;
                  const d = payload[0];
                  return (
                    <div style={{ background: '#fff', border: `2px solid ${d.payload.color}`, borderRadius: 10, padding: '8px 14px', boxShadow: '0 4px 16px rgba(0,0,0,0.12)', textAlign: 'center' }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: d.payload.color }}>{d.name}</div>
                      <div style={{ fontSize: 18, fontWeight: 800, color: '#1a2332' }}>{d.value} <span style={{ fontSize: 11, color: '#90a4ae', fontWeight: 600 }}>cases</span></div>
                    </div>
                  );
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Weekly Case Trend <span className="info-tooltip-wrap" data-tooltip="Week-over-week trend of resolved vs open cases with growth rate">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <ComposedChart data={trendData} barCategoryGap="25%" margin={{ top: 20, right: 5, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
              <XAxis dataKey="week" fontSize={10} tick={{ fill: chartColors.tick }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fill: chartColors.tick, fontSize: 10 }} axisLine={false} tickLine={false} width={30} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#ef6c5e', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} width={35} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '10px', color: '#212121', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} cursor={false} />
              <Legend wrapperStyle={{ color: chartColors.legend, paddingTop: 4, fontSize: '0.75rem' }} iconType="square" iconSize={10} />
              <Bar yAxisId="left" dataKey="resolved" stackId="a" fill="#2dd4bf" name="Resolved" radius={[0, 0, 0, 0]} />
              <Bar yAxisId="left" dataKey="open" stackId="a" fill="#f7a9a0" name="Open" radius={[3, 3, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="rate" stroke="#ef6c5e" strokeWidth={2.5} name="Growth %" dot={{ fill: '#fff', stroke: '#ef6c5e', strokeWidth: 2, r: 5 }} activeDot={{ r: 7, fill: '#ef6c5e' }}>
                <LabelList dataKey="rate" position="top" fontSize={10} fill="#ef6c5e" fontWeight={700} formatter={v => `${v}%`} offset={10} />
              </Line>
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="bottom-row">
        <div className="activity-feed">
          <h3>Recent Activity <span className="info-tooltip-wrap" data-tooltip="Live feed of latest case actions — status changes, assignments, dispositions">&#9432;</span></h3>
          <div className="activity-list">
            {recentActivity.map((a, i) => (
              <div key={i} className={`activity-item activity-${a.type} ${a.caseId ? 'activity-clickable' : ''}`}
                onClick={() => a.caseId && navigate(`/cases?case=${a.caseId}`)}
                style={a.caseId ? { cursor: 'pointer' } : {}}>
                <span className="activity-time">{a.time}</span>
                <span className="activity-event">{a.event}</span>
              </div>
            ))}
          </div>
        </div>

        {isSuperOrLead && (
        <div className="ai-summary-wrapper">
          <div className="ai-summary-header">AI Summary and Feedback</div>
          <div className="ai-summary-scroll">
          <div className="feedback-card">
          <h3>AI vs Human <span className="info-tooltip-wrap" data-tooltip="How often does the human investigator agree with the AI recommendation?">&#9432;</span></h3>
          {/* ── VISUAL SCORECARD ── */}
          <div className="avh-scorecard">
            <div className="avh-score-ring">
              <svg viewBox="0 0 120 120" className="avh-ring-svg">
                <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(0,0,0,0.06)" strokeWidth="10"/>
                <circle cx="60" cy="60" r="52" fill="none" stroke="#2e7d32" strokeWidth="10"
                  strokeDasharray={`${FEEDBACK_METRICS.ai_accuracy * 3.267} ${326.7 - FEEDBACK_METRICS.ai_accuracy * 3.267}`}
                  strokeDashoffset="81.675" strokeLinecap="round" className="avh-ring-fill"/>
              </svg>
              <div className="avh-ring-text">
                <span className="avh-ring-value">{FEEDBACK_METRICS.ai_accuracy}%</span>
                <span className="avh-ring-label">AI Accuracy</span>
              </div>
            </div>
            <div className="avh-score-stats">
              <div className="avh-stat-row">
                <div className="avh-stat-info">
                  <span className="avh-stat-number" style={{color: '#2e7d32'}}>{Math.round(FEEDBACK_METRICS.total_decisions * FEEDBACK_METRICS.accept_rate / 100)} cases</span>
                  <span className="avh-stat-desc">Human <b>agreed</b> with AI</span>
                </div>
                <span className="avh-stat-count" style={{color: '#2e7d32', fontSize:"1.5em"}}>{FEEDBACK_METRICS.accept_rate}%</span>
              </div>
              <div className="avh-stat-row">
                <div className="avh-stat-info">
                  <span className="avh-stat-number" style={{color: '#c62828'}}>{Math.round(FEEDBACK_METRICS.total_decisions * FEEDBACK_METRICS.override_rate / 100)} cases</span>
                  <span className="avh-stat-desc">Human <b>overrode</b> AI</span>
                </div>
                <span className="avh-stat-count" style={{color: '#c62828', fontSize:"1.5em"}}>{FEEDBACK_METRICS.override_rate}%</span>
              </div>
              <div className="avh-stat-row avh-stat-total">
                <div className="avh-stat-info">
                  <span className="avh-stat-number">{FEEDBACK_METRICS.total_decisions}</span>
                  <span className="avh-stat-desc">Total decisions compared</span>
                </div>
              </div>
            </div>
          </div>

          {/* ── RECENT DECISIONS TABLE ── */}
          <div className="feedback-section">
            <h4>Recent AI vs Human Decisions</h4>
            <div className="avh-table-wrapper">
              <table className="avh-table">
                <thead>
                  <tr>
                    <th>Case</th>
                    <th>Risk</th>
                    <th>AI</th>
                    <th>Human</th>
                    <th>Result</th>
                  </tr>
                </thead>
                <tbody>
                  {AI_VS_HUMAN_HISTORY.map(h => (
                    <tr key={h.case_id}>
                      <td>{h.case_id}</td>
                      <td>{h.risk_score}</td>
                      <td>{h.ai_recommendation.replace(/_/g, ' ')}</td>
                      <td>{h.human_disposition.replace(/_/g, ' ')}</td>
                      <td>{h.accepted ? <span className="avh-result-agree">Agree</span> : <span className="avh-result-override">Override</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* ── ACCURACY BY DISPOSITION ── */}
          <div className="feedback-section">
            <h4>AI Accuracy by Decision Type</h4>
            <p className="avh-section-desc">When AI says "approve", does the human agree? How about "reject"?</p>
            <div className="avh-disposition-cards">
              {Object.entries(FEEDBACK_METRICS.by_disposition).map(([key, val]) => {
                const badgeColors = { approve: '#2e7d32', reject: '#c62828', fraud_found: '#c62828', customer_engagement: '#1565c0', cannot_determine: '#546e7a', no_fraud: '#2e7d32', waiting_for_documents: '#e65100', issue_with_ticket: '#7b1fa2', credit_approved: '#1565c0', credit_denied: '#c62828' };
                const barColor = badgeColors[key] || '#546e7a';
                return (
                <div key={key} className={`avh-disp-card ${val.accuracy < 70 ? 'avh-disp-warn' : ''}`}>
                  <div className="avh-disp-card-header">
                    <span className={`avh-disp-badge avh-disp-${key}`}>{key.replace(/_/g, ' ')}</span>
                    <span className="avh-disp-card-pct" style={{ color: barColor }}>{val.accuracy}%</span>
                  </div>
                  <div className="avh-disp-card-bar">
                    <div className="avh-disp-card-fill" style={{ width: `${val.accuracy}%`, background: barColor }}></div>
                  </div>
                  <div className="avh-disp-card-detail">
                    <span>{val.correct} agreed</span>
                    <span>{val.total - val.correct} overridden</span>
                    <span>{val.total} total</span>
                  </div>
                  {val.accuracy < 70 && <div className="avh-disp-card-alert">Below 70% — needs review</div>}
                </div>
                );
              })}
            </div>
          </div>

          {/* ── RISK BAND ACCURACY ── */}
          <div className="feedback-section">
            <h4>AI Accuracy by Risk Level</h4>
            <p className="avh-section-desc">Is AI better at obvious fraud (high risk) or borderline cases (medium)?</p>
            <div className="avh-riskband-cards">
              {Object.entries(FEEDBACK_METRICS.by_risk_band).map(([band, data]) => {
                const bandColors = { low: '#2e7d32', medium: '#f59e0b', high: '#dc2626' };
                const bColor = bandColors[band] || '#546e7a';
                return (
                <div key={band} className="avh-riskband-card">
                  <div className="avh-riskband-header">
                    <span className={`risk-band-tag band-${band}`}>{band}</span>
                    <span className="avh-riskband-range">Score {data.range}</span>
                  </div>
                  <div className="avh-riskband-pct" style={{ color: bColor }}>{data.accuracy}%</div>
                  <div className="avh-riskband-bar">
                    <div className="avh-riskband-fill" style={{ width: `${data.accuracy}%`, background: bColor }}></div>
                  </div>
                  <div className="avh-riskband-detail">{data.correct}/{data.total} agreed</div>
                </div>
                );
              })}
            </div>
          </div>

          {/* ── COMMON OVERRIDE PATTERNS ── */}
          <div className="feedback-section">
            <h4>Top Override Patterns</h4>
            <p className="avh-section-desc">Most common cases where humans disagree with AI:</p>
            <div className="avh-override-list">
              {FEEDBACK_METRICS.common_overrides.map((o, i) => {
                const parts = o.split('(');
                return (
                  <div key={i} className="avh-override-item">
                    <span className="avh-override-num">{i + 1}</span>
                    <div className="avh-override-content">
                      <span className="avh-override-action">{parts[0].trim()}</span>
                      {parts[1] && <span className="avh-override-reason">({parts[1]}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── RECOMMENDATIONS ── */}
          <div className="feedback-section">
            <h4>Threshold Recommendations</h4>
            <ul className="threshold-recs">
              {FEEDBACK_METRICS.override_rate > 30 && <li className="rec-warning">Override rate ({FEEDBACK_METRICS.override_rate}%) exceeds 30% — review auto-decision thresholds</li>}
              {Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).map(([key, val]) => (
                <li key={key} className="rec-warning">"{key.replace(/_/g, ' ')}" accuracy ({val.accuracy}%) below 70% — adjust confidence threshold</li>
              ))}
              {Object.entries(FEEDBACK_METRICS.by_risk_band).filter(([, v]) => v.accuracy < 60).map(([key, val]) => (
                <li key={key} className="rec-critical">Risk band "{key}" accuracy ({val.accuracy}%) below 60% — retrain model</li>
              ))}
              {FEEDBACK_METRICS.override_rate <= 30 && Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).length === 0 && (
                <li className="rec-ok">All metrics within acceptable thresholds</li>
              )}
            </ul>
          </div>
        </div>
          </div>
        </div>
        )}
      </div>

    </div>
  );
}
