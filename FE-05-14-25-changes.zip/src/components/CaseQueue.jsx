import React, { useState, useRef, useEffect } from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { USERS, DISPOSITIONS } from '../data/dummyData';

const CASES_PER_PAGE = 10;

export default function CaseQueue() {
  const { user } = useAuth();
  const { getFilteredCases, setSelectedCase, selectedCase, updateCase, addComment } = useCases();
  const [quickFilter, setQuickFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [dispPopup, setDispPopup] = useState(null);
  const [dispValue, setDispValue] = useState('');
  const [dispComment, setDispComment] = useState('');
  const [escalateReason, setEscalateReason] = useState('');
  const exportRef = useRef(null);
  const dispRef = useRef(null);
  const filteredCases = getFilteredCases(user.role, user.id);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false);
      if (dispRef.current && !dispRef.current.contains(e.target)) setDispPopup(null);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDispSubmit = (c) => {
    if (!dispValue) return;
    updateCase(c.id, {
      disposition: dispValue,
      status: 'resolved',
      updated_at: new Date().toISOString(),
      status_history: [...c.status_history, { from: c.status, to: 'resolved', changed_by: user.name, changed_at: new Date().toISOString(), reason: `Disposition: ${dispValue}${dispComment ? ' — ' + dispComment : ''}` }]
    });
    addComment(c.id, { id: `c-${Date.now()}`, author: user.name, text: `Disposition submitted: ${dispValue}. ${dispComment}`, created_at: new Date().toISOString() });
    setDispPopup(null);
    setDispValue('');
    setDispComment('');
  };

  const handleEscalate = (c) => {
    if (!escalateReason.trim()) return;
    updateCase(c.id, {
      status: 'escalated',
      updated_at: new Date().toISOString(),
      status_history: [...c.status_history, { from: c.status, to: 'escalated', changed_by: user.name, changed_at: new Date().toISOString(), reason: escalateReason }]
    });
    addComment(c.id, { id: `c-${Date.now()}`, author: user.name, text: `Case escalated to supervisor. Reason: ${escalateReason}`, created_at: new Date().toISOString() });
    setEscalateReason('');
    setDispPopup(null);
  };

  // Apply quick filters on top of existing filters
  const getQuickFiltered = () => {
    switch (quickFilter) {
      case 'open':
        return filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'my_open':
        return filteredCases.filter(c => c.assigned_to === user.id && ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'auto_rejected':
        return filteredCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85);
      case 'pending':
        return filteredCases.filter(c => c.status === 'pending_customer' || c.disposition === 'pending');
      default:
        return filteredCases;
    }
  };

  const displayCases = getQuickFiltered();
  const totalPages = Math.ceil(displayCases.length / CASES_PER_PAGE);
  const paginatedCases = displayCases.slice((currentPage - 1) * CASES_PER_PAGE, currentPage * CASES_PER_PAGE);

  // Reset page when filter changes
  const handleFilterChange = (filter) => {
    setQuickFilter(filter);
    setCurrentPage(1);
  };

  const getAssigneeName = (id) => USERS.find(u => u.id === id)?.name || 'Unassigned';

  const getSLAIcon = (sla) => {
    switch (sla) {
      case 'on_track': return <span className="sla-badge on-track">On Track</span>;
      case 'at_risk': return <span className="sla-badge at-risk">At Risk</span>;
      case 'breached': return <span className="sla-badge breached">Breached</span>;
      default: return null;
    }
  };

  const getPriorityClass = (p) => {
    switch (p) {
      case 'critical': return 'priority-critical';
      case 'high': return 'priority-high';
      case 'medium': return 'priority-medium';
      case 'low': return 'priority-low';
      default: return '';
    }
  };

  return (
    <div className="case-queue">
      <table className="queue-table">
        <thead>
          <tr>
            <th>Case ID</th>
            <th>UCM #</th>
            <th>Order #</th>
            <th>Type</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Risk</th>
            <th>SLA</th>
            <th>Disposition</th>
            <th>Investigator</th>
          </tr>
        </thead>
        <tbody>
          {paginatedCases.map(c => (
            <tr
              key={c.id}
              className={`queue-row ${selectedCase?.id === c.id ? 'selected' : ''}`}
              onClick={() => setSelectedCase(c)}
            >
              <td className="case-id">{c.id}</td>
              <td>{c.ucm_ticket_id}</td>
              <td>{c.order_id}</td>
              <td><span className="type-badge">{c.ticket_type.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span></td>
              <td><span className={`priority-badge ${getPriorityClass(c.priority)}`}>{c.priority}</span></td>
              <td><span className={`status-badge status-${c.status}`}>{c.status.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span></td>
              <td><span className="risk-score">{c.risk_score}</span></td>
              <td>{getSLAIcon(c.sla_status)}</td>
              <td style={{ position: 'relative' }}>
                {c.disposition ? (
                  <span
                    className={`status-badge status-resolved`}
                    style={{ fontSize: '0.7rem', cursor: 'pointer' }}
                    onClick={(e) => { e.stopPropagation(); setDispPopup(c.id); setDispValue(c.disposition); setDispComment(''); }}
                  >{c.disposition.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}</span>
                ) : (
                  <button
                    className="btn-primary"
                    style={{ fontSize: '0.65rem', padding: '3px 8px', whiteSpace: 'nowrap' }}
                    onClick={(e) => { e.stopPropagation(); setDispPopup(c.id); setDispValue(''); setDispComment(''); }}
                  >
                    -- Set --
                  </button>
                )}
                {dispPopup === c.id && (
                  <div ref={dispRef} className="disp-popup-overlay" onClick={(e) => { e.stopPropagation(); setDispPopup(null); }}>
                    <div className="disp-popup-modal" onClick={(e) => e.stopPropagation()}>
                      <div className="disp-popup-header">
                        <h4>Disposition — {c.id}</h4>
                        <button className="disp-popup-close" onClick={() => setDispPopup(null)}>×</button>
                      </div>
                      <div className="disp-popup-body">
                      <div className="avh-case-compare" style={{ margin: 0 }}>
                        <div className="avh-compare-cards" style={{ gap: 10 }}>
                          <div className="avh-compare-ai" style={{ flex: 1 }}>
                            <div className="avh-compare-label">AI</div>
                            <div className={`avh-compare-disp avh-disp-${c.agent_insights.decision.recommendation}`}>
                              {c.agent_insights.decision.recommendation.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}
                            </div>
                            <div className="avh-compare-conf">Confidence: {c.agent_insights.decision.confidence}%</div>
                            <div className="avh-compare-reason" style={{ fontSize: '0.72rem' }}>{c.agent_insights.decision.reasoning}</div>
                          </div>
                          <div className="avh-compare-vs">VS</div>
                          <div className="avh-compare-human" style={{ flex: 1 }}>
                            <div className="avh-compare-label">HUMAN</div>
                            {c.disposition ? (
                              <div className={`avh-compare-disp avh-disp-${c.disposition}`}>
                                {c.disposition.replace(/_/g, ' ').replace(/\b\w/g, c2 => c2.toUpperCase())}
                              </div>
                            ) : (
                              <div className="avh-compare-pending">Select below...</div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="disp-popup-form">
                        <label>Disposition:</label>
                        <select value={dispValue} onChange={e => setDispValue(e.target.value)}>
                          <option value="">Select disposition...</option>
                          {DISPOSITIONS.map(d => <option key={d} value={d}>{d.replace(/_/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase())}</option>)}
                        </select>
                        <label>Comments:</label>
                        <textarea value={dispComment} onChange={e => setDispComment(e.target.value)} placeholder="Enter notes..." rows={3} />
                        <button className="btn-primary" onClick={() => handleDispSubmit(c)} disabled={!dispValue} style={{ marginTop: 8, width: '100%' }}>Submit Disposition</button>
                      </div>
                      <div className="escalate-section" style={{ marginTop: 16, borderTop: '2px solid #e65100', paddingTop: 14 }}>
                        <h4 style={{ margin: '0 0 10px', color: '#1a2332', fontWeight: 700 }}>Escalate to Supervisor</h4>
                        <textarea
                          value={escalateReason}
                          onChange={e => setEscalateReason(e.target.value)}
                          placeholder="Reason for escalation (required)..."
                          className="escalate-reason-input"
                          rows={2}
                        />
                        <button className="btn-warning" onClick={() => handleEscalate(c)} disabled={!escalateReason.trim()} style={{ marginTop: 8, width: '100%' }}>
                          Escalate to Supervisor
                        </button>
                      </div>
                      </div>
                    </div>
                  </div>
                )}
              </td>
              <td>{getAssigneeName(c.assigned_to)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {totalPages > 1 && (
        <div className="pagination-bar">
          <button
            className="pagination-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(currentPage - 1)}
          >
            ← Prev
          </button>
          <div className="pagination-pages">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                className={`pagination-page ${currentPage === page ? 'active' : ''}`}
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </button>
            ))}
          </div>
          <button
            className="pagination-btn"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(currentPage + 1)}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
