import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useSystemHealth } from '../contexts/SystemHealthContext';

export default function Header() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { isFullyOperational, degradedServices, toggleService } = useSystemHealth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="app-header">
      <div className="header-left">
        <div className="logo">🛡️ FPM Platform</div>
        <nav className="main-nav">
          <NavLink to="/dashboard" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">📊</span><span className="nav-label">Summary</span></NavLink>
          <NavLink to="/cases" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">📋</span><span className="nav-label">Cases</span></NavLink>
          <NavLink to="/data-spider" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">🕷️</span><span className="nav-label">Data Spider</span></NavLink>
          <NavLink to="/fraud-map" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">🗺️</span><span className="nav-label">Fraud Map</span></NavLink>
          <NavLink to="/nlp-query" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">💬</span><span className="nav-label">NLP Query</span></NavLink>
          {user?.role === 'supervisor' && (
            <NavLink to="/sla-monitor" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">⚠️</span><span className="nav-label">SLA Monitor</span></NavLink>
          )}
          {user?.role === 'supervisor' && (
            <NavLink to="/audit-log" className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}><span className="nav-icon">📋</span><span className="nav-label">Audit Log</span></NavLink>
          )}
        </nav>
      </div>
      <div className="header-right">
        {!isFullyOperational && (
          <div className="degradation-indicator" title={`Degraded: ${degradedServices.join(', ')}`}>
            <span className="degradation-icon">⚠️</span>
            <span className="degradation-text">
              {degradedServices.map(s => s.replace(/_/g, ' ')).join(', ')} unavailable
            </span>
          </div>
        )}
        {user?.role === 'supervisor' && (
          <div className="health-toggle-group">
            <button className={`health-toggle-btn ${!isFullyOperational ? 'degraded' : 'healthy'}`}
              onClick={() => toggleService('openai_api')}
              title="Toggle OpenAI API status (demo)"
            >
              {isFullyOperational ? '🟢' : '🟡'} AI
            </button>
          </div>
        )}
        <div className="user-info">
          <span className="user-name">👤 {user?.name}</span>
          <span className={`role-badge ${user?.role}`}>{user?.role}</span>
        </div>
        <button className="btn-theme-toggle" onClick={toggleTheme} title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}>
          {theme === 'dark' ? '☀️' : '🌙'}
        </button>
        <button className="btn-logout" onClick={handleLogout}>Logout</button>
      </div>
    </header>
  );
}
