import React from 'react';

export default function KPICard({ title, value, color, icon }) {
  return (
    <div
      className="kpi-card"
      style={{
        borderTop: `4px solid ${color}`,
        borderLeft: 'none',
        background: '#ffffff',
      }}
    >
      <div className="kpi-icon">{icon}</div>
      <div className="kpi-content">
        <div className="kpi-value" style={{ color }}>{value}</div>
        <div className="kpi-title">{title}</div>
      </div>
    </div>
  );
}
