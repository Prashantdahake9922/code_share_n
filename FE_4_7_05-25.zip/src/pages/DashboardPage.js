import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';

import { FEEDBACK_METRICS, AI_VS_HUMAN_HISTORY } from '../data/dummyData';
import KPICard from '../components/KPICard';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, Legend } from 'recharts';

export default function DashboardPage() {
  const { user } = useAuth();
  const { cases, setFilters } = useCases();
  const navigate = useNavigate();

  // Date filter state
  const [dateFilter, setDateFilter] = useState('all'); // 'all', '1m', '2m', '3m', '6m', 'custom'
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');

  const chartColors = {
    grid: 'rgba(0,0,0,0.1)',
    tick: '#37474f',
    axis: '#90a4ae',
    label: '#546e7a',
    legend: '#37474f',
  };

  // Role-based: investigator sees only their cases, supervisor sees all
  const myCases = user.role === 'investigator'
    ? cases.filter(c => c.assigned_to === user.id)
    : cases;

  // Apply date filter
  const filteredCases = useMemo(() => {
    if (dateFilter === 'all') return myCases;

    const now = new Date();
    let fromDate;

    if (dateFilter === 'custom') {
      if (!customFrom && !customTo) return myCases;
      const from = customFrom ? new Date(customFrom) : new Date('2000-01-01');
      const to = customTo ? new Date(customTo + 'T23:59:59') : now;
      return myCases.filter(c => {
        const cDate = new Date(c.created_at);
        return cDate >= from && cDate <= to;
      });
    }

    const months = parseInt(dateFilter);
    fromDate = new Date(now.getFullYear(), now.getMonth() - months, now.getDate());
    return myCases.filter(c => new Date(c.created_at) >= fromDate);
  }, [myCases, dateFilter, customFrom, customTo]);

  const totalCases = filteredCases.length;
  const openCases = filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status)).length;
  const resolvedCases = filteredCases.filter(c => c.status === 'resolved').length;
  const escalatedCases = filteredCases.filter(c => c.status === 'escalated').length;
  const slaBreach = filteredCases.filter(c => c.sla_status === 'breached').length;
  const pendingCases = filteredCases.filter(c => c.status === 'pending_customer').length;
  const autoRejected = filteredCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85).length;

  const navigateWithFilter = (filterKey, filterValue) => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '', [filterKey]: filterValue });
    navigate('/cases');
  };

  const typeDistribution = [
    { name: 'Fraud Ordering', value: filteredCases.filter(c => c.ticket_type === 'fraud_ordering').length },
    { name: 'Fraud Non-Ordering', value: filteredCases.filter(c => c.ticket_type === 'fraud_non_ordering').length },
    { name: 'Credit Abuse Ordering', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_ordering').length },
    { name: 'Credit Abuse SOR', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_sor').length },
    { name: 'Credit Abuse Appeal', value: filteredCases.filter(c => c.ticket_type === 'credit_abuse_appeal').length },
    { name: 'General', value: filteredCases.filter(c => c.ticket_type === 'general').length },
  ];

  const priorityDistribution = [
    { name: 'Critical', value: filteredCases.filter(c => c.priority === 'critical').length, color: '#ef5350' },
    { name: 'High', value: filteredCases.filter(c => c.priority === 'high').length, color: '#ffab40' },
    { name: 'Medium', value: filteredCases.filter(c => c.priority === 'medium').length, color: '#ffd54f' },
    { name: 'Low', value: filteredCases.filter(c => c.priority === 'low').length, color: '#66bb6a' },
  ];

  const trendData = [
    { week: 'W1 Apr', cases: 45, resolved: 38 },
    { week: 'W2 Apr', cases: 52, resolved: 44 },
    { week: 'W3 Apr', cases: 48, resolved: 41 },
    { week: 'W4 Apr', cases: 61, resolved: 52 },
    { week: 'W5 Apr', cases: 55, resolved: 43 },
  ];

  const COLORS = ['#7986cb', '#ffab40', '#66bb6a', '#ce93d8'];

  const recentActivity = [
    { time: '10:30', event: 'Case FPM-001 assigned to Investigator 1', type: 'assign', caseId: 'FPM-001' },
    { time: '10:15', event: 'Case FPM-008 auto-rejected (score: 95)', type: 'reject', caseId: 'FPM-008' },
    { time: '09:45', event: 'Case FPM-006 resolved - fraud_found', type: 'resolve', caseId: 'FPM-006' },
    { time: '09:30', event: 'SLA breach alert: FPM-004 (156h inactive)', type: 'alert', caseId: 'FPM-004' },
    { time: '09:00', event: 'Case FPM-010 pending customer response', type: 'pending', caseId: 'FPM-010' },
    { time: '08:30', event: 'New ticket UCM-5525 ingested', type: 'new', caseId: null },
    { time: '08:15', event: 'Case FPM-003 auto-approve candidate', type: 'approve', caseId: 'FPM-003' },
  ];

  return (
    <div className="dashboard-page">
      <h1>Dashboard</h1>

      {/* Date Filter Bar */}
      <div className="dashboard-filter-bar">
        <div className="filter-bar-label">📅 Filter Period:</div>
        <select
          className="filter-period-select"
          value={dateFilter}
          onChange={e => setDateFilter(e.target.value)}
        >
          <option value="all">All Time</option>
          <option value="1">Last 1 Month</option>
          <option value="2">Last 2 Months</option>
          <option value="3">Last 3 Months</option>
          <option value="custom">Custom Range</option>
        </select>
        {dateFilter === 'custom' && (
          <div className="filter-custom-dates">
            <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} className="filter-date-input" />
            <span className="filter-date-sep">to</span>
            <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} className="filter-date-input" />
          </div>
        )}
        <div className="filter-result-count">
          Showing <strong>{filteredCases.length}</strong> of {myCases.length} cases
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <div onClick={() => navigateWithFilter('status', '')} style={{ cursor: 'pointer' }}>
          <KPICard title="Total Cases" value={totalCases} color="#1a237e" icon="📋" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'open')} style={{ cursor: 'pointer' }}>
          <KPICard title="Open Cases" value={openCases} color="#e65100" icon="📂" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'resolved')} style={{ cursor: 'pointer' }}>
          <KPICard title="Resolved" value={resolvedCases} color="#2e7d32" icon="✅" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'escalated')} style={{ cursor: 'pointer' }}>
          <KPICard title="Escalated" value={escalatedCases} color="#c62828" icon="🚨" />
        </div>
        <div onClick={() => user.role === 'supervisor' ? navigate('/sla-monitor') : navigateWithFilter('status', '')} style={{ cursor: 'pointer' }}>
          <KPICard title="SLA Breached" value={slaBreach} color="#d84315" icon="⏰" />
        </div>
        <div onClick={() => navigateWithFilter('status', 'pending_customer')} style={{ cursor: 'pointer' }}>
          <KPICard title="Pending" value={pendingCases} color="#7b1fa2" />
        </div>
        <div onClick={() => { setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '' }); navigate('/cases?filter=auto_rejected'); }} style={{ cursor: 'pointer' }}>
          <KPICard title="Auto-Rejected" value={autoRejected} color="#ad1457" icon="🤖" />
        </div>
        {user.role === 'supervisor' && (
          <>
            <KPICard title="AI Accuracy" value={`${FEEDBACK_METRICS.ai_accuracy}%`} color="#00838f" icon="🎯" />
            <KPICard title="Total Decisions" value={FEEDBACK_METRICS.total_decisions} color="#1565c0" icon="📊" />
          </>
        )}
      </div>

      {/* Charts Row */}
      <div className="charts-row">
        <div className="chart-card">
          <h3>Case Distribution by Type</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={typeDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis dataKey="name" fontSize={11} tick={{ fill: chartColors.tick }} axisLine={{ stroke: chartColors.axis }} />
              <YAxis tick={{ fill: chartColors.tick }} axisLine={{ stroke: chartColors.axis }} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #bdbdbd', borderRadius: '8px', color: '#212121' }} />
              <Bar dataKey="value" fill="#303f9f" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Priority Breakdown</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={priorityDistribution} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={{ stroke: chartColors.label }} style={{ fontSize: '0.75rem' }}>
                {priorityDistribution.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #bdbdbd', borderRadius: '8px', color: '#212121' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Weekly Case Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis dataKey="week" fontSize={11} tick={{ fill: chartColors.tick }} axisLine={{ stroke: chartColors.axis }} />
              <YAxis tick={{ fill: chartColors.tick }} axisLine={{ stroke: chartColors.axis }} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #bdbdbd', borderRadius: '8px', color: '#212121' }} />
              <Legend wrapperStyle={{ color: chartColors.legend }} />
              <Line type="monotone" dataKey="cases" stroke="#1565c0" strokeWidth={2} name="New Cases" dot={{ fill: '#1565c0' }} />
              <Line type="monotone" dataKey="resolved" stroke="#2e7d32" strokeWidth={2} name="Resolved" dot={{ fill: '#2e7d32' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="bottom-row">
        <div className="activity-feed">
          <h3>Recent Activity</h3>
          <div className="activity-list">
            {recentActivity.map((a, i) => (
              <div key={i} className={`activity-item activity-${a.type} ${a.caseId ? 'activity-clickable' : ''}`}
                onClick={() => a.caseId && navigate(`/cases?case=${a.caseId}`)}
                style={a.caseId ? { cursor: 'pointer' } : {}}>
                <span className="activity-time">{a.time}</span>
                <span className="activity-event">{a.event}</span>
              </div>
            ))}
          </div>
        </div>

        {user.role === 'supervisor' && (
        <div className="ai-summary-wrapper">
          <div className="ai-summary-header">📊 AI Summary and Feedback</div>
          <div className="ai-summary-scroll">
          <div className="feedback-card">
          <h3>🤖 AI vs 👤 Human</h3>
          <p className="feedback-subtitle">How often does the human investigator agree with the AI recommendation?</p>
          {/* ── VISUAL SCORECARD ── */}
          <div className="avh-scorecard">
            <div className="avh-score-ring">
              <svg viewBox="0 0 120 120" className="avh-ring-svg">
                <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(0,0,0,0.06)" strokeWidth="10"/>
                <circle cx="60" cy="60" r="52" fill="none" stroke="#2e7d32" strokeWidth="10"
                  strokeDasharray={`${FEEDBACK_METRICS.ai_accuracy * 3.267} ${326.7 - FEEDBACK_METRICS.ai_accuracy * 3.267}`}
                  strokeDashoffset="81.675" strokeLinecap="round" className="avh-ring-fill"/>
              </svg>
              <div className="avh-ring-text">
                <span className="avh-ring-value">{FEEDBACK_METRICS.ai_accuracy}%</span>
                <span className="avh-ring-label">AI Accuracy</span>
              </div>
            </div>
            <div className="avh-score-stats">
              <div className="avh-stat-row">
                <span className="avh-stat-icon">✅</span>
                <div className="avh-stat-info">
                  <span className="avh-stat-number" style={{color: '#2e7d32'}}>{FEEDBACK_METRICS.accept_rate}%</span>
                  <span className="avh-stat-desc">Human <b>agreed</b> with AI</span>
                </div>
                <span className="avh-stat-count">{Math.round(FEEDBACK_METRICS.total_decisions * FEEDBACK_METRICS.accept_rate / 100)} cases</span>
              </div>
              <div className="avh-stat-row">
                <span className="avh-stat-icon">❌</span>
                <div className="avh-stat-info">
                  <span className="avh-stat-number" style={{color: '#c62828'}}>{FEEDBACK_METRICS.override_rate}%</span>
                  <span className="avh-stat-desc">Human <b>overrode</b> AI</span>
                </div>
                <span className="avh-stat-count">{Math.round(FEEDBACK_METRICS.total_decisions * FEEDBACK_METRICS.override_rate / 100)} cases</span>
              </div>
              <div className="avh-stat-row avh-stat-total">
                <span className="avh-stat-icon">📊</span>
                <div className="avh-stat-info">
                  <span className="avh-stat-number">{FEEDBACK_METRICS.total_decisions}</span>
                  <span className="avh-stat-desc">Total decisions compared</span>
                </div>
              </div>
            </div>
          </div>

          {/* ── RECENT DECISIONS TABLE ── */}
          <div className="feedback-section">
            <h4>Recent AI vs Human Decisions</h4>
            <div className="avh-table-wrapper">
              <table className="avh-table">
                <thead>
                  <tr>
                    <th>Case</th>
                    <th>Risk</th>
                    <th>🤖 AI</th>
                    <th>👤 Human</th>
                    <th>Result</th>
                    <th>Override Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {AI_VS_HUMAN_HISTORY.map(h => (
                    <tr key={h.case_id} className={h.accepted ? 'avh-row-agree' : 'avh-row-override'}>
                      <td><span className="avh-case-id">{h.case_id}</span></td>
                      <td><span className={`avh-risk ${h.risk_score >= 70 ? 'avh-risk-high' : h.risk_score >= 35 ? 'avh-risk-med' : 'avh-risk-low'}`}>{h.risk_score}</span></td>
                      <td>
                        <span className={`avh-disp-badge avh-disp-${h.ai_recommendation}`}>{h.ai_recommendation.replace(/_/g, ' ')}</span>
                        <span className="avh-conf">({h.ai_confidence}%)</span>
                      </td>
                      <td><span className={`avh-disp-badge avh-disp-${h.human_disposition}`}>{h.human_disposition.replace(/_/g, ' ')}</span></td>
                      <td>{h.accepted ? <span className="avh-result-agree">✅ Agree</span> : <span className="avh-result-override">❌ Override</span>}</td>
                      <td className="avh-reason">{h.reason || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* ── ACCURACY BY DISPOSITION ── */}
          <div className="feedback-section">
            <h4>AI Accuracy by Decision Type</h4>
            <p className="avh-section-desc">When AI says "approve", does the human agree? How about "reject"?</p>
            <div className="avh-disposition-cards">
              {Object.entries(FEEDBACK_METRICS.by_disposition).map(([key, val]) => (
                <div key={key} className={`avh-disp-card ${val.accuracy < 70 ? 'avh-disp-warn' : ''}`}>
                  <div className="avh-disp-card-header">
                    <span className={`avh-disp-badge avh-disp-${key}`}>{key.replace(/_/g, ' ')}</span>
                    <span className="avh-disp-card-pct" style={{ color: val.accuracy < 70 ? '#c62828' : val.accuracy < 80 ? '#e65100' : '#2e7d32' }}>{val.accuracy}%</span>
                  </div>
                  <div className="avh-disp-card-bar">
                    <div className="avh-disp-card-fill" style={{ width: `${val.accuracy}%`, background: val.accuracy < 70 ? '#c62828' : val.accuracy < 80 ? '#e65100' : '#2e7d32' }}></div>
                  </div>
                  <div className="avh-disp-card-detail">
                    <span>✅ {val.correct} agreed</span>
                    <span>❌ {val.total - val.correct} overridden</span>
                    <span>📊 {val.total} total</span>
                  </div>
                  {val.accuracy < 70 && <div className="avh-disp-card-alert">⚠️ Below 70% — needs review</div>}
                </div>
              ))}
            </div>
          </div>

          {/* ── RISK BAND ACCURACY ── */}
          <div className="feedback-section">
            <h4>AI Accuracy by Risk Level</h4>
            <p className="avh-section-desc">Is AI better at obvious fraud (high risk) or borderline cases (medium)?</p>
            <div className="avh-riskband-cards">
              {Object.entries(FEEDBACK_METRICS.by_risk_band).map(([band, data]) => (
                <div key={band} className="avh-riskband-card">
                  <div className="avh-riskband-header">
                    <span className={`risk-band-tag band-${band}`}>{band}</span>
                    <span className="avh-riskband-range">Score {data.range}</span>
                  </div>
                  <div className="avh-riskband-pct" style={{ color: data.accuracy >= 90 ? '#2e7d32' : data.accuracy >= 80 ? '#e65100' : '#c62828' }}>{data.accuracy}%</div>
                  <div className="avh-riskband-bar">
                    <div className="avh-riskband-fill" style={{ width: `${data.accuracy}%`, background: data.accuracy >= 90 ? '#2e7d32' : data.accuracy >= 80 ? '#e65100' : '#c62828' }}></div>
                  </div>
                  <div className="avh-riskband-detail">{data.correct}/{data.total} agreed</div>
                </div>
              ))}
            </div>
          </div>

          {/* ── COMMON OVERRIDE PATTERNS ── */}
          <div className="feedback-section">
            <h4>Top Override Patterns</h4>
            <p className="avh-section-desc">Most common cases where humans disagree with AI:</p>
            <div className="avh-override-list">
              {FEEDBACK_METRICS.common_overrides.map((o, i) => {
                const parts = o.split('(');
                return (
                  <div key={i} className="avh-override-item">
                    <span className="avh-override-num">{i + 1}</span>
                    <div className="avh-override-content">
                      <span className="avh-override-action">{parts[0].trim()}</span>
                      {parts[1] && <span className="avh-override-reason">({parts[1]}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── RECOMMENDATIONS ── */}
          <div className="feedback-section">
            <h4>🎯 Threshold Recommendations</h4>
            <ul className="threshold-recs">
              {FEEDBACK_METRICS.override_rate > 30 && <li className="rec-warning">⚠️ Override rate ({FEEDBACK_METRICS.override_rate}%) exceeds 30% — review auto-decision thresholds</li>}
              {Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).map(([key, val]) => (
                <li key={key} className="rec-warning">⚠️ "{key.replace(/_/g, ' ')}" accuracy ({val.accuracy}%) below 70% — adjust confidence threshold</li>
              ))}
              {Object.entries(FEEDBACK_METRICS.by_risk_band).filter(([, v]) => v.accuracy < 60).map(([key, val]) => (
                <li key={key} className="rec-critical">🔴 Risk band "{key}" accuracy ({val.accuracy}%) below 60% — retrain model</li>
              ))}
              {FEEDBACK_METRICS.override_rate <= 30 && Object.entries(FEEDBACK_METRICS.by_disposition).filter(([, v]) => v.accuracy < 70).length === 0 && (
                <li className="rec-ok">✅ All metrics within acceptable thresholds</li>
              )}
            </ul>
          </div>
        </div>
          </div>
        </div>
        )}
      </div>
    </div>
  );
}
