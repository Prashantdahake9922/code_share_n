import React, { useState, useRef, useEffect } from 'react';
import { useCases } from '../contexts/CasesContext';
import { useAuth } from '../contexts/AuthContext';
import { USERS } from '../data/dummyData';

const CASES_PER_PAGE = 10;

export default function CaseQueue() {
  const { user } = useAuth();
  const { getFilteredCases, setSelectedCase, selectedCase } = useCases();
  const [quickFilter, setQuickFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef(null);
  const filteredCases = getFilteredCases(user.role, user.id);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (exportRef.current && !exportRef.current.contains(e.target)) setShowExportMenu(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Apply quick filters on top of existing filters
  const getQuickFiltered = () => {
    switch (quickFilter) {
      case 'open':
        return filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'my_open':
        return filteredCases.filter(c => c.assigned_to === user.id && ['open', 'assigned', 'in_progress'].includes(c.status));
      case 'auto_rejected':
        return filteredCases.filter(c => c.risk_score >= 90 && c.agent_insights.decision.recommendation === 'reject' && c.agent_insights.decision.confidence >= 85);
      case 'pending':
        return filteredCases.filter(c => c.status === 'pending_customer' || c.disposition === 'pending');
      default:
        return filteredCases;
    }
  };

  const displayCases = getQuickFiltered();
  const totalPages = Math.ceil(displayCases.length / CASES_PER_PAGE);
  const paginatedCases = displayCases.slice((currentPage - 1) * CASES_PER_PAGE, currentPage * CASES_PER_PAGE);

  // Reset page when filter changes
  const handleFilterChange = (filter) => {
    setQuickFilter(filter);
    setCurrentPage(1);
  };

  const getAssigneeName = (id) => USERS.find(u => u.id === id)?.name || 'Unassigned';

  const getSLAIcon = (sla) => {
    switch (sla) {
      case 'on_track': return <span className="sla-badge on-track">On Track</span>;
      case 'at_risk': return <span className="sla-badge at-risk">At Risk</span>;
      case 'breached': return <span className="sla-badge breached">Breached</span>;
      default: return null;
    }
  };

  const getPriorityClass = (p) => {
    switch (p) {
      case 'critical': return 'priority-critical';
      case 'high': return 'priority-high';
      case 'medium': return 'priority-medium';
      case 'low': return 'priority-low';
      default: return '';
    }
  };

  return (
    <div className="case-queue">
      <div className="quick-filter-bar">
        <button className={`quick-filter-btn ${quickFilter === 'all' ? 'active' : ''}`} onClick={() => handleFilterChange('all')}>All</button>
        <button className={`quick-filter-btn ${quickFilter === 'open' ? 'active' : ''}`} onClick={() => handleFilterChange('open')}>Open</button>
        <button className={`quick-filter-btn ${quickFilter === 'my_open' ? 'active' : ''}`} onClick={() => handleFilterChange('my_open')}>My Open</button>
        <button className={`quick-filter-btn ${quickFilter === 'auto_rejected' ? 'active' : ''}`} onClick={() => handleFilterChange('auto_rejected')}>Auto-Rejected</button>
        <button className={`quick-filter-btn ${quickFilter === 'pending' ? 'active' : ''}`} onClick={() => handleFilterChange('pending')}>Pending</button>
        <div className="export-dropdown" ref={exportRef} style={{ marginLeft: 'auto' }}>
          <button className="btn-export" onClick={() => setShowExportMenu(!showExportMenu)}>
            Export ▾
          </button>
          {showExportMenu && (
            <div className="export-menu">
              <button onClick={() => {
                const headers = ['case_id','ucm_ticket_id','order_id','ticket_type','priority','status','risk_score','sla_status','assigned_to','customer_name','created_at'];
                const rows = displayCases.map(c => [c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.priority, c.status, c.risk_score, c.sla_status, getAssigneeName(c.assigned_to), c.customer.name, c.created_at]);
                const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
                const blob = new Blob([csv], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = 'cases_export.csv'; a.click();
                URL.revokeObjectURL(url);
                setShowExportMenu(false);
              }}>CSV</button>
              <button onClick={() => {
                const data = displayCases.map(c => ({ case_id: c.id, ucm_ticket_id: c.ucm_ticket_id, order_id: c.order_id, ticket_type: c.ticket_type, priority: c.priority, status: c.status, risk_score: c.risk_score, sla_status: c.sla_status, assigned_to: getAssigneeName(c.assigned_to), customer_name: c.customer.name, created_at: c.created_at }));
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = 'cases_export.json'; a.click();
                URL.revokeObjectURL(url);
                setShowExportMenu(false);
              }}>JSON</button>
              <button onClick={() => {
                const headers = ['Case ID','UCM Ticket','Order ID','Ticket Type','Priority','Status','Risk Score','SLA Status','Assigned To','Customer','Created At'];
                const rows = displayCases.map(c => [c.id, c.ucm_ticket_id, c.order_id, c.ticket_type, c.priority, c.status, c.risk_score, c.sla_status, getAssigneeName(c.assigned_to), c.customer.name, c.created_at]);
                let html = '<table><tr>' + headers.map(h => `<th>${h}</th>`).join('') + '</tr>';
                rows.forEach(r => { html += '<tr>' + r.map(v => `<td>${v}</td>`).join('') + '</tr>'; });
                html += '</table>';
                const blob = new Blob([`<html><head><meta charset="utf-8"></head><body>${html}</body></html>`], { type: 'application/vnd.ms-excel' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = 'cases_export.xls'; a.click();
                URL.revokeObjectURL(url);
                setShowExportMenu(false);
              }}>Excel</button>
            </div>
          )}
        </div>
      </div>
      <table className="queue-table">
        <thead>
          <tr>
            <th>Case ID</th>
            <th>UCM #</th>
            <th>Order #</th>
            <th>Type</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Risk</th>
            <th>SLA</th>
            <th>Investigator</th>
          </tr>
        </thead>
        <tbody>
          {paginatedCases.map(c => (
            <tr
              key={c.id}
              className={`queue-row ${selectedCase?.id === c.id ? 'selected' : ''}`}
              onClick={() => setSelectedCase(c)}
            >
              <td className="case-id">{c.id}</td>
              <td>{c.ucm_ticket_id}</td>
              <td>{c.order_id}</td>
              <td><span className="type-badge">{c.ticket_type.replace(/_/g, ' ')}</span></td>
              <td><span className={`priority-badge ${getPriorityClass(c.priority)}`}>{c.priority}</span></td>
              <td><span className={`status-badge status-${c.status}`}>{c.status.replace('_', ' ')}</span></td>
              <td><span className="risk-score">{c.risk_score}</span></td>
              <td>{getSLAIcon(c.sla_status)}</td>
              <td>{getAssigneeName(c.assigned_to)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {totalPages > 1 && (
        <div className="pagination-bar">
          <button
            className="pagination-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(currentPage - 1)}
          >
            ← Prev
          </button>
          <div className="pagination-pages">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                className={`pagination-page ${currentPage === page ? 'active' : ''}`}
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </button>
            ))}
          </div>
          <button
            className="pagination-btn"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(currentPage + 1)}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
