import React, { useState, useMemo, useEffect } from 'react';
import { FRAUD_MAP_DATA } from '../data/dummyData';

// ── Union-Find Algorithm for Fraud Ring Detection (Req 9.5) ─────────────────
class UnionFind {
  constructor(n) {
    this.parent = Array.from({ length: n }, (_, i) => i);
    this.rank = new Array(n).fill(0);
  }

  find(x) {
    if (this.parent[x] !== x) {
      this.parent[x] = this.find(this.parent[x]); // path compression
    }
    return this.parent[x];
  }

  union(x, y) {
    const px = this.find(x);
    const py = this.find(y);
    if (px === py) return false;
    if (this.rank[px] < this.rank[py]) { this.parent[px] = py; }
    else if (this.rank[px] > this.rank[py]) { this.parent[py] = px; }
    else { this.parent[py] = px; this.rank[px]++; }
    return true;
  }
}

/**
 * Detect fraud ring clusters from raw link data using union-find on shared PII attributes.
 * Groups nodes (ZIP codes) into connected components based on shared city, email, phone, address.
 * Returns detected rings with unique IDs assigned per connected component.
 */
function detectFraudRings(rawLinks) {
  const zipSet = new Set();
  rawLinks.forEach(link => { zipSet.add(link.source_zip); zipSet.add(link.target_zip); });
  const zips = [...zipSet];
  const zipIndex = Object.fromEntries(zips.map((z, i) => [z, i]));

  const uf = new UnionFind(zips.length);
  rawLinks.forEach(link => {
    uf.union(zipIndex[link.source_zip], zipIndex[link.target_zip]);
  });

  // Group into components
  const components = {};
  zips.forEach((zip, i) => {
    const root = uf.find(i);
    if (!components[root]) components[root] = { zips: [], links: [], sharedTypes: new Set() };
    components[root].zips.push(zip);
  });

  rawLinks.forEach(link => {
    const root = uf.find(zipIndex[link.source_zip]);
    components[root].links.push(link);
    components[root].sharedTypes.add(link.link_type);
  });

  // Build ring objects with unique IDs
  let ringId = 1;
  return Object.values(components)
    .filter(comp => comp.zips.length > 1) // only multi-node rings
    .sort((a, b) => b.zips.length - a.zips.length)
    .slice(0, 20) // top 20
    .map(comp => {
      const nodes = comp.zips.length;
      const risk_level = nodes >= 5 ? 'critical' : nodes >= 3 ? 'high' : 'medium';
      return {
        id: `FR-${String(ringId++).padStart(3, '0')}`,
        nodes,
        edges: comp.links.length,
        risk_level,
        zips: comp.zips,
        cities: comp.zips,
        links: comp.links,
        shared: [...comp.sharedTypes],
      };
    });
}

// ── Edge color map per link type (Req 9.6) ──────────────────────────────────
const LINK_TYPE_COLORS = {
  city: '#1565c0',
  email: '#c62828',
  phone: '#2e7d32',
  address: '#e65100',
};

export default function FraudMapPage() {
  const [view, setView] = useState('heatmap');
  const [selectedState, setSelectedState] = useState(null);
  const [selectedRing, setSelectedRing] = useState(null);
  const [stateSortBy, setStateSortBy] = useState('fraud_impact');
  const [stateSortOrder, setStateSortOrder] = useState('desc');

  // Run union-find on raw link data to detect clusters (Req 9.5)
  const detectedRings = useMemo(() => detectFraudRings(FRAUD_MAP_DATA.raw_links || []), []);

  // Use detected rings if available, otherwise fall back to pre-computed rings
  const fraudRings = detectedRings.length > 0 ? detectedRings : FRAUD_MAP_DATA.fraud_rings;

  // Auto-select first ring by default
  useEffect(() => {
    if (!selectedRing && fraudRings.length > 0) {
      setSelectedRing(fraudRings[0]);
    }
  }, [fraudRings]);

  const maxImpact = Math.max(...FRAUD_MAP_DATA.states.map(s => s.fraud_impact));

  const getHeatColor = (impact) => {
    const intensity = impact / maxImpact;
    if (intensity > 0.7) return '#c62828';
    if (intensity > 0.5) return '#e65100';
    if (intensity > 0.3) return '#f57f17';
    return '#2e7d32';
  };

  const getRingColor = (level) => {
    switch (level) {
      case 'critical': return '#b71c1c';
      case 'high': return '#e65100';
      case 'medium': return '#f9a825';
      default: return '#bdbdbd';
    }
  };

  // Generate node positions for SVG graph (circular layout)
  const getNodePositions = (nodeCount) => {
    const cx = 200, cy = 150, radius = 100;
    return Array.from({ length: nodeCount }, (_, i) => {
      const angle = (2 * Math.PI * i) / nodeCount - Math.PI / 2;
      return { x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle) };
    });
  };

  // Generate edges for SVG graph connecting nodes
  const getEdges = (ring) => {
    if (ring.links) {
      // Use real link data from union-find detected rings
      const zipIndex = Object.fromEntries(ring.zips.map((z, i) => [z, i]));
      return ring.links.map((link, i) => ({
        from: zipIndex[link.source_zip] ?? (i % ring.nodes),
        to: zipIndex[link.target_zip] ?? ((i + 1) % ring.nodes),
        type: link.link_type,
      }));
    }
    // Fallback: generate edges from shared types for pre-computed rings
    const edges = [];
    const sharedTypes = ring.shared || [];
    for (let i = 0; i < ring.edges; i++) {
      edges.push({
        from: i % ring.nodes,
        to: (i + 1 + Math.floor(i / 3)) % ring.nodes,
        type: sharedTypes[i % sharedTypes.length]?.toLowerCase() || 'city',
      });
    }
    return edges;
  };

  return (
    <div className="fraud-map-page">
      <div className="page-header-row">
        <h1>Fraud Map & Ring Detection</h1>
        <div className="map-toggle">
          <button className={`toggle-btn ${view === 'heatmap' ? 'active' : ''}`} onClick={() => setView('heatmap')}>
            Heatmap View
          </button>
          <button className={`toggle-btn ${view === 'rings' ? 'active' : ''}`} onClick={() => setView('rings')}>
            Fraud Rings View
          </button>
        </div>
      </div>

      {view === 'heatmap' && (
        <div className="heatmap-layout">
          {/* Map Visualization (simplified grid representation) */}
          <div className="map-container">
            <h3>US Fraud Impact by State (Choropleth)</h3>
            <div className="state-grid">
              {FRAUD_MAP_DATA.states.map(state => (
                <div
                  key={state.state}
                  className={`state-cell ${selectedState?.state === state.state ? 'selected' : ''}`}
                  style={{ backgroundColor: getHeatColor(state.fraud_impact) }}
                  onClick={() => setSelectedState(state)}
                  title={`${state.name}: ${state.fraud_impact} impacts`}
                >
                  <span className="state-code">{state.state}</span>
                  <span className="state-impact">{state.fraud_impact}</span>
                </div>
              ))}
            </div>
            <div className="map-legend">
              <span style={{ backgroundColor: '#2e7d32' }}>Low</span>
              <span style={{ backgroundColor: '#f57f17' }}>Medium</span>
              <span style={{ backgroundColor: '#e65100' }}>High</span>
              <span style={{ backgroundColor: '#c62828' }}>Critical</span>
            </div>
          </div>

          {/* State Ranking */}
          <div className="state-ranking">
            <h3>State Ranking</h3>
            <table className="ranking-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>State</th>
                  <th onClick={() => { setStateSortBy('fraud_impact'); setStateSortOrder(stateSortBy === 'fraud_impact' && stateSortOrder === 'desc' ? 'asc' : 'desc'); }} style={{ cursor: 'pointer' }}>
                    Impact {stateSortBy === 'fraud_impact' ? (stateSortOrder === 'desc' ? '↓' : '↑') : ''}
                  </th>
                  <th onClick={() => { setStateSortBy('confirmed'); setStateSortOrder(stateSortBy === 'confirmed' && stateSortOrder === 'desc' ? 'asc' : 'desc'); }} style={{ cursor: 'pointer' }}>
                    Confirmed {stateSortBy === 'confirmed' ? (stateSortOrder === 'desc' ? '↓' : '↑') : ''}
                  </th>
                  <th>ZIP Count</th>
                </tr>
              </thead>
              <tbody>
                {[...FRAUD_MAP_DATA.states]
                  .sort((a, b) => stateSortOrder === 'desc' ? b[stateSortBy] - a[stateSortBy] : a[stateSortBy] - b[stateSortBy])
                  .map((s, i) => (
                    <tr key={s.state} className={selectedState?.state === s.state ? 'selected' : ''} onClick={() => setSelectedState(s)}
                      style={selectedState?.state === s.state ? { background: getHeatColor(s.fraud_impact) + '22', borderLeft: `4px solid ${getHeatColor(s.fraud_impact)}` } : {}}>
                      <td>{i + 1}</td>
                      <td>{s.name}</td>
                      <td><strong>{s.fraud_impact}</strong></td>
                      <td>{s.confirmed}</td>
                      <td>{s.zip_count}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* State Detail */}
          {selectedState && (
            <div className="state-detail">
              <h3>{selectedState.name} ({selectedState.state})</h3>
              <div className="detail-metrics">
                <div><strong>Fraud Impact:</strong> {selectedState.fraud_impact}</div>
                <div><strong>Confirmed Fraud:</strong> {selectedState.confirmed}</div>
                <div><strong>ZIP Codes Affected:</strong> {selectedState.zip_count}</div>
                <div><strong>Top ZIPs:</strong> {selectedState.top_zips.join(', ')}</div>
              </div>
            </div>
          )}
        </div>
      )}

      {view === 'rings' && (
        <div className="rings-layout">
          {/* Fraud Rings List */}
          <div className="rings-list">
            <h3>Detected Fraud Rings (Top {fraudRings.length} multi-node rings)</h3>
            <div className="rings-grid">
              {fraudRings.map(ring => (
                <div
                  key={ring.id}
                  className={`ring-card ${selectedRing?.id === ring.id ? 'selected' : ''}`}
                  onClick={() => setSelectedRing(ring)}
                  style={{ borderLeft: `4px solid ${getRingColor(ring.risk_level)}` }}
                >
                  <div className="ring-header">
                    <strong>{ring.id}</strong>
                    <span className={`ring-level level-${ring.risk_level}`}>{ring.risk_level}</span>
                  </div>
                  <div className="ring-stats">
                    <span>Nodes: {ring.nodes}</span>
                    <span>Edges: {ring.edges}</span>
                  </div>
                  {ring.type && <div className="ring-type">{ring.type}</div>}
                  <div className="ring-cities">{(ring.cities || ring.zips || []).join(', ')}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Ring Visualization */}
          <div className="ring-visualization">
            <h3>Ring Network Graph</h3>
            {selectedRing ? (
              <div className="ring-detail-view">
                <div className="ring-graph-svg-container">
                  <svg viewBox="0 0 400 300" className="ring-graph-svg">
                    {/* Render edges as colored lines between nodes */}
                    {(() => {
                      const positions = getNodePositions(selectedRing.nodes);
                      const edges = getEdges(selectedRing);
                      return edges.map((edge, i) => {
                        const from = positions[edge.from] || positions[0];
                        const to = positions[edge.to] || positions[1];
                        const linkType = edge.type?.toLowerCase() || 'city';
                        const color = LINK_TYPE_COLORS[linkType.includes('city') ? 'city' : linkType.includes('email') ? 'email' : linkType.includes('phone') || linkType.includes('imei') ? 'phone' : 'address'];
                        return (
                          <line key={`edge-${i}`} x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                            stroke={color} strokeWidth="2" strokeOpacity="0.7" />
                        );
                      });
                    })()}
                    {/* Render nodes as sized circles at ZIP code positions */}
                    {(() => {
                      const positions = getNodePositions(selectedRing.nodes);
                      return positions.map((pos, i) => {
                        const size = 12 + (selectedRing.nodes - i) * 2;
                        return (
                          <g key={`node-${i}`}>
                            <circle cx={pos.x} cy={pos.y} r={size} fill="rgba(21,101,192,0.15)"
                              stroke="#1565c0" strokeWidth="2" />
                            <text x={pos.x} y={pos.y + 4} textAnchor="middle" fill="#212121"
                              fontSize="10" fontWeight="bold">
                              {selectedRing.zips?.[i] || `N${i + 1}`}
                            </text>
                          </g>
                        );
                      });
                    })()}
                  </svg>
                </div>
                <div className="ring-detail-info">
                  <h4>Ring Details: {selectedRing.id}</h4>
                  <p><strong>Risk Level:</strong> <span className={`ring-level level-${selectedRing.risk_level}`}>{selectedRing.risk_level}</span></p>
                  <p><strong>Nodes:</strong> {selectedRing.nodes} | <strong>Edges:</strong> {selectedRing.edges}</p>
                  <p><strong>Shared Link Types:</strong></p>
                  <div className="ring-shared-links">
                    {selectedRing.shared.map((attr, i) => {
                      const linkType = attr.toLowerCase();
                      let display = attr;
                      if (linkType.includes('email')) display = 'Email: ***@***.com (masked)';
                      else if (linkType.includes('phone')) display = 'Phone: ***-***-XX12 (masked)';
                      else if (linkType.includes('imei')) display = 'IMEI: 35XXXXXXXXX (masked)';
                      else if (linkType.includes('address')) display = 'Address: *** (masked)';
                      else display = `City: ${attr}`;
                      return <span key={i} className={`shared-link-tag link-${linkType.includes('city') ? 'city' : linkType.includes('email') ? 'email' : linkType.includes('phone') || linkType.includes('imei') ? 'phone' : 'address'}`}>{display}</span>;
                    })}
                  </div>
                  <p className="pii-mask-note">PII values masked — showing link type and truncated identifiers only</p>
                  <p><strong>ZIP Codes:</strong> {selectedRing.zips.join(', ')}</p>
                  <p><strong>Cities:</strong> {selectedRing.cities.join(', ')}</p>
                </div>
              </div>
            ) : (
              <p className="no-data">Select a fraud ring to view its network graph</p>
            )}
          </div>

          {/* Legend */}
          <div className="ring-legend">
            <h4>Link Types</h4>
            <div className="legend-items">
              <span className="legend-item"><span className="legend-color" style={{ background: '#1565c0' }}></span> City</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#c62828' }}></span> Email</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#2e7d32' }}></span> Phone</span>
              <span className="legend-item"><span className="legend-color" style={{ background: '#e65100' }}></span> Address</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
