import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCases } from '../contexts/CasesContext';
import { LEADERSHIP_METRICS, ORDER_ANALYTICS, FRAUD_TREND, FRAUD_MAP_DATA, FEEDBACK_METRICS } from '../data/dummyData';
import KPICard from '../components/KPICard';
import USAMap from '../components/USAMap';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, ComposedChart, Line, LabelList, ResponsiveContainer, Legend } from 'recharts';

export default function LeadershipDashboardPage() {
  const { user } = useAuth();
  const { cases, setFilters } = useCases();
  const navigate = useNavigate();
  const [granularity, setGranularity] = useState('monthly');
  const [dateFilter, setDateFilter] = useState('all');

  const myCases = cases;

  const filteredCases = useMemo(() => {
    if (dateFilter === 'all') return myCases;
    const now = new Date();
    const months = parseInt(dateFilter);
    const fromDate = new Date(now.getFullYear(), now.getMonth() - months, now.getDate());
    return myCases.filter(c => new Date(c.created_at) >= fromDate);
  }, [myCases, dateFilter]);

  const openCases = filteredCases.filter(c => ['open', 'assigned', 'in_progress'].includes(c.status)).length;
  const resolvedCases = filteredCases.filter(c => c.status === 'resolved').length;
  const escalatedCases = filteredCases.filter(c => c.status === 'escalated').length;
  const slaBreach = filteredCases.filter(c => c.sla_status === 'breached').length;
  const fraudCases = filteredCases.filter(c => c.ticket_type.includes('fraud'));
  const highRiskAlerts = filteredCases.filter(c => c.risk_score >= 80).length;

  const orderData = ORDER_ANALYTICS[granularity] || [];
  const fraudTrendData = FRAUD_TREND[granularity] || [];
  const totalOrdersSum = orderData.reduce((s, d) => s + d.total_orders, 0);
  const closedSum = orderData.reduce((s, d) => s + d.closed, 0);
  const escalatedSum = orderData.reduce((s, d) => s + d.escalated, 0);

  const states = FRAUD_MAP_DATA.states;
  const maxImpact = Math.max(...states.map(s => s.fraud_impact));
  const getHeatColor = (impact) => {
    const intensity = impact / maxImpact;
    if (intensity > 0.7) return '#c62828';
    if (intensity > 0.5) return '#e65100';
    if (intensity > 0.3) return '#f57f17';
    if (intensity > 0.15) return '#fdd835';
    return '#66bb6a';
  };

  const openVsResolvedData = [
    { name: 'Open', value: openCases, color: '#e65100' },
    { name: 'Resolved', value: resolvedCases, color: '#2e7d32' },
  ];

  const navigateWithFilter = (filterKey, filterValue) => {
    setFilters({ status: '', priority: '', ticket_type: '', assigned_to: '', search: '', dateFrom: '', dateTo: '', [filterKey]: filterValue });
    navigate('/cases');
  };

  return (
    <div className="leadership-page">
      {/* Header */}
      <div className="leadership-header">
        <h2>Leadership Analytics</h2>
        <div className="leadership-controls">
          <select className="granularity-select" value={dateFilter} onChange={e => setDateFilter(e.target.value)}>
            <option value="all">All Time</option>
            <option value="1">Last 1 Month</option>
            <option value="3">Last 3 Months</option>
            <option value="6">Last 6 Months</option>
          </select>
          <select className="granularity-select" value={granularity} onChange={e => setGranularity(e.target.value)}>
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid leadership-kpi-grid">
        <div onClick={() => navigateWithFilter('ticket_type', 'fraud_ordering')} style={{ cursor: 'pointer' }}>
          <KPICard title="Total Fraud Cases" value={fraudCases.length} color="#c62828" />
        </div>
        <KPICard title="Fraud Loss Prevented" value={`$${(LEADERSHIP_METRICS.fraud_loss_prevented / 1000000).toFixed(1)}M`} color="#2e7d32" />
        <KPICard title="AI Detection Accuracy" value={`${LEADERSHIP_METRICS.ai_detection_accuracy}%`} color="#1565c0" />
        <KPICard title="Fraud Trend" value={`+${LEADERSHIP_METRICS.fraud_trend_delta}%`} color="#e65100" />
        <KPICard title="Open vs Resolved" value={`${openCases} / ${resolvedCases}`} color="#7b1fa2" />
        <div onClick={() => navigate('/sla-monitor')} style={{ cursor: 'pointer' }}>
          <KPICard title="SLA Breaches" value={LEADERSHIP_METRICS.sla_breaches_total} color="#d84315" />
        </div>
        <KPICard title="High-Risk Alerts" value={highRiskAlerts} color="#ad1457" />
        <KPICard title="Total Orders" value={totalOrdersSum.toLocaleString()} color="#00838f" />
      </div>

      {/* Charts Row 1: Fraud Trend + Order Analytics */}
      <div className="leadership-charts-row">
        <div className="chart-card">
          <h3>Fraud Trend <span className="info-tooltip-wrap" data-tooltip="Fraud cases and monetary loss trend over time with detection rate overlay">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <ComposedChart data={fraudTrendData} margin={{ top: 20, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
              <XAxis dataKey="period" fontSize={10} tick={{ fill: '#37474f' }} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" tick={{ fill: '#37474f', fontSize: 10 }} axisLine={false} tickLine={false} width={35} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#1565c0', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={v => `${v}%`} width={35} />
              <Tooltip contentStyle={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} />
              <Legend wrapperStyle={{ fontSize: '0.75rem', paddingTop: 4 }} iconType="square" iconSize={10} />
              <Bar yAxisId="left" dataKey="fraud_cases" fill="#ef5350" name="Fraud Cases" radius={[4, 4, 0, 0]} barSize={24} />
              <Line yAxisId="right" type="monotone" dataKey="detection_rate" stroke="#1565c0" strokeWidth={2.5} name="Detection %" dot={{ fill: '#fff', stroke: '#1565c0', strokeWidth: 2, r: 4 }}>
                <LabelList dataKey="detection_rate" position="top" fontSize={9} fill="#1565c0" fontWeight={700} formatter={v => `${v}%`} offset={8} />
              </Line>
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <h3>Order Analytics — {closedSum.toLocaleString()} Closed / {escalatedSum.toLocaleString()} Escalated <span className="info-tooltip-wrap" data-tooltip="Monthly breakdown of closed vs escalated orders across all regions">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <BarChart data={orderData.map(({ period, closed, escalated, pending }) => ({ period, closed, escalated, pending }))} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
              <XAxis dataKey="period" fontSize={10} tick={{ fill: '#37474f' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#37474f', fontSize: 10 }} axisLine={false} tickLine={false} width={35} />
              <Tooltip cursor={false} contentStyle={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '10px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} />
              <Legend wrapperStyle={{ fontSize: '0.75rem', paddingTop: 4 }} iconType="square" iconSize={10} />
              <Bar dataKey="closed" stackId="a" fill="#2dd4bf" name="Closed" />
              <Bar dataKey="escalated" stackId="a" fill="#ef5350" name="Escalated" />
              <Bar dataKey="pending" stackId="a" fill="#fbbf24" name="Pending" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2: Open vs Resolved + Fraud by Region Heatmap */}
      <div className="leadership-charts-row">
        <div className="chart-card">
          <h3>Open vs Resolved Cases <span className="info-tooltip-wrap" data-tooltip="Donut chart showing ratio of currently open cases to resolved cases">&#9432;</span></h3>
          <ResponsiveContainer width="100%" height={290}>
            <PieChart>
              <Pie
                data={openVsResolvedData}
                cx="50%" cy="48%"
                innerRadius="45%" outerRadius="70%"
                dataKey="value"
                stroke="none"
                isAnimationActive={false}
                label={({ cx, cy, midAngle, outerRadius, name, value }) => {
                  const RADIAN = Math.PI / 180;
                  const x = cx + (outerRadius + 22) * Math.cos(-midAngle * RADIAN);
                  const y = cy + (outerRadius + 22) * Math.sin(-midAngle * RADIAN);
                  return <text x={x} y={y} fill="#37474f" textAnchor="middle" fontSize={12} fontWeight={700}>{name}: {value}</text>;
                }}
              >
                {openVsResolvedData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card chart-card-map">
          <h3>Fraud by Region — USA <span className="info-tooltip-wrap" data-tooltip="Geographic heatmap of fraud impact across all 50 US states with pin markers">&#9432;</span></h3>
          <div className="map-stats-row">
            <div className="map-stat-card">
              <span className="map-stat-num" style={{ color: '#1a237e' }}>{states.length}</span>
              <span className="map-stat-label">States Monitored</span>
            </div>
            <div className="map-stat-card">
              <span className="map-stat-num" style={{ color: '#c62828' }}>{states.reduce((s, d) => s + d.fraud_impact, 0).toLocaleString()}</span>
              <span className="map-stat-label">Total Impact</span>
            </div>
            <div className="map-stat-card">
              <span className="map-stat-num" style={{ color: '#e65100' }}>{states.reduce((s, d) => s + d.confirmed, 0).toLocaleString()}</span>
              <span className="map-stat-label">Confirmed Cases</span>
            </div>
            <div className="map-stat-card">
              <span className="map-stat-num" style={{ color: '#b71c1c' }}>{states.filter(d => d.fraud_impact > 100).length}</span>
              <span className="map-stat-label">High-Risk States</span>
            </div>
          </div>
          <USAMap data={states} getColor={getHeatColor} />
          <div className="leadership-heatmap-legend">
            <span className="heatmap-legend-label">Low</span>
            <div className="heatmap-legend-bar">
              <span style={{ background: '#66bb6a' }}></span>
              <span style={{ background: '#fdd835' }}></span>
              <span style={{ background: '#f57f17' }}></span>
              <span style={{ background: '#e65100' }}></span>
              <span style={{ background: '#c62828' }}></span>
            </div>
            <span className="heatmap-legend-label">Critical</span>
          </div>
        </div>
      </div>
    </div>
  );
}
